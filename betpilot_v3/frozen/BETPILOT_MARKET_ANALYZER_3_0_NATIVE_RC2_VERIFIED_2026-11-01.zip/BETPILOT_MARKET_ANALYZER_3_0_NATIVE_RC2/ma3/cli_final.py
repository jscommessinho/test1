"""Read-only normalized final sources interface; no GA2 fallback.

python -m ma3.cli_final normalized_bundle.json -o ma3_report.json
"""
import argparse
import json
from pathlib import Path
from .final_sources import analyze_final_sources

def main():
    p=argparse.ArgumentParser(description='MA3 normalized GA3 RC2 + GTS3 RC1 + RC15 Verdict C reader')
    p.add_argument('input',type=Path)
    p.add_argument('-o','--output',type=Path)
    x=p.parse_args()
    data=json.loads(x.input.read_text(encoding='utf8'))
    result=analyze_final_sources(data)
    encoded=json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n'
    if x.output: x.output.write_text(encoded,encoding='utf8')
    else: print(encoded)
if __name__=='__main__':main()
