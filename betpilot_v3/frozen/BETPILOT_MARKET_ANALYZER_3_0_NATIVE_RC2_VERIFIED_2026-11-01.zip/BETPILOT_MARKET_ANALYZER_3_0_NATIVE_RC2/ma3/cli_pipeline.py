"""End-to-end MA3 communication entrypoint using external normalized GA3 and GTS3 outputs.

python -m ma3.cli_pipeline --match match.json --ga3 ga3.normalized.json \\
  --gts3 gts3.normalized.json --rc15-input RC15_EVENT_INPUT.json \\
  --ga3-source /path/original-ga3-output.json --gts3-source /path/original-gts3-output.json \\
  --output-dir results/
"""
import argparse
import json
from pathlib import Path
from .core import MarketError
from .runtime import json_read, run_pipeline, verify_source_file


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('match','ga3','gts3','rc15-input'):
        ap.add_argument('--'+name,required=True,type=Path)
    ap.add_argument('--ga3-source',type=Path,help='Original GA3 RC2 artifact, verified against normalized SHA256')
    ap.add_argument('--gts3-source',type=Path,help='Original GTS3 RC1 artifact, verified against normalized SHA256')
    ap.add_argument('--output-dir',required=True,type=Path)
    ap.add_argument('--requested-markets',nargs='*')
    a=ap.parse_args(argv)
    m=json_read(a.match);ga=json_read(a.ga3);gts=json_read(a.gts3);rc=json_read(a.rc15_input)
    for payload,filename,label in ((ga,a.ga3_source,'GA3'),(gts,a.gts3_source,'GTS3')):
        if filename is None:
            raise MarketError(f'--{label.lower()}-source is required: native original artifact hash must be verified')
        verify_source_file(payload,filename,label)
    res=run_pipeline(m,ga,gts,rc,a.output_dir,requested_markets=a.requested_markets)
    print(json.dumps({'pipeline':res['manifest']['pipeline'],
                      'analyzed_markets':len(res['market_analyzer']['markets']),
                      'selection_status':res['betanalyzer_handoff']['selection_status'],
                      'output_dir':str(a.output_dir)},indent=2))

if __name__=='__main__':main()
