"""Default MA3 invocation is final-sources only. No legacy runtime flag."""
from .cli_final import main
if __name__ == '__main__': main()
