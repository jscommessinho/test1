"""BETPILOT MA3 isolated integration runtime.

GA3 RC2 and GTS3 RC1 enter ONLY through reviewed normalized contracts.
Bookmaker RC15 is executed with Verdict C C-01/C-02 using its verified
existing adapter; never call the legacy Step5 orchestration, GA2, or MA2.
Return market evaluation + BetAnalyzer handoff, no betting decision.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Callable

from .core import MarketError, timestamp
from .final_sources import ADAPTER_VERSION, analyze_final_sources

PIPELINE_VERSION = "BETPILOT_MA3_COMMUNICATION_RC1_2026-11-01"


def sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def json_read(path: str | Path) -> dict:
    with open(path, encoding='utf-8') as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise MarketError('JSON root must be an object')
    return data


def verify_source_file(normalized: dict, original_path: str | Path, label: str):
    actual = sha256(original_path)
    declared = normalized.get('source_artifact_sha256')
    if actual != declared:
        raise MarketError(f'{label} source artifact SHA256 mismatch; expected {declared}, actual {actual}')
    return actual


def _same_match(match: dict, other: dict, label: str):
    for key in ('event_id', 'home', 'away', 'competition', 'kickoff', 'cutoff'):
        if match.get(key) != other.get(key):
            raise MarketError(f'{label}: {key} mismatch')
    if timestamp(match['cutoff']) >= timestamp(match['kickoff']):
        raise MarketError('cutoff must precede kickoff')


def rc15_verdict_c_only(payload: dict, out_dir: str | Path) -> dict:
    """Invoke unchanged RC15 with applied Verdict C, WITHOUT Step5.run_full.

    Works when installed in the existing betpilot-prematch-analyzer repository.
    Uses its original native RC15 implementation and the existing Verdict C
    adapter, not any internal GA2 or MA2 model/runtime.
    """
    try:
        from betpilot import bookmaker_verdict_c as verdict
    except ImportError as exc:
        raise MarketError('Original RC15+Verdict C module unavailable in this environment; run from BETPILOT repository') from exc

    native = verdict.native
    clean = copy.deepcopy(payload)
    if 'goal_analyzer' in clean:
        raise MarketError('Legacy GA2 input forbidden in RC15-only path')
    try:
        native.check_payload(clean)
    except (KeyError, ValueError, TypeError, AssertionError) as exc:
        raise MarketError(f'RC15 input validation failed: {exc}') from exc
    row = clean['match']
    odds = clean['odds']
    snapshot = clean['odds_snapshot']
    path = Path(out_dir)
    path.mkdir(parents=True, exist_ok=True)
    try:
        model = json.loads(verdict._MODEL.read_text(encoding='utf-8'))
        # Original code is referenced but never altered. Verdict C only touches
        # the generated report in this run folder.
        report, manifest, csv_path = verdict._rc15_fixed(
            row, odds, path, native.native_rc15, model
        )
    except (KeyError, ValueError, RuntimeError, AssertionError) as exc:
        raise MarketError(f'RC15 + Verdict C execution failed: {exc}') from exc
    quality = report['data_quality']
    audit = {
        'schema': 'BETPILOT_BOOKMAKER_VERDICT_C_V1',
        'source': 'Unmodified RC15, RC12 and BISE; isolated Verdict C corrections',
        'competition_mapping': quality['verdict_c_competition_mapping'],
        'unavailable_reference_events': quality['verdict_c_reference_mismatches'],
        'coefficients_changed': False,
        'historical_recalibration_claimed': False,
        'prospective_prediction_validated': False,
    }
    # The bookmaker's seven required odds plus any optional binary lines,
    # using native mapping rather than inventing independent probabilities.
    quotes = [
        {
            'market_id': native.MARKET_NAMES[k],
            'decimal_odds': v,
            'timestamp': snapshot['timestamp'],
            'snapshot_id': snapshot.get('snapshot_id') or 'SINGLE_CAPTURE',
            'source': 'Bet365',
            'provenance': ({
                'USER_SUPPLIED_NOT_TIMESTAMP_VERIFIED': 'NOT_VERIFIED',
                'VERIFIED_EXTERNAL_SNAPSHOT': 'VERIFIED_EXTERNAL_SNAPSHOT',
                'SYNTHETIC': 'SYNTHETIC',
            }[snapshot['provenance']]),
            **({'external_capture_reference': snapshot['external_capture_reference']}
               if snapshot['provenance'] == 'VERIFIED_EXTERNAL_SNAPSHOT' else {}),
        }
        for k, v in odds.items()
        if k in native.MARKET_NAMES and v is not None
    ]
    result = {'verdict_c_audit': audit, 'rc15_report': report, 'quotes': quotes}
    (path / 'BOOKMAKER_VERDICT_C_AUDIT.json').write_text(
        json.dumps(audit, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8'
    )
    (path / 'BOOKMAKER_MA3_BRIDGE.json').write_text(
        json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8'
    )
    return result


def build_handoff(report: dict) -> dict:
    """Machine-readable BetAnalyzer handoff; NEVER a betting selection."""
    markets = []
    for row in report['markets']:
        markets.append({
            k: copy.deepcopy(row.get(k)) for k in (
                'market_id', 'technical_status', 'value_status', 'model_probability',
                'bookmaker_probability', 'difference_pp', 'odds', 'fair_odds',
                'expected_profit_per_unit', 'reliability', 'probability_basis',
                'settlement_probabilities', 'limitations', 'quote_provenance'
            )
        })
    return {
        'protocol': 'BETPILOT_BETANALYZER_HANDOFF_MA3_V1',
        'event': copy.deepcopy(report['match']),
        'upstream': copy.deepcopy(report['upstream_status']),
        'market_analyzer_protocol': report['protocol'],
        'market_analyzer_adapter': report['final_sources_adapter'],
        'markets': markets,
        'rankings': copy.deepcopy(report['rankings']),
        'coherence_issues': copy.deepcopy(report['coherence_issues']),
        'gts3_descriptive': copy.deepcopy(report['gts3_descriptive']),
        'bookmaker_methods': copy.deepcopy(report['bookmaker_rc15_market_methods']),
        'betting_recommendation': None,
        'stake': None,
        'final_selection': None,
        'selection_status': 'HANDOFF_ONLY_BETANALYZER_DECIDES',
        'native_betanalyzer_integration_verified': False,
        'operational_eligible': False,
    }


def run_pipeline(match: dict, ga3_normalized: dict, gts3_normalized: dict,
                 rc15_input: dict, out_dir: str | Path,
                 bookmaker_executor: Callable[[dict, str | Path], dict] = rc15_verdict_c_only,
                 requested_markets: list[str] | None = None,
                 native_parity_verified: bool = False) -> dict:
    """Run native corrected RC15 once, consume normalized final-source inputs.

    Does not execute upstream GA3/GTS3, whose native CLIs are not in this repo.
    Caller must supply their actual precomputed normalized outputs.
    """
    _same_match(match, rc15_input.get('match', {}), 'RC15 input')
    bundle = {
        'match': copy.deepcopy(match),
        'ga3_rc2': copy.deepcopy(ga3_normalized),
        'gts3_rc1': copy.deepcopy(gts3_normalized),
    }
    path = Path(out_dir)
    path.mkdir(parents=True, exist_ok=True)
    bundle['bookmaker_rc15_verdict_c'] = bookmaker_executor(copy.deepcopy(rc15_input), path/'rc15_verdict_c')
    if requested_markets is not None:
        bundle['requested_markets'] = copy.deepcopy(requested_markets)
    report = analyze_final_sources(bundle)
    if native_parity_verified:
        if not all(p.get('native_schema_parity_verified') is True for p in
                   (ga3_normalized, gts3_normalized)):
            raise MarketError('Native parity flag requires real validated exports')
        report['upstream_status']['goal_analyzer']='GA3 RC2 native schema and numeric market parity verified'
        report['upstream_status']['gts']='GTS3 RC1 native schema validated (historical prematch snapshots NOT authenticated)'
        report['upstream_status']['native_ga3_gts3_parity_verified']=True
        report['selection_status']='ABSTAIN_RESEARCH_ONLY_NO_OPERATIONAL_VALIDATION'
        report['operational_eligible']=False
    handoff = build_handoff(report)
    (path/'MA3_INPUT_NORMALIZED.json').write_text(json.dumps(bundle, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')
    (path/'MA3_ANALYSIS.json').write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')
    (path/'BETANALYZER_HANDOFF.json').write_text(json.dumps(handoff, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')
    manifest = {
        'pipeline': PIPELINE_VERSION,
        'source_engines_modified': False,
        'ga3_gts3_native_parity_verified': native_parity_verified,
        'selection_automated': False,
        'files_sha256': {name:sha256(path/name) for name in ('MA3_INPUT_NORMALIZED.json','MA3_ANALYSIS.json','BETANALYZER_HANDOFF.json')},
    }
    (path/'MA3_RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return {'market_analyzer': report, 'betanalyzer_handoff': handoff, 'manifest': manifest}
