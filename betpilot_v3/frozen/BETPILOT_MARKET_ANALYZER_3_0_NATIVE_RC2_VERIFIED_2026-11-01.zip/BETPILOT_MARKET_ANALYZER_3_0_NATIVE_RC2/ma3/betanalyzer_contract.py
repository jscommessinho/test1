"""Read-only BetAnalyzer handoff consumer / intake audit; NOT BetAnalyzer decision engine.

This validates the MA3 handoff for a future native BetAnalyzer connector. It
never chooses a bet, sizes stake, computes bankroll utility, or calls legacy MA2.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
from .core import MarketError,number,timestamp

PROTOCOL='BETPILOT_BETANALYZER_HANDOFF_MA3_V1'

def accept_handoff(payload: dict) -> dict:
    if not isinstance(payload,dict) or payload.get('protocol')!=PROTOCOL:
        raise MarketError('Unknown BetAnalyzer intake protocol')
    e=payload.get('event')
    if not isinstance(e,dict) or not all(isinstance(e.get(k),str) and e[k] for k in
        ('event_id','home','away','competition','kickoff','cutoff')):
        raise MarketError('Missing event identity')
    if timestamp(e['cutoff'])>=timestamp(e['kickoff']):
        raise MarketError('Input is not prematch')
    if payload.get('operational_eligible') is not False or any(payload.get(k) is not None
            for k in ('stake','betting_recommendation','final_selection')):
        raise MarketError('Research handoff cannot contain executable betting orders')
    up=payload.get('upstream')
    if not isinstance(up,dict) or up.get('native_ga3_gts3_parity_verified') is not True:
        raise MarketError('GA3/GTS3 native parity unverified')
    sidecar=payload.get('gts3_descriptive')
    if not isinstance(sidecar,dict) or sidecar.get('numeric_fusion_with_ga3') is not False:
        raise MarketError('GTS3 must remain non-probability sidecar')
    if payload.get('native_betanalyzer_integration_verified') is not False:
        raise MarketError('Cannot claim native BetAnalyzer already verified')
    markets=payload.get('markets')
    if not isinstance(markets,list) or not markets:
        raise MarketError('No markets to deliver to BetAnalyzer')
    seen=set();quoted=0
    for row in markets:
        if not isinstance(row,dict):raise MarketError('Malformed market row')
        mid=row.get('market_id')
        if not isinstance(mid,str) or mid in seen:raise MarketError('Duplicate/bad market')
        seen.add(mid)
        if row.get('reliability') not in ('NOT_CALIBRATED','CALIBRATED_VALIDATED'):
            raise MarketError('Unsupported reliability class')
        p=row.get('model_probability')
        if p is not None:number(p,'market probability',0,1)
        quote=row.get('odds')
        if quote is not None:
            if number(quote,'quote')<=1:raise MarketError('Invalid quote')
            quoted+=1
        if row.get('value_status')=='POSITIVE_MODEL_EV_UNVALIDATED' and payload.get('operational_eligible') is not False:
            raise MarketError('Unvalidated EV must not authorize bets')
    return {'status':'BETANALYZER_HANDOFF_ACCEPTED_RESEARCH_ONLY',
            'event_id':e['event_id'],'markets':len(markets),
            'markets_with_offered_odds':quoted,'gts_numeric_fusion':False,
            'native_betanalyzer_decision_engine_executed':False,
            'betting_authorized':False,'recommended_selection':None}

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('handoff',type=Path)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args(argv)
    report=accept_handoff(json.loads(args.handoff.read_text('utf8')))
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    else:print(json.dumps(report,indent=2))
if __name__=='__main__':main()
