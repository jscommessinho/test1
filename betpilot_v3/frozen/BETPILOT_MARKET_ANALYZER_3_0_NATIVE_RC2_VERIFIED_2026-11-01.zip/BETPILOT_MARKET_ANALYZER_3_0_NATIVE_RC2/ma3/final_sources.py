"""Read-only, fail-closed *normalized* GA3 RC2 / GTS3 RC1 / RC15 Verdict C bridge.

NOT the undisclosed GA3 or GTS3 native parser. A separately verified exporter must
create the normalization envelope; no automatic GA2 fallback or probability fitting.
No source is modified. GTS is forwarded, never combined with GA3 probabilities.
"""
from __future__ import annotations

import copy
import hashlib
import json
from datetime import timezone
from .core import MarketError, analyze, is_binary, load_matrix, number, timestamp

ADAPTER_VERSION = 'MA3-FINAL-SOURCES-NORMALIZED-CONTRACT-1'
GA3 = 'GA3_RC2'  # normalization labels, NOT verified upstream version strings
GTS3 = 'GTS3_RC1'
VERDICT = 'BETPILOT_BOOKMAKER_VERDICT_C_V1'

_RC15_MAPPING = {
    '1X2': {'1':'FT.1X2.H','X':'FT.1X2.D','2':'FT.1X2.A',
            '1X':'FT.DC.1X','X2':'FT.DC.X2','12':'FT.DC.12'},
    'OU2_5': {'Over_2_5':'FT.TOTAL.OVER.2.5','Under_2_5':'FT.TOTAL.UNDER.2.5'},
    'BTTS': {'GG':'FT.BTTS.YES','NG':'FT.BTTS.NO'},
}


def _obj(v, name):
    if not isinstance(v, dict):
        raise MarketError(f'{name} must be an object')
    return v


def _string(v, name):
    if not isinstance(v, str) or not v.strip():
        raise MarketError(f'{name} must be a nonempty string')
    return v


def _same_event(obj, match, label):
    if _string(obj.get('event_id'),label+'.event_id') != match['event_id']:
        raise MarketError(f'{label}: match event_id mismatch')
    for x in ('home','away'):
        if _string(obj.get(x),label+'.'+x).strip().casefold() != match[x].strip().casefold():
            raise MarketError(f'{label}: {x} mismatch')


def _prior(obj, match, label):
    t=timestamp(obj.get('cutoff'),label+'.cutoff')
    if t > timestamp(match['cutoff'],'match.cutoff'):
        raise MarketError(f'{label}: future information')
    return t


def _pitch_only(obj, name):
    if obj.get('source') != 'PitchAPI':
        raise MarketError(f'{name}: source must be PitchAPI')
    if obj.get('footystats_prediction_input'):
        raise MarketError(f'{name}: FootyStats cannot feed the prediction path')


def _ga3_normalized(g,match):
    _obj(g,'ga3_rc2')
    if g.get('release') != GA3 or g.get('contract') != ADAPTER_VERSION:
        raise MarketError('GA3 RC2 normalized contract/release mismatch; no GA2 fallback')
    _pitch_only(g,'GA3')
    _same_event(g,match,'GA3')
    _prior(g,match,'GA3')
    _string(g.get('source_artifact_sha256'),'GA3.source_artifact_sha256')
    if len(g['source_artifact_sha256'])!=64 or any(c not in '0123456789abcdef' for c in g['source_artifact_sha256'].lower()):
        raise MarketError('GA3 original artifact SHA256 must be 64 hex characters')
    if not any(k in g for k in ('scorelines','event_probabilities','settlement_probabilities')):
        raise MarketError('GA3: no probability data supplied')
    pm={'version':'GA3 RC2 (normalized; native schema unverified)',
        'source':'PitchAPI', 'event_id':g['event_id'], 'cutoff':g['cutoff'],
        'validation_state':g.get('validation_state','UNVERIFIED'),
        'source_artifact_sha256':g['source_artifact_sha256']}
    if 'scorelines' in g:
        load_matrix(g['scorelines'])
        pm['periods']={'FT':{'scorelines':copy.deepcopy(g['scorelines']),
                               'construction':'Supplied by upstream GA3 exporter; never reconstructed from lambda'}}
    if 'event_probabilities' in g:
        v=_obj(g['event_probabilities'],'GA3.event_probabilities')
        for mid,p in v.items():
            if not is_binary(mid): raise MarketError('GA3 marginal for non-binary market')
            number(p,mid,0,1)
        pm['event_probabilities']=copy.deepcopy(v)
    if 'settlement_probabilities' in g:
        pm['settlement_probabilities']=copy.deepcopy(_obj(g['settlement_probabilities'],'GA3.settlement_probabilities'))
    return pm


def _validate_json_metrics(value, path='GTS.metrics', depth=0):
    if depth>12: raise MarketError('GTS metrics excessively nested')
    if isinstance(value, dict):
        for k,v in value.items():
            if not isinstance(k,str): raise MarketError(path+': non-string key')
            _validate_json_metrics(v,path+'.'+k,depth+1)
    elif isinstance(value,list):
        for i,v in enumerate(value): _validate_json_metrics(v,f'{path}[{i}]',depth+1)
    elif isinstance(value,bool) or value is None or isinstance(value,str):
        return
    elif isinstance(value,(float,int)):
        number(value,path)
    else: raise MarketError(path+': non-JSON metric')


def _gts_readonly(g,match):
    _obj(g,'gts3_rc1')
    if g.get('release') != GTS3 or g.get('contract') != ADAPTER_VERSION:
        raise MarketError('GTS3 RC1 normalized contract/release mismatch')
    _pitch_only(g,'GTS3')
    _same_event(g,match,'GTS3')
    _prior(g,match,'GTS3')
    _string(g.get('source_artifact_sha256'),'GTS3.source_artifact_sha256')
    if len(g['source_artifact_sha256'])!=64 or any(c not in '0123456789abcdef' for c in g['source_artifact_sha256'].lower()):
        raise MarketError('GTS3 source hash must be SHA256 hex')
    metrics=_obj(g.get('metrics'),'GTS3.metrics')
    if not metrics: raise MarketError('GTS3 has no descriptive metrics')
    _validate_json_metrics(metrics)
    return {'release':GTS3, 'source':'PitchAPI', 'cutoff':g['cutoff'],
            'source_artifact_sha256':g['source_artifact_sha256'],
            'validation_state':g.get('validation_state','UNVERIFIED'),
            'metrics':copy.deepcopy(metrics),
            'role':'DESCRIPTIVE_ONLY_NOT_A_SECOND_INDEPENDENT_PROBABILITY_MODEL',
            'numeric_fusion_with_ga3':False}


def _bookmaker_from_verdict(b,match):
    _obj(b,'bookmaker_rc15_verdict_c')
    audit=_obj(b.get('verdict_c_audit'),'Verdict C audit')
    if audit.get('schema') != VERDICT or audit.get('coefficients_changed') is not False:
        raise MarketError('Missing/corrupt Verdict C provenance audit')
    if audit.get('prospective_prediction_validated') is not False:
        raise MarketError('Unexpected Verdict C validation claim')
    report=_obj(b.get('rc15_report'),'RC15 native report')
    identity=_obj(report.get('identity'),'RC15.identity')
    if any(identity.get(key)!=match[key] for key in ('home','away')):
        raise MarketError('RC15 native team identity mismatch')
    # RC15 report's league can be canonicalized for BIG5 at the engine boundary.
    mapping=_obj(audit.get('competition_mapping'),'Verdict C competition mapping')
    if mapping.get('source') != match['competition'] or mapping.get('engine') != identity.get('league'):
        raise MarketError('RC15 competition identity / Verdict C mapping mismatch')
    quality=_obj(report.get('data_quality'),'RC15.data_quality')
    if quality.get('verdict_c_competition_mapping') != mapping:
        raise MarketError('Verdict C mapping not present in corrected RC15 output')
    mismatches=quality.get('verdict_c_reference_mismatches')
    if not isinstance(mismatches,list) or mismatches != audit.get('unavailable_reference_events'):
        raise MarketError('Verdict C historical-reference audit mismatch')
    refs=_obj(report.get('historical_support'),'RC15.historical_support')
    for key in mismatches:
        s=_obj(refs.get(key),f'RC15 historical_support.{key}')
        if s.get('support_level') != 'UNAVAILABLE_REFERENCE_MISMATCH' or any(
              s.get(k) is not None for k in ('n','mean_prediction','observed_frequency','bias_pp')):
            raise MarketError('Verdict C historical mismatch bins not masked')
    rc=_obj(report.get('single_market_probabilities_RC12_experimental'),'RC15 single probabilities')
    probs={};methods={}
    for family,mapping2 in _RC15_MAPPING.items():
        section=_obj(rc.get(family),'RC15.'+family)
        pp=_obj(section.get('p'),'RC15.'+family+'.p')
        method=_string(section.get('method'),'RC15.'+family+'.method')
        for native,mid in mapping2.items():
            probs[mid]=number(pp.get(native),mid,0,1)
            methods[mid]=method
    for trio in [('FT.1X2.H','FT.1X2.D','FT.1X2.A'),
                 ('FT.BTTS.YES','FT.BTTS.NO'),
                 ('FT.TOTAL.OVER.2.5','FT.TOTAL.UNDER.2.5')]:
        if abs(sum(probs[k] for k in trio)-1)>1e-7:
            raise MarketError('RC15 exhaustive price group not normalized')
    qs=b.get('quotes')
    if not isinstance(qs,list) or not qs:raise MarketError('Captured Bet365 quotes missing')
    collected=[]; ts=set();snap=set()
    for q in qs:
        _obj(q,'quote')
        if q.get('source')!='Bet365': raise MarketError('RC15 quotes must be Bet365')
        t=timestamp(q.get('timestamp'),'quote timestamp')
        if t>timestamp(match['cutoff']): raise MarketError('Future quote')
        ts.add(t);snap.add(q.get('snapshot_id'))
        if q.get('provenance') not in ('SYNTHETIC','NOT_VERIFIED','VERIFIED_EXTERNAL_SNAPSHOT'):
            raise MarketError('Missing explicit quote provenance')
        collected.append(copy.deepcopy(q))
    if len(ts)!=1 or len(snap)!=1:
        raise MarketError('RC15 captured quotes must be synchronized in one snapshot')
    ba={'protocol':'RC15+VERDICT_C','source':'Bet365',
        'timestamp':next(iter(ts)).isoformat(),
        'probability_method':'RC15_RC12_MARKET_SPECIFIC_METHODS_EXPERIMENTAL',
        'market_probabilities':probs,
        'validation_state':'RESEARCH_ONLY_VERDICT_C',
        'confidence':{'status':'HISTORICAL_BINS_NOT_ALL_REPRODUCIBLE',
                      'masked_reference_events':copy.deepcopy(mismatches)},
        'market_stability':copy.deepcopy(report.get('optional_market_diagnostics')),
        'scenario_intelligence':copy.deepcopy(report.get('bise_structural')),
        'per_market_methods':methods}
    return collected,ba


def from_final_sources(data):
    """Map normalized final upstream *outputs* without touching or recomputing them."""
    obj=_obj(data,'root')
    m=copy.deepcopy(_obj(obj.get('match'),'match'))
    for f in ('event_id','home','away','competition','kickoff','cutoff'):
        _string(m.get(f),'match.'+f)
    if not timestamp(m['cutoff']) < timestamp(m['kickoff']):
        raise MarketError('Match cutoff must precede kickoff')
    ga=_ga3_normalized(_obj(obj.get('ga3_rc2'),'ga3_rc2'),m)
    gts=_gts_readonly(_obj(obj.get('gts3_rc1'),'gts3_rc1'),m)
    qs,ba=_bookmaker_from_verdict(_obj(obj.get('bookmaker_rc15_verdict_c'),'bookmaker_rc15_verdict_c'),m)
    return ({'match':m,'probability_model':ga,'bookmaker_analyzer':ba,
             'quotes':qs,'requested_markets':copy.deepcopy(obj.get('requested_markets'))},gts)


def analyze_final_sources(data):
    normalized,gts=from_final_sources(data)
    original_before=hashlib.sha256(json.dumps(data,sort_keys=True,allow_nan=False).encode()).hexdigest()
    report=analyze(normalized)
    report['final_sources_adapter']=ADAPTER_VERSION
    report['upstream_status']={
        'goal_analyzer':'GA3 RC2 NORMALIZED INPUT (native schema NOT verified)',
        'gts':'GTS3 RC1 NORMALIZED INPUT (native schema NOT verified)',
        'bookmaker':'RC15 + VERIFIED-STRUCTURE VERDICT C AUDIT',
        'native_ga3_gts3_parity_verified':False,
        'source_read_only':True}
    report['gts3_descriptive']=gts
    report['bookmaker_rc15_market_methods']=normalized['bookmaker_analyzer']['per_market_methods']
    report['source_input_sha256']=original_before
    report['selection_status']='ABSTAIN_GA3_GTS3_NATIVE_PARITY_NOT_VERIFIED'
    report['operational_eligible']=False
    report['betting_recommendation']=None
    report['final_selection']=None
    if original_before!=hashlib.sha256(json.dumps(data,sort_keys=True,allow_nan=False).encode()).hexdigest():
        raise MarketError('Invariant violated: input mutated by MA3')
    return report
