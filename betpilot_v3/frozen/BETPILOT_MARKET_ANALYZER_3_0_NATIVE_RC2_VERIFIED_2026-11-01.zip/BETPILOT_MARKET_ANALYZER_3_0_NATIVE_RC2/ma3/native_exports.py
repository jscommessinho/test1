"""Verified GA3 RC2 and GTS3 RC1 NATIVE JSON -> immutable MA3 normalized contract.

This module doesn't import or run upstream engines or alter raw artifacts. The
native release input is the current ZIP's actual JSON schema, not guessed fields.
Raw data remain research-only: passing schema/parity does not certify the
historic capture point-in-time or betting profitability.
"""
from __future__ import annotations
import hashlib
import json
import bisect
import math
from datetime import datetime, date, timedelta
from pathlib import Path
from .core import MarketError, timestamp, load_matrix, market_from_matrix, number
from .final_sources import ADAPTER_VERSION

GA3_NATIVE_STATUS='RESEARCH_ONLY_NOT_VALIDATED_FOR_PRODUCTION'
GTS3_NATIVE_STATUS='RESEARCH_ONLY_NO_BETTING'
GTS3_FROZEN_PARAMETER_SHA256='7a87f0a372e895aa4cf8916f01575471937ae577c6719194cd4c0b0ac9515de6'


def _obj(obj, label):
    if not isinstance(obj, dict):
        raise MarketError(f'{label} must be an object')
    return obj


def _required(obj, name):
    if not isinstance(obj, str) or not obj.strip():
        raise MarketError(f'{name} must be a non-empty string')
    return obj


def _valid_hex(x):
    return isinstance(x, str) and len(x)==64 and all(ch in '0123456789abcdef' for ch in x.lower())


def _binding(match, ids):
    _obj(match,'match');_obj(ids,'pitchapi_identity')
    for key in ('event_id','home','away','competition','kickoff','cutoff'):
        _required(match.get(key), 'match.'+key)
    for k in ('league_id','home_team_id','away_team_id','season','identity_reference'):
        _required(ids.get(k),'pitchapi_identity.'+k)
    if ids['home_team_id']==ids['away_team_id']:
        raise MarketError('Same PitchAPI home and away team IDs')
    if timestamp(match['cutoff']) >= timestamp(match['kickoff']):
        raise MarketError('Match cutoff must precede kickoff')
    # Venue information may be independently verified or synthetic: never silently claim it.
    if ids.get('identity_provenance') not in ('EXTERNAL_VERIFIED','SYNTHETIC_TEST','USER_SUPPLIED_UNVERIFIED'):
        raise MarketError('Explicit identity_provenance required')
    return {'home':ids['home_team_id'],'away':ids['away_team_id']}


def _digest_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _native_source(path):
    raw=Path(path).read_bytes()
    parsed=json.loads(raw)
    return _obj(parsed,'native input'),hashlib.sha256(raw).hexdigest()


def export_ga3(native_path, match, identity):
    ids=_binding(match,identity)
    raw,digest=_native_source(native_path)
    if raw.get('status') != GA3_NATIVE_STATUS or raw.get('provider') != 'PitchAPI':
        raise MarketError('Not a GA3 RC2 PitchAPI native predict output; audit/backtest excluded')
    if raw.get('point_in_time_original_publication_verified') is not False:
        raise MarketError('Unexpected native GA3 historic availability flag')
    if raw.get('teams') != [ids['home'],ids['away']]:
        raise MarketError('Native GA3 PitchAPI team IDs/order mismatch')
    model=_obj(raw.get('model'),'GA3.model')
    if model.get('provider')!='PitchAPI' or model.get('competition') != 'PitchAPI:'+identity['league_id']:
        raise MarketError('GA3 model source competition/provider mismatch')
    model_cutoff=timestamp(model.get('cutoff'),'GA3 model cutoff')
    actual_asof=timestamp(raw.get('as_of'),'GA3.as_of')
    target_cutoff=timestamp(match['cutoff'])
    if not model_cutoff <= actual_asof <= target_cutoff < timestamp(match['kickoff']):
        raise MarketError('GA3 predicts after cutoff/kickoff or before model was trained')
    if timestamp(model.get('training_last_kickoff'),'GA3 training_last_kickoff') >= model_cutoff:
        raise MarketError('GA3 training includes future match')
    quality=_obj(raw.get('quality'),'GA3.quality')
    if quality.get('provider')!='PitchAPI' or quality.get('competition')!=model['competition']:
        raise MarketError('GA3 quality origin incompatible')
    if quality.get('point_in_time_original_publication_verified') is not False:
        raise MarketError('GA3 historical publication incorrectly certified')
    pred=_obj(raw.get('prediction'),'GA3.prediction')
    if pred.get('distribution') not in ('poisson','dixon_coles'):
        raise MarketError('Unsupported GA3 native distribution')
    axis=pred.get('score_axis_max')
    rows=pred.get('exact_scores')
    if type(axis)!=int or not 1<=axis<=100 or not isinstance(rows,list) or len(rows)!=axis+1:
        raise MarketError('Invalid native GA3 exact-score matrix shape')
    scorelines=[]
    for i,row in enumerate(rows):
        if not isinstance(row,list) or len(row)!=axis+1:
            raise MarketError('Non-square GA3 score matrix')
        for j,val in enumerate(row):
            scorelines.append({'home_goals':i,'away_goals':j,
                               'probability':number(val,'native GA3 exact score',0,1)})
    mat=load_matrix(scorelines)
    pm=_obj(pred.get('markets'),'GA3 native markets')
    mapping={
        'home_win':'FT.1X2.H','draw':'FT.1X2.D','away_win':'FT.1X2.A',
        'btts_yes':'FT.BTTS.YES','btts_no':'FT.BTTS.NO',
    }
    for prefix,fmt in (('', 'FT.TOTAL.{}.'),('home_','FT.TEAM.H.{}.'),('away_','FT.TEAM.A.{}.')):
        for i in range(7):
            for typ in ('over','under'):
                mapping[prefix+typ+f'_{i}.5']=fmt.format(typ.upper())+f'{i}.5'
    transformed={}
    for native_key,mid in mapping.items():
        p=number(pm.get(native_key), 'GA3 probability '+native_key,0,1)
        from_joint=market_from_matrix(mid,mat)['p_event']
        if abs(p-from_joint)>1e-8:
            raise MarketError('GA3 NATIVE PARITY MISMATCH: '+native_key)
        transformed[mid]=p
    # Never use lambda to replace the actual upstream joint distribution.
    return {
        'release':'GA3_RC2', 'contract':ADAPTER_VERSION, 'source':'PitchAPI',
        'source_artifact_sha256':digest,'event_id':match['event_id'],
        'home':match['home'],'away':match['away'],'cutoff':raw['as_of'],
        'scorelines':scorelines,'event_probabilities':transformed,
        'validation_state':GA3_NATIVE_STATUS,
        'native_schema_parity_verified':True,
        'native_distribution':pred['distribution'],
        'native_tail_truncation':number(pred.get('tail_truncation'), 'GA3 tail',0,1),
        'model_meta':{'as_of':raw['as_of'],'training_n':model.get('train_n'),
                      'source_competition':model['competition'],'quality':quality,
                      'pitchapi_identity':identity.copy()},
    }


def export_gts3(native_path, match, identity, model_parameters_path):
    ids=_binding(match,identity)
    raw,digest=_native_source(native_path)
    if raw.get('status')!=GTS3_NATIVE_STATUS:
        raise MarketError('Not a GTS3 RC1 native score output')
    if raw.get('lambda_adjustment_allowed') is not False:
        raise MarketError('GTS3 lambda injection forbidden')
    if raw.get('snapshot_is_true_prematch') is not False:
        raise MarketError('GTS3 snapshot claim not supported by RC1')
    if not str(raw.get('source','')).startswith('PitchAPI '):
        raise MarketError('GTS3 must derive from PitchAPI aggregate team stats')
    if raw.get('fixture_date')!=datetime.fromisoformat(match['kickoff'].replace('Z','+00:00')).date().isoformat():
        raise MarketError('GTS3 fixture date differs from kickoff calendar date in its declared timezone')
    if raw.get('season') != identity['season']:
        raise MarketError('GTS3 season mismatch')
    params,dparams=_native_source(model_parameters_path)
    if dparams != GTS3_FROZEN_PARAMETER_SHA256:
        raise MarketError('GTS3 RC1 frozen model parameter SHA256 mismatch')
    period=_required(raw.get('period_calibration'),'GTS3.period_calibration')
    conf=_obj(params.get(period),'GTS3 frozen model period')
    if raw.get('model_version')!='odh' or conf.get('name')!='odh':
        raise MarketError('Only frozen odh candidate is supported; no fallback')
    if raw['fixture_date']<=conf.get('training_max_date',''):
        raise MarketError('GTS3 scoring date not after frozen training end')
    features=conf.get('features')
    means=conf.get('scaler_mean')
    stds=conf.get('scaler_std')
    coefs=conf.get('glm_coefs')
    ref=conf.get('score_reference')
    if (features!=['O','D','H'] or not all(isinstance(a,list) and len(a)==3 for a in (means,stds,coefs))
          or not isinstance(ref,list) or not ref):
        raise MarketError('GTS3 frozen ODH parameter schema unsupported')
    for x in means+coefs+stds+ref:
        number(x,'frozen GTS3 parameter')
    if any(x<=0 for x in stds) or any(x<=0 for x in ref) or any(ref[i]>ref[i+1] for i in range(len(ref)-1)):
        raise MarketError('GTS3 invalid scaler or frozen reference')
    intercept=number(conf.get('glm_intercept'),'GTS3 intercept')
    rows=raw.get('predictions')
    if not isinstance(rows,list) or len(rows)!=2:
        raise MarketError('GTS3 must contain 2 team predictions')
    found={}
    for row in rows:
        _obj(row,'GTS3 prediction')
        side=row.get('venue')
        if side not in ('home','away') or side in found:
            raise MarketError('GTS3 invalid/duplicate venue')
        h,a=(ids['home'],ids['away']) if side=='home' else (ids['away'],ids['home'])
        if row.get('team_id')!=h or row.get('opponent_id')!=a:
            raise MarketError('GTS3 team/opponent ID mismatch')
        number(row.get('gts3_0_100_relative'),'GTS3 score',0,100)
        number(row.get('goals_intensity_research'),'GTS3 intensity',0,100)
        feats=_obj(row.get('features'),'GTS3 feature components')
        for k in ('O','D','H','Q','F'):number(feats.get(k),'GTS3 '+k)
        exponent=intercept+sum(coefs[i]*(feats[name]-means[i])/stds[i]
                                  for i,name in enumerate(features))
        if abs(exponent)>700:
            raise MarketError('GTS3 implausible native model exponent')
        lam=max(.02,min(8.,math.exp(exponent)))
        if abs(lam-row['goals_intensity_research'])>0.000051:
            raise MarketError('GTS3 NATIVE PARITY MISMATCH: goals intensity')
        score=100*(bisect.bisect_left(ref,lam)+bisect.bisect_right(ref,lam))/(2*len(ref))
        if abs(score-row['gts3_0_100_relative'])>0.000501:
            raise MarketError('GTS3 NATIVE PARITY MISMATCH: score rank')
        d=date.fromisoformat(row['latest_input_match_date'])
        if d+timedelta(days=2)>timestamp(match['cutoff']).date():
            raise MarketError('GTS3 historical date too recent for cutoff')
        for k in ('history_matches_team','history_matches_opponent','history_matches_team_at_venue'):
            number(row.get(k),'GTS3 '+k,0)
        if row['history_matches_team']<10 or row['history_matches_team_at_venue']<4:
            raise MarketError('GTS3 insufficient historical coverage')
        found[side]=row
    return {
        'release':'GTS3_RC1','contract':ADAPTER_VERSION,'source':'PitchAPI',
        'event_id':match['event_id'],'home':match['home'],'away':match['away'],
        'cutoff':match['cutoff'], 'source_artifact_sha256':digest,
        'validation_state':GTS3_NATIVE_STATUS,
        'native_schema_parity_verified':True,
        'source_snapshot_verified':False,
        'metrics':{
            'teams':{k:found[k] for k in ('home','away')},
            'model_version':raw['model_version'],'period_calibration':period,
            'frozen_model_sha256':dparams,
            'source_note':raw['source'],
            'interpretation':raw.get('interpretation'),
            'snapshot_is_true_prematch':False,
            'lambda_adjustment_allowed':False,
            'pitchapi_identity':identity.copy(),
        },
    }
