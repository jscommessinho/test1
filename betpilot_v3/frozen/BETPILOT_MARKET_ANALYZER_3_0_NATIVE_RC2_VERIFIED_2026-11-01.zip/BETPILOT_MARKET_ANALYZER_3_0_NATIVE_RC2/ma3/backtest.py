"""Observed-outcome backtesting. Requires genuinely timestamped historical data.

Input JSON list of {"input": MA3 input, "actual_home": int, "actual_away": int,
"outcome_observed_at": timezone-aware ISO8601}. There are no bundled live
history claims. Scores from AFTER cutoff are used only to grade frozen forecasts.
"""
from __future__ import annotations
import math
from collections import defaultdict
from datetime import timedelta
from .core import analyze, MarketError, settle_result, timestamp

PROB_FLOOR=1e-15

def _score(y,p):
    p=max(PROB_FLOOR,min(1-PROB_FLOOR,p))
    return {'brier':(p-y)**2, 'log_loss':-(y*math.log(p)+(1-y)*math.log1p(-p))}

def validate_history(records):
    if not isinstance(records,list) or not records:
        raise MarketError('Historical validation requires at least one real, independent record')
    seen=set()
    bymarket=defaultdict(list)
    per_match=defaultdict(list)
    for item in records:
        if not isinstance(item,dict) or not isinstance(item.get('input'),dict): raise MarketError('Invalid history row')
        i=item['input']; match=i['match']; event=match['event_id']
        if event in seen: raise MarketError('Duplicate historical event; do not count same match twice')
        seen.add(event)
        h,a=item.get('actual_home'),item.get('actual_away')
        if any(isinstance(x,bool) or not isinstance(x,int) or not 0<=x<=100 for x in (h,a)):
            raise MarketError('Invalid observed match score')
        if timestamp(item.get('outcome_observed_at'),'outcome time') < timestamp(match['kickoff']) + timedelta(minutes=90):
            raise MarketError('Full-time outcome timestamp precedes minimum regular match duration')
        report=analyze(i)
        for row in report['markets']:
            if row['technical_status']!='VALID': continue
            label=int(settle_result(row['market_id'],h,a)=='full_win')
            model=_score(label,row['model_probability']) if row['model_probability'] is not None else None
            bprob=row['bookmaker_probability']
            book=_score(label,bprob) if model is not None and bprob is not None else None
            rowdata={'event_id':event,'model':model,'bookmaker':book,
                     'realized_profit_per_unit':None}
            if row['odds'] is not None:
                settle=settle_result(row['market_id'],h,a)
                rowdata['realized_profit_per_unit']={
                  'full_win':row['odds']-1,'half_win':(row['odds']-1)/2,
                  'push':0,'half_loss':-.5,'full_loss':-1}[settle]
            bymarket[row['market_id']].append(rowdata)
            if model is not None: per_match[event].append(model['brier'])
    results={}
    for mid,rows in bymarket.items():
        binary=[r for r in rows if r['model'] is not None]
        b=[r for r in binary if r['bookmaker'] is not None]
        prices=[r['realized_profit_per_unit'] for r in rows if r['realized_profit_per_unit'] is not None]
        results[mid]={
          'n_matches':len(rows), 'n_binary_probabilities':len(binary),
          'brier':sum(r['model']['brier'] for r in binary)/len(binary) if binary else None,
          'log_loss':sum(r['model']['log_loss'] for r in binary)/len(binary) if binary else None,
          'paired_n':len(b),
          'paired_model_brier':sum(r['model']['brier'] for r in b)/len(b) if b else None,
          'paired_bookmaker_brier':sum(r['bookmaker']['brier'] for r in b)/len(b) if b else None,
          'paired_model_log_loss':sum(r['model']['log_loss'] for r in b)/len(b) if b else None,
          'paired_bookmaker_log_loss':sum(r['bookmaker']['log_loss'] for r in b)/len(b) if b else None,
          'realized_roi_per_unit':sum(prices)/len(prices) if prices else None,
          'roi_n':len(prices)}
    return {'n_independent_events':len(seen),'markets':results,
      'event_macro_brier':sum(sum(r)/len(r) for r in per_match.values() if r)/sum(bool(r) for r in per_match.values()) if any(per_match.values()) else None,
      'warnings':['Results require externally verified real event/quote provenance.',
       'Event macro-average avoids treating markets from one match as independent events.',
       'No threshold for statistical or economic significance is implied by a positive observed ROI.',
       'Calibration, block bootstrap uncertainty, preregistered temporal holdout and selection-bias checks remain separate requirements.']}
