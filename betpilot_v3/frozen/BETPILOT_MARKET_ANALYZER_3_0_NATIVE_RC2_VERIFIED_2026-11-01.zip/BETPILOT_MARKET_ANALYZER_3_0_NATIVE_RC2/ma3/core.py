"""BETPILOT Market Analyzer 3.0 — independent market evaluation layer.

No model training, bookmaker calibration or betting decision. Uses external GA
probabilities and BA probabilities; calculations are deterministic. Stdlib only.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timezone
import math
import re
from typing import Any

VERSION = 'MA3-RESEARCH-20261101'
SETTLEMENT = ('full_win', 'half_win', 'push', 'half_loss', 'full_loss')
EPS = 1e-8

class MarketError(ValueError):
    pass

def number(v, label, lo=None, hi=None):
    if isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v):
        raise MarketError(f'{label}: non-finite or non-numeric')
    if lo is not None and v < lo or hi is not None and v > hi:
        raise MarketError(f'{label}: outside [{lo},{hi}]')
    return float(v)

def timestamp(v, label='timestamp'):
    if not isinstance(v, str) or not v:
        raise MarketError(f'{label}: missing')
    try:
        d = datetime.fromisoformat(v.replace('Z', '+00:00'))
    except ValueError as ex:
        raise MarketError(f'{label}: invalid ISO8601') from ex
    if d.tzinfo is None or d.utcoffset() is None:
        raise MarketError(f'{label}: timezone required')
    return d.astimezone(timezone.utc)

def market_parts(mid):
    if not isinstance(mid, str) or not re.fullmatch(r'(FT|HT|SH)\.[A-Z0-9_]+\..+', mid):
        raise MarketError(f'Unsupported identifier: {mid!r}')
    return mid.split('.')

def line_value(parts):
    try:
        line = float('.'.join(parts))
    except (ValueError, TypeError):
        raise MarketError('Invalid market line') from None
    if not math.isfinite(line) or abs(4 * line - round(4 * line)) > EPS:
        raise MarketError('Line must be finite and multiple of 0.25')
    return line

def legs(line):
    if round(line * 4) % 2:
        return (line - .25, line + .25)
    return (line,)

def settle_result(mid, h, a):
    """Return stake-weighted settlement category for a single correct score.

    Validates semantics at the score level. For 'COMBO', both component events
    must be binary; no multiplying independent marginals is permitted.
    """
    p = market_parts(mid)
    period, kind, args = p[0], p[1], p[2:]
    if kind == '1X2' and len(args) == 1 and args[0] in ('H','D','A'):
        got = 'H' if h > a else 'D' if h == a else 'A'
        return 'full_win' if got == args[0] else 'full_loss'
    if kind == 'DC' and len(args) == 1 and args[0] in ('1X','X2','12'):
        got = '1' if h > a else 'X' if h == a else '2'
        return 'full_win' if got in args[0] else 'full_loss'
    if kind == 'BTTS' and len(args) == 1 and args[0] in ('YES','NO'):
        v = h >= 1 and a >= 1
        return 'full_win' if v == (args[0] == 'YES') else 'full_loss'
    if kind == 'MULTIGOAL' and len(args) == 2:
        if not all(re.fullmatch(r'\d+', x) for x in args):
            raise MarketError('Invalid multigoal limits')
        lo, hi = map(int, args)
        if hi < lo: raise MarketError('Invalid multigoal interval')
        return 'full_win' if lo <= h + a <= hi else 'full_loss'
    if kind == 'CS' and len(args) == 2:
        if not all(re.fullmatch(r'\d+', x) for x in args):
            raise MarketError('Invalid correct score')
        return 'full_win' if (h, a) == tuple(map(int,args)) else 'full_loss'
    if kind == 'WIN_TO_NIL' and len(args) == 1 and args[0] in ('H','A'):
        win = (h > a and a == 0) if args[0] == 'H' else (a > h and h == 0)
        return 'full_win' if win else 'full_loss'
    if kind == 'EURO_AH' and len(args) == 2 and args[0] in ('H','D','A'):
        ln = line_value(args[1:])
        if not ln.is_integer(): raise MarketError('European handicap must be integral')
        delta = h + int(ln) - a
        got = 'H' if delta > 0 else 'D' if delta == 0 else 'A'
        return 'full_win' if got == args[0] else 'full_loss'
    if kind in ('DNB','AH'):
        if kind == 'DNB' and len(args) == 1 and args[0] in ('H','A'):
            side, ln = args[0], 0.
        elif kind == 'AH' and len(args) >= 2 and args[0] in ('H','A'):
            side, ln = args[0], line_value(args[1:])
        else:
            raise MarketError('Malformed handicap')
        raw = h - a if side == 'H' else a - h
        return _from_components([_component(raw + n) for n in legs(ln)])
    if kind in ('TOTAL','TOTAL_AH') and len(args) >= 2 and args[0] in ('OVER','UNDER'):
        ln = line_value(args[1:])
        if ln < 0: raise MarketError('Negative total-goals line')
        direction = 1 if args[0] == 'OVER' else -1
        return _from_components([_component((h + a - n) * direction) for n in legs(ln)])
    if kind == 'TEAM' and len(args) >= 3 and args[0] in ('H','A') and args[1] in ('OVER','UNDER'):
        ln = line_value(args[2:])
        if ln < 0: raise MarketError('Negative team total line')
        direction = 1 if args[1] == 'OVER' else -1
        n = h if args[0] == 'H' else a
        return _from_components([_component((n - x) * direction) for x in legs(ln)])
    if kind == 'COMBO':
        raw = mid[len(period + '.COMBO.'):]
        two = raw.split('&')
        if len(two) != 2 or not all(x.startswith(period + '.') for x in two) or any('.COMBO.' in x for x in two):
            raise MarketError('COMBO requires two non-nested same-period legs')
        if not all(is_binary(x) for x in two):
            raise MarketError('COMBO components must be binary')
        return 'full_win' if all(settle_result(x,h,a) == 'full_win' for x in two) else 'full_loss'
    raise MarketError(f'Unsupported market {mid}')

def _component(x):
    return 1 if x > EPS else -1 if x < -EPS else 0

def _from_components(xs):
    return {1:'full_win',.5:'half_win',0:'push',-.5:'half_loss',-1:'full_loss'}[sum(xs)/len(xs)]

def is_binary(mid):
    # Settlement logic on arbitrary scores catches a quarter line, push, etc.
    # Line-specific structural check avoids accidentally assessing finite scores only.
    p = market_parts(mid)
    k, args = p[1],p[2:]
    if k == 'DNB': return False
    if k == 'AH': return len(args) >= 2 and line_value(args[1:]) % 1 == .5
    if k in ('TOTAL','TOTAL_AH'): return len(args) >= 2 and line_value(args[1:]) % 1 == .5
    if k == 'TEAM': return len(args) >= 3 and line_value(args[2:]) % 1 == .5
    if k == 'COMBO':
        a = mid[len(p[0]+'.COMBO.'):].split('&')
        return len(a) == 2 and all('.COMBO.' not in x and is_binary(x) for x in a)
    # Check syntax: a market that fails on 0-0 must not be accepted.
    settle_result(mid,0,0)
    return True

def load_matrix(scorelines):
    if not isinstance(scorelines, list) or not scorelines:
        raise MarketError('Nonempty scorelines list required')
    matrix={}
    for s in scorelines:
        if not isinstance(s, dict): raise MarketError('Invalid scoreline record')
        h,a = s.get('home_goals'),s.get('away_goals')
        if any(isinstance(v,bool) or not isinstance(v,int) or not 0 <= v <= 100 for v in (h,a)):
            raise MarketError('Invalid scoreline coordinates')
        p=number(s.get('probability'),'scoreline probability',0,1)
        if (h,a) in matrix: raise MarketError('Duplicate scoreline')
        matrix[h,a]=p
    total=math.fsum(matrix.values())
    if abs(total-1) > EPS: raise MarketError(f'Scoreline mass must be 1 within {EPS}; got {total:.12g}')
    # Numerical rounding only; no renormalization or invented tail.
    return matrix

def market_from_matrix(mid, matrix):
    buckets=defaultdict(float)
    for (h,a),prob in matrix.items(): buckets[settle_result(mid,h,a)] += prob
    v={key:math.fsum([buckets[key]]) for key in SETTLEMENT}
    binary=is_binary(mid)
    if binary and (v['push'] + v['half_win'] + v['half_loss'] > EPS):
        raise MarketError('Binary market produced non-binary settlement')
    v.update({'binary':binary, 'p_event':v['full_win'] if binary else None,
              'p_positive_return':v['full_win']+v['half_win'],
              'p_non_negative_return':v['full_win']+v['half_win']+v['push'],
              'p_any_loss':v['full_loss']+v['half_loss']})
    return v

def fair_odds(dist):
    """Settlement-adjusted theoretical break-even decimal odds, price-independent."""
    w=dist['full_win']+.5*dist['half_win']
    loss=dist['full_loss']+.5*dist['half_loss']
    return 1+loss/w if w>0 else None

def payoffs(dist, odds):
    """Asian and DNB payoff with decimal odds applied to each half-stake leg."""
    o=number(odds,'decimal odds')
    if o<=1: raise MarketError('decimal odds must be > 1')
    w=dist['full_win']+.5*dist['half_win']
    loss=dist['full_loss']+.5*dist['half_loss']
    fair=fair_odds(dist)
    ev=(o-1)*w-loss
    return {'expected_profit_per_unit':ev, 'fair_odds':fair, 'breakeven_odds':fair,
            'win_stake_equivalent':w, 'loss_stake_equivalent':loss}

def _validate_data(data):
    if not isinstance(data,dict): raise MarketError('Root must be JSON object')
    match=data.get('match')
    if not isinstance(match,dict): raise MarketError('match is required')
    for k in ('event_id','home','away','competition','kickoff','cutoff'):
        if not isinstance(match.get(k),str) or not match[k].strip(): raise MarketError('Missing match.'+k)
    cutoff=timestamp(match['cutoff'],'match.cutoff')
    kickoff=timestamp(match['kickoff'],'match.kickoff')
    if not cutoff < kickoff: raise MarketError('cutoff must precede kickoff')
    if match.get('duration_minutes',90)!=90 or match.get('format','association_football')!='association_football':
        raise MarketError('Non-standard association football excluded')
    quotes={}
    for q in data.get('quotes',[]):
        if not isinstance(q,dict): raise MarketError('Invalid quote record')
        mid=q.get('market_id')
        market_parts(mid)
        if mid in quotes: raise MarketError('Duplicate quote market; select snapshot upstream')
        number(q.get('decimal_odds'),'quote decimal odds')
        if q['decimal_odds']<=1: raise MarketError('Odds must be > 1')
        if not isinstance(q.get('source'),str) or not q['source']: raise MarketError('Quote source required')
        qt=timestamp(q.get('timestamp'),'quote timestamp')
        if q.get('provenance')=='VERIFIED_EXTERNAL_SNAPSHOT' and not q.get('external_capture_reference'):
            raise MarketError('Claimed externally verified quote requires capture reference')
        if qt>cutoff: raise MarketError('Future quote (after cutoff)')
        quotes[mid]=q
    model=data.get('probability_model')
    if model is not None:
        if not isinstance(model,dict) or not model.get('version') or not model.get('source'):
            raise MarketError('Model source/version required')
        if not isinstance(model.get('event_id'),str) or not model['event_id']:
            raise MarketError('Model event_id required for fixture identity')
        if timestamp(model.get('cutoff'),'model cutoff')>cutoff:
            raise MarketError('Future model (after cutoff)')
        if model.get('event_id') and model['event_id'] != match['event_id']:
            raise MarketError('Model event_id mismatch')
        if not isinstance(model.get('periods',{}),dict) or not isinstance(model.get('event_probabilities',{}),dict) or not isinstance(model.get('settlement_probabilities',{}),dict):
            raise MarketError('Model period/event/settlement collections must be objects')
        for p, spec in model.get('periods',{}).items():
            if p not in ('FT','HT','SH') or not isinstance(spec,dict): raise MarketError('Invalid model period')
            if 'scorelines' in spec: load_matrix(spec['scorelines'])
        for mid,prob in model.get('event_probabilities',{}).items():
            if not is_binary(mid): raise MarketError('Direct event_probability must be binary')
            number(prob,mid,0,1)
        for mid,d in model.get('settlement_probabilities',{}).items():
            market_parts(mid)
            if not isinstance(d,dict) or set(d)-set(SETTLEMENT): raise MarketError('Invalid settlement vector')
            for k in SETTLEMENT: number(d.get(k,0),k,0,1)
            if abs(math.fsum(d.values())-1)>EPS: raise MarketError('Settlement probability mass != 1')
            if is_binary(mid) and sum(d.get(k,0) for k in ('half_win','push','half_loss'))>EPS:
                raise MarketError('Binary market cannot contain push/half-settlement states')
    book=data.get('bookmaker_analyzer')
    if book is not None:
        if not isinstance(book,dict) or not book.get('protocol') or not book.get('source'):
            raise MarketError('Bookmaker Analyzer protocol/source required')
        if timestamp(book.get('timestamp'),'BA timestamp')>cutoff: raise MarketError('Future BA output')
        if not book.get('probability_method'):
            book=dict(book,probability_method='UNSPECIFIED_NOT_VERIFIED')
        for mid,p in book.get('market_probabilities',{}).items():
            if not is_binary(mid):
                raise MarketError('BA direct probability requires binary market')
            number(p,'BA probability',0,1)
    requested=data.get('requested_markets')
    if requested is None: requested=list(dict.fromkeys(list(quotes)+list((model or {}).get('event_probabilities',{}))))
    if not isinstance(requested,list) or any(not isinstance(k,str) for k in requested) or len(set(requested))!=len(requested):
        raise MarketError('requested_markets must be unique list of identifiers')
    return match, cutoff, quotes, model, book, requested

def _coherence(model):
    """Checks exclusively on declared direct marginal probabilities; no score tuning."""
    if not model: return []
    p=model.get('event_probabilities',{})
    issues=[]
    for period in ('FT','HT','SH'):
        triples = [[f'{period}.1X2.{s}' for s in ('H','D','A')],
                   [f'{period}.BTTS.{s}' for s in ('YES','NO')]]
        for group in triples:
            if all(k in p for k in group) and abs(math.fsum(p[k] for k in group)-1)>EPS:
                issues.append({'type':'MARGINAL_PARTITION', 'markets':group})
        overs=[]
        for k in p:
            m=re.fullmatch(re.escape(period)+r'\.TOTAL\.OVER\.(\d+\.5)',k)
            if m: overs.append((float(m.group(1)),k))
        overs.sort()
        for (_,lo),(_,hi) in zip(overs,overs[1:]):
            if p[hi] > p[lo]+EPS: issues.append({'type':'MONOTONICITY','markets':[lo,hi]})
        gg=f'{period}.BTTS.YES'; ov=f'{period}.TOTAL.OVER.1.5'
        if gg in p and ov in p and p[gg]>p[ov]+EPS:
            issues.append({'type':'SUBSET','markets':[gg,ov]})
    for period,spec in model.get('periods',{}).items():
        if 'scorelines' not in spec: continue
        matrix=load_matrix(spec['scorelines'])
        for mid,prob in p.items():
            if mid.startswith(period+'.'):
                calculated=market_from_matrix(mid,matrix)['p_event']
                if calculated is not None and abs(calculated-prob)>EPS:
                    issues.append({'type':'MATRIX_VS_MARGINAL','markets':[mid],
                                   'difference':calculated-prob})
    return issues

def analyze(data:dict[str,Any])->dict[str,Any]:
    match,cutoff,quotes,model,book,requested=_validate_data(data)
    coherence=_coherence(model)
    invalid_set={k for issue in coherence for k in issue['markets']}
    matrices={k:load_matrix(v['scorelines']) for k,v in (model or {}).get('periods',{}).items() if 'scorelines' in v}
    bps=(book or {}).get('market_probabilities',{})
    booktime=timestamp(book['timestamp']) if book else None
    rows=[]
    for mid in requested:
        q=quotes.get(mid)
        row={'market_id':mid,'technical_status':None,'value_status':'NOT_ASSESSED',
             'odds':q['decimal_odds'] if q else None,
             'raw_implied_probability':1/q['decimal_odds'] if q else None,
             'quote_source':q['source'] if q else None,
             'quote_provenance':q.get('provenance','NOT_VERIFIED') if q else None,
             'quote_age_minutes':(cutoff-timestamp(q['timestamp'])).total_seconds()/60 if q else None,
             'model_probability':None,'bookmaker_probability':None,'bookmaker_method':None,
             'difference_pp':None,'fair_odds':None,'expected_profit_per_unit':None,
             'settlement_probabilities':None,'reliability': 'NOT_CALIBRATED',
             'limitations':[], 'risk_description':None, 'probability_basis':None}
        try:
            p=market_parts(mid)
            binary=is_binary(mid)
            # Syntax validation for quote-only data, incl invalid unsupported combo.
            settle_result(mid,0,0)
            period=p[0]
            if mid in invalid_set:
                row['technical_status']='INCONSISTENT_INPUT'
                row['limitations'].append('Conflicting model marginal probabilities / scoreline distribution')
            else:
                if period in matrices:
                    dist=market_from_matrix(mid,matrices[period])
                    row['probability_basis']='UPSTREAM_JOINT_SCORE_DISTRIBUTION'
                elif model and mid in model.get('settlement_probabilities',{}):
                    b=model['settlement_probabilities'][mid]
                    dist={key:float(b.get(key,0)) for key in SETTLEMENT}
                    dist.update({'binary':binary,'p_event':dist['full_win'] if binary else None})
                    row['probability_basis']='UPSTREAM_SETTLEMENT_VECTOR'
                elif binary and model and mid in model.get('event_probabilities',{}):
                    prob=model['event_probabilities'][mid]
                    dist={key: (prob if key=='full_win' else 1-prob if key=='full_loss' else 0) for key in SETTLEMENT}
                    dist.update({'binary':True,'p_event':prob})
                    row['probability_basis']='UPSTREAM_EVENT_PROBABILITY'
                else: dist=None
                if dist:
                    if abs(math.fsum(dist[k] for k in SETTLEMENT)-1)>EPS:
                        raise MarketError('Invalid source probability mass')
                    row['technical_status']='VALID'
                    row['settlement_probabilities']={k:dist[k] for k in SETTLEMENT}
                    row['model_probability']=dist['p_event']
                    row['fair_odds']=fair_odds(dist)
                    row['risk_description']='BINARY' if binary else 'MULTI_OUTCOME_SETTLEMENT'
                    if q:
                        payoff=payoffs(dist,q['decimal_odds'])
                        row.update({k:payoff[k] for k in ('fair_odds','expected_profit_per_unit')})
                        row['value_status']=('POSITIVE_MODEL_EV_UNVALIDATED' if payoff['expected_profit_per_unit']>EPS
                           else 'NO_DEMONSTRABLE_EDGE')
                    else:
                        row['limitations'].append('No offered price; cannot compute economic value')
                    if not model.get('validation_evidence'):
                        row['limitations'].append('Independent out-of-sample model calibration not evidenced')
                else:
                    row['technical_status']='INSUFFICIENT_DATA' if model else 'BOOKMAKER_ONLY'
                    row['limitations'].append('No model event probability / settlement vector / period score matrix')
            if mid in bps:
                if book and q and q['source']!=book['source']:
                    row['limitations'].append('BA source differs from quote source')
                elif q and booktime!=timestamp(q['timestamp']):
                    row['limitations'].append('BA and quote not synchronized at exact timestamp')
                else:
                    row['bookmaker_probability']=bps[mid]
                    row['bookmaker_method']=book.get('probability_method','UNSPECIFIED')
            if row['model_probability'] is not None and row['bookmaker_probability'] is not None:
                row['difference_pp']=100*(row['model_probability']-row['bookmaker_probability'])
            if q and q.get('provenance') != 'VERIFIED_EXTERNAL_SNAPSHOT':
                row['limitations'].append('Price provenance unverified or synthetic')
            elif q:
                row['limitations'].append('External capture reference supplied but not independently authenticated by MA3')
            if row['technical_status']=='VALID' and not q:
                row['value_status']='NO_QUOTE'
            # An externally declared validation label is not treated as independent proof.
            if model and model.get('validation_evidence'):
                row['limitations'].append('External validation evidence declared, not independently audited by MA3')
        except (MarketError,ValueError) as ex:
            row['technical_status']='UNSUPPORTED_MARKET'
            row['limitations'].append(str(ex))
        rows.append(row)
    def rank(key, condition=lambda r:True, descending=True):
        subset=[r for r in rows if condition(r) and r[key] is not None]
        return [r['market_id'] for r in sorted(subset,key=lambda r:(-r[key] if descending else r[key],r['market_id']))]
    rankings={
      'probability':rank('model_probability',lambda r:r['technical_status']=='VALID'),
      'reliability':[], # Not calibrated, therefore not rankable.
      'positive_probability_difference_pp':rank('difference_pp',lambda r:r['technical_status']=='VALID'),
      'model_ev':rank('expected_profit_per_unit',lambda r:r['technical_status']=='VALID'),
      'market_quality':None}
    return {'protocol':VERSION,'match':match,'mode':'MODEL_AND_BOOKMAKER' if model and (quotes or book) else
      'MODEL_ONLY' if model else 'BOOKMAKER_ONLY' if (quotes or book) else 'NO_INPUT',
      'model_version':model.get('version') if model else None,
      'model_source':model.get('source') if model else None,
      'bookmaker_protocol':book.get('protocol') if book else None,
      'bookmaker_diagnostics':({'source':book['source'],'timestamp':book['timestamp'],
         'probability_method':book.get('probability_method','UNSPECIFIED_NOT_VERIFIED'),
         'validation_state':book.get('validation_state'),
         'market_stability':book.get('market_stability'),
         'scenario_intelligence':book.get('scenario_intelligence'),
         'confidence':book.get('confidence'),
         'pricing_groups':book.get('pricing_groups'),
         'interpretation':'Passthrough of upstream Bookmaker Analyzer. NOT an independent confirmation.'}
         if book else None),
      'model_validation_declared':model.get('validation_state','NOT_PROVIDED') if model else None,
      'operational_eligible':False,'betting_recommendation':None,'final_selection':None,
      'rankings':rankings,'markets':rows,'coherence_issues':coherence,
      'selection_status':'ABSTAIN_NOT_INDEPENDENTLY_VALIDATED',
      'notes':['BA and its own odds are not independent evidence',
       'Positive model EV is not a demonstrated edge or guaranteed profit',
       'No bookmaker no-vig calculations are duplicated: consumes bookmaker probabilities from BA',
       'Reliability cannot be scored without external independent calibration',
       'An omitted price is never invented; a bookmaker-only probability is not a Goal Analyzer forecast']}
