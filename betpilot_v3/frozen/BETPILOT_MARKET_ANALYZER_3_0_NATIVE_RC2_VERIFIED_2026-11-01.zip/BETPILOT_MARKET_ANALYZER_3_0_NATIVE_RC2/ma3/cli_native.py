"""Real GA3 RC2 and GTS3 RC1 output artifacts + native RC15 corrected, read-only.

Use native GA3 CLI and GTS3 score separately with legitimate PitchAPI histories.
This CLI verifies their output contracts; it never manufactures probabilities or odds.
"""
import argparse
import json
from pathlib import Path
from .core import MarketError
from .native_exports import export_ga3,export_gts3
from .runtime import json_read, run_pipeline, verify_source_file


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('match','identity','ga3-native','gts3-native','gts3-parameters','rc15-input','output-dir'):
        parser.add_argument('--'+key,required=True,type=Path)
    parser.add_argument('--requested-markets',nargs='*',default=None)
    args=parser.parse_args(argv)
    m=json_read(args.match)
    identity=json_read(args.identity)
    ga=export_ga3(args.ga3_native,m,identity)
    gts=export_gts3(args.gts3_native,m,identity,args.gts3_parameters)
    verify_source_file(ga,args.ga3_native,'GA3')
    verify_source_file(gts,args.gts3_native,'GTS3')
    # Live archive provenance is explicitly NOT guaranteed by the source engines.
    output=run_pipeline(m,ga,gts,json_read(args.rc15_input),args.output_dir,
                        requested_markets=args.requested_markets,native_parity_verified=True)
    for name, obj in (('GA3_NORMALIZED.json',ga),('GTS3_NORMALIZED.json',gts)):
        (args.output_dir/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':'NATIVE_SCHEMAS_VERIFIED_RESEARCH_ONLY',
         'analyzed_markets':len(output['market_analyzer']['markets']),
         'output_directory':str(args.output_dir),
         'operational_eligible':False},indent=2))

if __name__=='__main__':main()
