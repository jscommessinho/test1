# BETPILOT | MARKET ANALYZER 3.0 — NATIVE INTEGRATION RC2

**1 novembre 2026 · Versione integrata e testata in modalità ricerca**

## Esito

- **GA3 RC2 nativo**: parser e parità numerica della matrice di probabilità verificati.
- **GTS3 RC1 nativo**: parser, squadra/sede, storico e componenti descrittive verificati.
- **Bookmaker Analyzer RC15 + Verdetto C**: motore originale eseguito sul repository GitHub, report corretto nativo ricevuto e consumato senza eseguire MA2/GA2.
- **Market Analyzer 3.0**: 47 mercati restituiti nell'esempio sintetico; output `MA3_ANALYSIS.json` e `BETANALYZER_HANDOFF.json` riproducibili.
- Nessuno dei tre motori sorgente è stato modificato. Nessuna calibratura o pricing sono cambiati.

## Topologia

```text
                  PITCHAPI
                  /      \
          GA3 RC2       GTS3 RC1
            |              |
    native exact_scores   native predictions
            |              |
     ma3.native_exports (strict, source-hashed, no numeric fusion)
                  \      /
           MARKET ANALYZER 3.0  <---- RC15 + VERDETTO C <---- BET365
                   |
         MA3_ANALYSIS.json
         BETANALYZER_HANDOFF.json  --> BetAnalyzer decision engine (consumer native da aggiornare)
```

## File principali

- `ma3/native_exports.py`: adapter **reali** GA3 RC2 e GTS3 RC1 per output JSON nativi. Nessun fallback GA2.
- `ma3/cli_native.py`: ingresso unico per GA3/GTS3 nativi + RC15 + Verdetto C.
- `ma3/runtime.py`: esecuzione RC15 corretta, Market Analyzer 3.0, handoff a BetAnalyzer, audit SHA256.
- `ma3/core.py`: distribuzioni, settlement e analisi dei mercati. Non importa i modelli sorgente.
- `tests/`: prove matematiche, adapter, identità, leak temporale, regressioni, isolamento.
- `examples/native_synthetic/`: fixture **inventata**, storico inventato, output generati dai moduli GA3/GTS3 originali e output corretto RC15 prodotto da GitHub; non quote reali.
- `docs/NATIVE_INTEGRATION_AUDIT_RC2.md`: audit puntuale, controlli, limiti.

## Esempio integrato riproducibile, senza credenziali

Dalla radice dell'archivio:

```bash
python -m unittest discover -s tests -q
python -m examples.replay_three_native_sources \
  --bookmaker-bridge examples/native_synthetic/rc15_native_verdict_c_bridge.json \
  --output-dir replay-output
```

Per ricreare gli output GA3/GTS3 da zero serve il codice **originale** nei due ZIP separati (mai modificarli); vedere `docs/NATIVE_INTEGRATION_AUDIT_RC2.md`. Il replay integrato distribuito **usa direttamente output generati da quel codice originale**, non ricostruzioni MA3 delle stime.

## Esecuzione su output nativi GA3 RC2 e GTS3 RC1

Posizionare `ma3/` come **pacchetto autonomo** nella root del repository `betpilot-prematch-analyzer`, lasciando inalterati `betpilot/` e `vendor/`.

Prima, produrre i JSON nativi con gli entrypoint originali e dati PitchAPI validati. Per il bookmaker occorrono sette quote Bet365 effettivamente raccolte e un cutoff prematch.

```bash
python -m ma3.cli_native \
  --match MATCH.json \
  --identity PITCHAPI_IDENTITY_VERIFIED.json \
  --ga3-native GA3_PREDICT_NATIVE.json \
  --gts3-native GTS3_SCORE_NATIVE.json \
  --gts3-parameters GTS3_FROZEN_SELECTED_MODEL_PARAMETERS.json \
  --rc15-input RC15_EVENT_INPUT.json \
  --output-dir MA3_RESULTS
```

`--identity` richiede: `league_id`, `home_team_id`, `away_team_id`, `season`, `identity_reference`, `identity_provenance` tra `EXTERNAL_VERIFIED`, `USER_SUPPLIED_UNVERIFIED`, `SYNTHETIC_TEST`.

Il sistema rifiuta timestamp GA3 successivi al cutoff, ID discordanti, fixture/date/season GTS discordanti, modifiche di probabilità e claim erronei di dati prematch certificati. Il suo output resta sempre `RESEARCH_ONLY` e `operational_eligible=false`.

**Nota:** il wrapper corretto `betpilot/bookmaker_verdict_c.py` viene invocato limitatamente al motore RC15 (`native_rc15` + correzioni C-01/C-02). La pipeline legacy `Step5.run_full` che usa GA2/MA2 non viene eseguita.

## Stato onesto

**Integrazione nativa completa dei tre output: PASS, su fixture sintetica**. **Autorizzazione per selezione scommesse: NO.** **Produttività della previsione su partite vere: NON VALIDATA.** **Decisione BetAnalyzer nativo: ancora da migrare a questa nuova interfaccia**, benché il JSON di handoff sia già prodotto.

## Contratto BetAnalyzer e verifiche

`python -m ma3.betanalyzer_contract replay-output/BETANALYZER_HANDOFF.json --output replay-output/BETANALYZER_INTAKE_AUDIT.json` controlla che i dati MA3 siano pronti ad essere consegnati come input, **senza eseguire il vecchio decision engine**. I moduli GA3/GTS3 sono in modalità ricerca; neppure un EV positivo in un esempio sintetico autorizza una scommessa.

La verifica del modello GTS RC1 include parità del GLM `odh`, controllo rango ECDF con lo `score_reference` congelato e verifica SHA256 dei parametri originali.
