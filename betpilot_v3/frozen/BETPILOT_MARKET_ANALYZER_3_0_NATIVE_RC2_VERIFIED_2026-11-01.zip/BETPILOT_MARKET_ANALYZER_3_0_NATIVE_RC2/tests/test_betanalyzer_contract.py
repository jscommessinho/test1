"""Intake validation is not an automated betting pick."""
import copy,json
from pathlib import Path
import unittest
from ma3.betanalyzer_contract import accept_handoff
from ma3.core import MarketError
ROOT=Path(__file__).resolve().parents[1]
P=json.loads((ROOT/'examples/native_synthetic/full_native_replay/BETANALYZER_HANDOFF.json').read_text())
class HandoffContract(unittest.TestCase):
    def test_actual_native_triplet_handoff(self):
        r=accept_handoff(copy.deepcopy(P))
        self.assertEqual(r['markets'],47)
        self.assertEqual(r['markets_with_offered_odds'],7)
        self.assertFalse(r['betting_authorized'])
    def test_no_stake_authorized(self):
        q=copy.deepcopy(P);q['stake']=2
        with self.assertRaises(MarketError):accept_handoff(q)
    def test_no_final_selection(self):
        q=copy.deepcopy(P);q['final_selection']='FT.BTTS.YES'
        with self.assertRaises(MarketError):accept_handoff(q)
    def test_reject_duplicated_market(self):
        q=copy.deepcopy(P);q['markets'].append(copy.deepcopy(q['markets'][0]))
        with self.assertRaises(MarketError):accept_handoff(q)
    def test_reject_unverified_native_inputs(self):
        q=copy.deepcopy(P);q['upstream']['native_ga3_gts3_parity_verified']=False
        with self.assertRaises(MarketError):accept_handoff(q)
    def test_reject_fused_gts(self):
        q=copy.deepcopy(P);q['gts3_descriptive']['numeric_fusion_with_ga3']=True
        with self.assertRaises(MarketError):accept_handoff(q)
    def test_reject_fake_betanalyzer_engine_claim(self):
        q=copy.deepcopy(P);q['native_betanalyzer_integration_verified']=True
        with self.assertRaises(MarketError):accept_handoff(q)
if __name__=='__main__':unittest.main()
