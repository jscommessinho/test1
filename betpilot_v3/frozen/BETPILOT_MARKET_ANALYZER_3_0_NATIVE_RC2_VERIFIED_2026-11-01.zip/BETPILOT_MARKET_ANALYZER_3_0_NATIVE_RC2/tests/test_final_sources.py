"""Synthetic contract & safety tests; NOT empirical GA3/GTS3 parity validation."""
import copy
import json
import unittest
from ma3.core import MarketError
from ma3.final_sources import analyze_final_sources, from_final_sources, ADAPTER_VERSION

NOW='2026-11-01T10:00:00+00:00'
KICK='2026-11-01T15:00:00+00:00'
FUTURE='2026-11-01T16:30:00+00:00'
MATRIX=[{'home_goals':h,'away_goals':a,'probability':p} for h,a,p in (
(0,0,.1),(1,0,.25),(0,1,.15),(1,1,.2),(2,0,.15),(0,2,.15))]


def fixture():
    m={'event_id':'SYNTHETIC-001','home':'Sample Home','away':'Sample Away',
       'competition':'Italy Serie A 2026','kickoff':KICK,'cutoff':NOW}
    mapping={'source':m['competition'],'engine':'Italy Serie A','applied':True,
        'preserved_external_event_identity':True}
    mismatch=['1','X','2','Over_2_5','Under_2_5']
    return {'match':m,
        'ga3_rc2':{'contract':ADAPTER_VERSION,'release':'GA3_RC2', 'source':'PitchAPI',
            'event_id':m['event_id'],'home':m['home'],'away':m['away'],'cutoff':NOW,
            'source_artifact_sha256':'a'*64,'scorelines':copy.deepcopy(MATRIX),
            'validation_state':'SYNTHETIC_TEST_ONLY'},
        'gts3_rc1':{'contract':ADAPTER_VERSION,'release':'GTS3_RC1', 'source':'PitchAPI',
            'event_id':m['event_id'],'home':m['home'],'away':m['away'],'cutoff':NOW,
            'source_artifact_sha256':'b'*64,'metrics':{'offensive_threat':{'home':68,'away':41},
            'defensive_vulnerability':{'home':44,'away':72},'descriptive_note':'synthetic'},
            'validation_state':'SYNTHETIC_TEST_ONLY'},
        'bookmaker_rc15_verdict_c':{
            'verdict_c_audit':{'schema':'BETPILOT_BOOKMAKER_VERDICT_C_V1',
                'competition_mapping':mapping,'unavailable_reference_events':mismatch,
                'coefficients_changed':False,'prospective_prediction_validated':False},
            'rc15_report':{'identity':{'home':m['home'],'away':m['away'],'league':'Italy Serie A'},
                'data_quality':{'verdict_c_competition_mapping':mapping,
                    'verdict_c_reference_mismatches':mismatch},
                'historical_support':{k:{'n':None,'mean_prediction':None,
                    'observed_frequency':None,'bias_pp':None,
                    'support_level':'UNAVAILABLE_REFERENCE_MISMATCH'} for k in mismatch},
                'single_market_probabilities_RC12_experimental':{
                    '1X2':{'method':'direct','p':{'1':.4,'X':.3,'2':.3,'1X':.7,'X2':.6,'12':.7}},
                    'OU2_5':{'method':'direct','p':{'Over_2_5':.5,'Under_2_5':.5}},
                    'BTTS':{'method':'RC11.2','p':{'GG':.5,'NG':.5}}},
                'bise_structural':{'fake':'fixture'},
                'optional_market_diagnostics':{}},
            'quotes':[{'market_id':mid,'decimal_odds':odd,'timestamp':NOW,
                'snapshot_id':'SYNTHETIC-SNAPSHOT','source':'Bet365','provenance':'SYNTHETIC'} for mid,odd in [
                ('FT.BTTS.YES',2.10),('FT.1X2.H',2.50),('FT.1X2.D',3.30),('FT.1X2.A',3.30)]]},
        'requested_markets':['FT.1X2.H','FT.BTTS.YES','FT.COMBO.FT.BTTS.YES&FT.TOTAL.OVER.1.5']}

class FinalSourceIntegration(unittest.TestCase):
    def test_full_readonly_normalized(self):
        x=fixture(); before=copy.deepcopy(x)
        r=analyze_final_sources(x)
        self.assertEqual(x,before)
        self.assertEqual(r['final_sources_adapter'],ADAPTER_VERSION)
        self.assertFalse(r['operational_eligible'])
        self.assertIsNone(r['betting_recommendation'])
        self.assertIsNone(r['final_selection'])
        self.assertEqual(r['bookmaker_protocol'],'RC15+VERDICT_C')
        self.assertEqual(r['model_source'],'PitchAPI')
        self.assertEqual(r['gts3_descriptive']['metrics'],x['gts3_rc1']['metrics'])
        self.assertFalse(r['gts3_descriptive']['numeric_fusion_with_ga3'])
        p1=r['markets'][0]
        self.assertAlmostEqual(p1['model_probability'],.40)
        self.assertAlmostEqual(p1['bookmaker_probability'],.4)
        self.assertAlmostEqual(p1['difference_pp'],0)
        combo=r['markets'][2]
        self.assertEqual(combo['technical_status'],'VALID')
        self.assertAlmostEqual(combo['model_probability'],.20)
        self.assertFalse(r['upstream_status']['native_ga3_gts3_parity_verified'])
    def test_gts_cannot_change_probability(self):
        a=fixture();b=copy.deepcopy(a)
        b['gts3_rc1']['metrics']['offensive_threat']={'home':0,'away':100}
        ra=analyze_final_sources(a);rb=analyze_final_sources(b)
        self.assertEqual([(p['market_id'],p['model_probability']) for p in ra['markets']],
                         [(p['market_id'],p['model_probability']) for p in rb['markets']])
    def test_different_teams_rejected(self):
        x=fixture();x['gts3_rc1']['away']='Opponent Swap'
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_ga2_rejected(self):
        x=fixture();x['ga3_rc2']['release']='GA2-RESEARCH-20261029-v1'
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_no_ga3_rejected(self):
        x=fixture(); del x['ga3_rc2']
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_no_gts_rejected(self):
        x=fixture();del x['gts3_rc1']
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_no_verdict_rejected(self):
        x=fixture();x['bookmaker_rc15_verdict_c'].pop('verdict_c_audit')
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_unmasked_bin_rejected(self):
        x=fixture();x['bookmaker_rc15_verdict_c']['rc15_report']['historical_support']['1']['n']=550
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_wrong_verdict_competition_mapping_rejected(self):
        x=fixture();x['bookmaker_rc15_verdict_c']['verdict_c_audit']['competition_mapping']['source']='Brazil Serie A'
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_unpatched_rc15_rejected(self):
        x=fixture();del x['bookmaker_rc15_verdict_c']['rc15_report']['data_quality']['verdict_c_reference_mismatches']
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_future_ga_rejected(self):
        x=fixture();x['ga3_rc2']['cutoff']=FUTURE
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_future_gts_rejected(self):
        x=fixture();x['gts3_rc1']['cutoff']=FUTURE
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_future_quote_rejected(self):
        x=fixture();x['bookmaker_rc15_verdict_c']['quotes'][0]['timestamp']=FUTURE
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_async_quote_rejected(self):
        x=fixture();x['bookmaker_rc15_verdict_c']['quotes'][0]['timestamp']='2026-11-01T09:59:59+00:00'
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_footystats_rejected(self):
        x=fixture();x['ga3_rc2']['source']='FootyStats'
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_unverified_wrong_hash_rejected(self):
        x=fixture();x['ga3_rc2']['source_artifact_sha256']='abc'
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_ga3_matrix_and_marginal_inconsistency_flagged(self):
        x=fixture();x['ga3_rc2']['event_probabilities']={'FT.1X2.H':0.9}
        r=analyze_final_sources(x)
        self.assertTrue(r['coherence_issues'])
        self.assertEqual(r['markets'][0]['technical_status'],'INCONSISTENT_INPUT')
    def test_gts_nan_rejected(self):
        x=fixture();x['gts3_rc1']['metrics']['offensive_threat']['home']=float('nan')
        with self.assertRaises(MarketError):analyze_final_sources(x)
    def test_market_probabilities_rc15_only_not_independent(self):
        x=fixture()
        x['ga3_rc2'].pop('scorelines')
        x['ga3_rc2']['event_probabilities']={'FT.1X2.H':0.4}
        r=analyze_final_sources(x)
        self.assertEqual(r['markets'][2]['technical_status'],'INSUFFICIENT_DATA')
        self.assertIsNone(r['markets'][2]['model_probability'])
    def test_normalized_input_not_mutated(self):
        x=fixture();prior=json.dumps(x,sort_keys=True)
        normalized,gts=from_final_sources(x)
        self.assertEqual(prior,json.dumps(x,sort_keys=True))
        self.assertEqual(normalized['probability_model']['version'], 'GA3 RC2 (normalized; native schema unverified)')

if __name__=='__main__':unittest.main()
