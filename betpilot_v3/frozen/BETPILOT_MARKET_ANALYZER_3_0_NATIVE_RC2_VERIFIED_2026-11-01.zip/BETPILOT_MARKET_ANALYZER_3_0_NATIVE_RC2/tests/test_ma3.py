import copy
import json
import math
import unittest
from ma3.core import MarketError, analyze, load_matrix, market_from_matrix, payoffs, settle_result, is_binary
from ma3.backtest import validate_history

NOW='2026-10-31T10:00:00+00:00'
KICK='2026-10-31T15:00:00+00:00'
FINAL='2026-10-31T16:35:00+00:00'
SCORES=[(0,0,.10),(1,0,.25),(0,1,.15),(1,1,.20),(2,0,.15),(0,2,.15)]
MATRIX=[dict(home_goals=h,away_goals=a,probability=p) for h,a,p in SCORES]

def payload(markets=None, quotes=None, model=True, book=False):
    x={'match':{'event_id':'dummy','home':'Home','away':'Away','competition':'Test League',
               'cutoff':NOW,'kickoff':KICK},
       'requested_markets':markets or ['FT.1X2.H','FT.1X2.D','FT.1X2.A','FT.BTTS.YES','FT.TOTAL.OVER.1.5'],
       'quotes':[{'market_id':k,'decimal_odds':v,'source':'Bet365','timestamp':NOW,
                   'provenance':'SYNTHETIC'} for k,v in (quotes or {}).items()]}
    if model:
        x['probability_model']={'version':'GA-MOCK','source':'TEST_ONLY',
            'validation_state':'SYNTHETIC_TEST_ONLY','cutoff':NOW,'event_id':'dummy',
            'periods':{'FT':{'scorelines':MATRIX}}}
    if book:
        x['bookmaker_analyzer']={'protocol':'RC15','source':'Bet365','timestamp':NOW,
          'probability_method':'RC15_EXPERIMENTAL_MODEL_DERIVED',
          'market_probabilities':{'FT.1X2.H':.45,'FT.BTTS.YES':.30}}
    return x

class Semantics(unittest.TestCase):
    def test_1x2(self):
        self.assertEqual([settle_result(f'FT.1X2.{x}',2,1) for x in 'HDA'],
                         ['full_win','full_loss','full_loss'])
    def test_dc(self):
        self.assertEqual(settle_result('FT.DC.1X',0,0),'full_win')
        self.assertEqual(settle_result('FT.DC.12',0,0),'full_loss')
    def test_btts(self):
        self.assertEqual(settle_result('FT.BTTS.YES',1,1),'full_win')
        self.assertEqual(settle_result('FT.BTTS.NO',0,1),'full_win')
    def test_multigoal(self):
        self.assertEqual(settle_result('FT.MULTIGOAL.1.3',2,1),'full_win')
        self.assertEqual(settle_result('FT.MULTIGOAL.1.2',2,1),'full_loss')
    def test_correct_score(self):
        self.assertEqual(settle_result('FT.CS.2.1',2,1),'full_win')
    def test_win_to_nil(self):
        self.assertEqual(settle_result('FT.WIN_TO_NIL.H',3,0),'full_win')
    def test_euro_handicap(self):
        self.assertEqual(settle_result('FT.EURO_AH.D.-1',2,1),'full_win')
        self.assertEqual(settle_result('FT.EURO_AH.H.-1',2,1),'full_loss')
    def test_dnb_push(self):
        self.assertEqual(settle_result('FT.DNB.H',1,1),'push')
    def test_asian_quarter_negative(self):
        self.assertEqual(settle_result('FT.AH.H.-0.25',1,1),'half_loss')
        self.assertEqual(settle_result('FT.AH.H.-0.75',1,0),'half_win')
    def test_asian_quarter_positive(self):
        self.assertEqual(settle_result('FT.AH.A.+0.75',1,0),'half_loss')
        self.assertEqual(settle_result('FT.AH.A.+0.25',1,1),'half_win')
    def test_total_quarter(self):
        self.assertEqual(settle_result('FT.TOTAL_AH.OVER.1.75',0,2),'half_win')
        self.assertEqual(settle_result('FT.TOTAL_AH.UNDER.1.75',0,2),'half_loss')
    def test_team_quarter(self):
        self.assertEqual(settle_result('FT.TEAM.H.OVER.0.75',1,0),'half_win')
    def test_combo_conjunction_not_independent(self):
        c='FT.COMBO.FT.BTTS.YES&FT.TOTAL.OVER.1.5'
        self.assertEqual(settle_result(c,1,1),'full_win')
        self.assertEqual(settle_result(c,2,0),'full_loss')
    def test_combo_reject_push_component(self):
        with self.assertRaises(MarketError):
            settle_result('FT.COMBO.FT.DNB.H&FT.BTTS.NO',0,0)
    def test_combo_no_nested(self):
        with self.assertRaises(MarketError):
            settle_result('FT.COMBO.FT.COMBO.FT.1X2.H&FT.BTTS.NO',0,0)
    def test_quarter_is_not_binary(self):
        self.assertFalse(is_binary('FT.TOTAL.OVER.2.25'))
        self.assertTrue(is_binary('FT.TOTAL.OVER.2.5'))
    def test_corner_unsupported(self):
        with self.assertRaises(MarketError): settle_result('FT.CORNER.OVER.8.5',0,0)
    def test_invalid_fraction(self):
        with self.assertRaises(MarketError): settle_result('FT.TOTAL.OVER.2.33',0,0)
    def test_bad_multigoal(self):
        with self.assertRaises(MarketError): settle_result('FT.MULTIGOAL.3.1',0,0)

class Probabilities(unittest.TestCase):
    def test_distribution(self):
        m=load_matrix(MATRIX)
        self.assertAlmostEqual(market_from_matrix('FT.1X2.H',m)['p_event'],.4)
        self.assertAlmostEqual(market_from_matrix('FT.1X2.D',m)['p_event'],.3)
        self.assertAlmostEqual(market_from_matrix('FT.BTTS.YES',m)['p_event'],.2)
    def test_dependent_combo_prob(self):
        m=load_matrix(MATRIX)
        v=market_from_matrix('FT.COMBO.FT.BTTS.YES&FT.TOTAL.OVER.1.5',m)['p_event']
        self.assertAlmostEqual(v,.2)
        self.assertNotAlmostEqual(v,.2*.5)
    def test_push_fair_odds(self):
        d=market_from_matrix('FT.DNB.H',load_matrix(MATRIX))
        fair=1+.3/.4
        self.assertAlmostEqual(payoffs(d,fair)['expected_profit_per_unit'],0)
        self.assertAlmostEqual(payoffs(d,fair)['fair_odds'],fair)
    def test_quarter_ev(self):
        d=market_from_matrix('FT.AH.H.-0.25',load_matrix(MATRIX))
        self.assertAlmostEqual(sum(d[k] for k in ('full_win','half_win','push','half_loss','full_loss')),1)
        self.assertAlmostEqual(payoffs(d,2)['expected_profit_per_unit'],.4-(.3+.3*.5))
    def test_binary_ev(self):
        d=market_from_matrix('FT.1X2.H',load_matrix(MATRIX))
        self.assertAlmostEqual(payoffs(d,3)['expected_profit_per_unit'],.2)
        self.assertAlmostEqual(payoffs(d,3)['fair_odds'],2.5)
    def test_total_mass_rejection(self):
        bad=copy.deepcopy(MATRIX);bad[0]['probability']=.2
        with self.assertRaises(MarketError): load_matrix(bad)
    def test_duplicate_scoreline(self):
        with self.assertRaises(MarketError): load_matrix(MATRIX+[MATRIX[0]])
    def test_negative_probability(self):
        bad=copy.deepcopy(MATRIX);bad[0]['probability']=-.1
        with self.assertRaises(MarketError): load_matrix(bad)
    def test_nan(self):
        bad=copy.deepcopy(MATRIX);bad[0]['probability']=float('nan')
        with self.assertRaises(MarketError): load_matrix(bad)

class Pipeline(unittest.TestCase):
    def test_ba_diagnostics_passthrough(self):
        p=payload(book=True)
        p['bookmaker_analyzer']['market_stability']={'foo':'bar'}
        self.assertEqual(analyze(p)['bookmaker_diagnostics']['market_stability'],{'foo':'bar'})
    def test_basic_mode(self):
        r=analyze(payload(quotes={'FT.1X2.H':2.7},book=True))
        self.assertEqual(r['protocol'],'MA3-RESEARCH-20261101')
        self.assertFalse(r['operational_eligible'])
        self.assertIsNone(r['final_selection'])
        self.assertEqual(r['markets'][0]['technical_status'],'VALID')
        self.assertAlmostEqual(r['markets'][0]['difference_pp'],-5)
        self.assertEqual(r['markets'][0]['value_status'],'POSITIVE_MODEL_EV_UNVALIDATED')
    def test_bookmaker_only(self):
        r=analyze(payload(model=False,quotes={'FT.1X2.H':2.3}))
        self.assertEqual(r['markets'][0]['technical_status'],'BOOKMAKER_ONLY')
        self.assertIsNone(r['markets'][0]['model_probability'])
    def test_no_quote(self):
        r=analyze(payload())
        self.assertEqual(r['markets'][0]['value_status'],'NO_QUOTE')
        self.assertAlmostEqual(r['markets'][0]['fair_odds'],2.5)
    def test_no_model_period(self):
        r=analyze(payload(['HT.BTTS.YES']))
        self.assertEqual(r['markets'][0]['technical_status'],'INSUFFICIENT_DATA')
    def test_unsupported_is_visible(self):
        r=analyze(payload(['FT.CARD.OVER.4.5']))
        self.assertEqual(r['markets'][0]['technical_status'],'UNSUPPORTED_MARKET')
    def test_no_automatic_numeric_confidence(self):
        r=analyze(payload())
        self.assertEqual(r['rankings']['reliability'],[])
        self.assertEqual(r['markets'][0]['reliability'],'NOT_CALIBRATED')
    def test_future_quote_rejected(self):
        p=payload(quotes={'FT.BTTS.YES':2.0});p['quotes'][0]['timestamp']=KICK
        with self.assertRaises(MarketError):analyze(p)
    def test_future_model_rejected(self):
        p=payload();p['probability_model']['cutoff']=KICK
        with self.assertRaises(MarketError):analyze(p)
    def test_missing_model_identity_rejected(self):
        p=payload()
        del p['probability_model']['event_id']
        with self.assertRaises(MarketError):analyze(p)
    def test_model_identity_rejected(self):
        p=payload();p['probability_model']['event_id']='different'
        with self.assertRaises(MarketError):analyze(p)
    def test_nonstandard_match_rejected(self):
        p=payload();p['match']['duration_minutes']=70
        with self.assertRaises(MarketError):analyze(p)
    def test_duplicate_quote_rejected(self):
        p=payload(quotes={'FT.1X2.H':2.3});p['quotes'].append(p['quotes'][0])
        with self.assertRaises(MarketError):analyze(p)
    def test_bookmaker_timestamp_mismatch_abstains_comparison(self):
        p=payload(quotes={'FT.BTTS.YES':2.4},book=True)
        p['bookmaker_analyzer']['timestamp']='2026-10-31T09:59:00+00:00'
        row=next(x for x in analyze(p)['markets'] if x['market_id']=='FT.BTTS.YES')
        self.assertIsNone(row['difference_pp'])
        self.assertTrue(any('not synchronized' in v for v in row['limitations']))
    def test_coherence_conflict(self):
        p=payload(['FT.BTTS.YES','FT.BTTS.NO'])
        p['probability_model']['event_probabilities']={'FT.BTTS.YES':.8,'FT.BTTS.NO':.4}
        rows=analyze(p)['markets']
        self.assertTrue(all(r['technical_status']=='INCONSISTENT_INPUT' for r in rows))
    def test_direct_marginals_no_combo(self):
        p=payload(['FT.BTTS.YES','FT.COMBO.FT.BTTS.YES&FT.TOTAL.OVER.1.5'])
        del p['probability_model']['periods']
        p['probability_model']['event_probabilities']={'FT.BTTS.YES':.6}
        r=analyze(p)
        self.assertAlmostEqual(r['markets'][0]['model_probability'],.6)
        self.assertEqual(r['markets'][1]['technical_status'],'INSUFFICIENT_DATA')
    def test_settlement_direct(self):
        p=payload(['FT.DNB.H']);del p['probability_model']['periods']
        p['probability_model']['settlement_probabilities']={
           'FT.DNB.H':{'full_win':.4,'push':.3,'full_loss':.3}}
        r=analyze(p)
        self.assertEqual(r['markets'][0]['technical_status'],'VALID')
        self.assertIsNone(r['markets'][0]['model_probability'])
    def test_cutoff_aware_required(self):
        p=payload();p['match']['cutoff']='2026-10-31T10:00:00'
        with self.assertRaises(MarketError):analyze(p)
    def test_roi_validation_uses_true_settlement(self):
        p=payload(['FT.DNB.H'],quotes={'FT.DNB.H':2.0})
        hist=[{'input':p,'actual_home':0,'actual_away':0,'outcome_observed_at':FINAL}]
        v=validate_history(hist)
        self.assertAlmostEqual(v['markets']['FT.DNB.H']['realized_roi_per_unit'],0)
    def test_history_duplicate_event(self):
        p=payload();row={'input':p,'actual_home':1,'actual_away':1,'outcome_observed_at':FINAL}
        with self.assertRaises(MarketError):validate_history([row,row])
    def test_history_prediction_after_outcome(self):
        p=payload();row={'input':p,'actual_home':1,'actual_away':1,'outcome_observed_at':NOW}
        with self.assertRaises(MarketError):validate_history([row])
    def test_history_empty(self):
        with self.assertRaises(MarketError):validate_history([])

    def test_binary_direct_rejects_push_vector(self):
        p=payload(['FT.BTTS.YES'])
        del p['probability_model']['periods']
        p['probability_model']['settlement_probabilities']={'FT.BTTS.YES':{'full_win':.4,'push':.2,'full_loss':.4}}
        with self.assertRaises(MarketError):analyze(p)
    def test_verified_claim_requires_reference(self):
        p=payload(quotes={'FT.BTTS.YES':2.5})
        p['quotes'][0]['provenance']='VERIFIED_EXTERNAL_SNAPSHOT'
        with self.assertRaises(MarketError):analyze(p)
    def test_model_matrix_vs_marginal_conflict(self):
        p=payload(['FT.BTTS.YES'])
        p['probability_model']['event_probabilities']={'FT.BTTS.YES':.5}
        self.assertEqual(analyze(p)['markets'][0]['technical_status'],'INCONSISTENT_INPUT')
    def test_observed_outcome_too_early(self):
        p=payload(['FT.BTTS.YES'])
        hist=[{'input':p,'actual_home':1,'actual_away':1,'outcome_observed_at':KICK}]
        with self.assertRaises(MarketError):validate_history(hist)
    def test_synthetic_backtest_metrics_not_certification(self):
        p=payload(['FT.BTTS.YES'],quotes={'FT.BTTS.YES':5.0},book=True)
        h=[{'input':p,'actual_home':1,'actual_away':1,'outcome_observed_at':FINAL}]
        report=validate_history(h)['markets']['FT.BTTS.YES']
        self.assertAlmostEqual(report['brier'],.64)
        self.assertAlmostEqual(report['paired_bookmaker_brier'],.49)
        self.assertEqual(report['n_matches'],1)
        self.assertAlmostEqual(report['realized_roi_per_unit'],4)

if __name__=='__main__': unittest.main()
