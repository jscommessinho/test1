import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from ma3.core import MarketError
from ma3.runtime import build_handoff, run_pipeline, verify_source_file, rc15_verdict_c_only

ROOT=Path(__file__).resolve().parents[1]
FIX=json.loads((ROOT/'examples/FINAL_SOURCES_SYNTHETIC_INPUT.json').read_text('utf8'))


def price_payload():
    return {
        'match': copy.deepcopy(FIX['match']),
        'odds_snapshot': {'timestamp':'2026-11-01T09:00:00+00:00',
                          'snapshot_id':'MA3-SYN-1','bookmaker':'Bet365',
                          'provenance':'SYNTHETIC'},
        'odds': {'q1':2.3,'qx':3.3,'q2':3.65,'qo':2.05,
                 'qu':1.82,'qgg':2.05,'qng':1.76}
    }


class PipelineTests(unittest.TestCase):
    def test_handoff_propagation_without_betting_pick(self):
        src=copy.deepcopy(FIX)
        called=[]
        def fake(payload, output):
            called.append(copy.deepcopy(payload))
            return copy.deepcopy(src['bookmaker_rc15_verdict_c'])
        with tempfile.TemporaryDirectory() as d:
            result=run_pipeline(FIX['match'],FIX['ga3_rc2'],FIX['gts3_rc1'],
                                price_payload(),d,bookmaker_executor=fake)
            self.assertEqual(len(called),1)
            self.assertEqual(result['betanalyzer_handoff']['markets'][0]['market_id'],
                             result['market_analyzer']['markets'][0]['market_id'])
            self.assertIsNone(result['betanalyzer_handoff']['final_selection'])
            self.assertFalse(result['betanalyzer_handoff']['operational_eligible'])
            for name in ('MA3_INPUT_NORMALIZED.json','MA3_ANALYSIS.json',
                         'BETANALYZER_HANDOFF.json','MA3_RUN_MANIFEST.json'):
                self.assertTrue((Path(d)/name).is_file(),name)
            saved=json.loads((Path(d)/'MA3_RUN_MANIFEST.json').read_text('utf8'))
            for name,digest in saved['files_sha256'].items():
                self.assertEqual(hashlib.sha256((Path(d)/name).read_bytes()).hexdigest(),digest)

    def test_input_readonly(self):
        ga=copy.deepcopy(FIX['ga3_rc2']);gts=copy.deepcopy(FIX['gts3_rc1']);prices=price_payload()
        ga0=copy.deepcopy(ga);gts0=copy.deepcopy(gts);prices0=copy.deepcopy(prices)
        with tempfile.TemporaryDirectory() as d:
            run_pipeline(FIX['match'],ga,gts,prices,d,
                         bookmaker_executor=lambda p,o:copy.deepcopy(FIX['bookmaker_rc15_verdict_c']))
        self.assertEqual(ga,ga0);self.assertEqual(gts,gts0);self.assertEqual(prices,prices0)

    def test_no_legacy_in_input(self):
        p=price_payload();p['goal_analyzer']={'version':'GA2'}
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(MarketError):
                rc15_verdict_c_only(p,d)

    def test_reject_match_mismatch_before_bookmaker(self):
        p=price_payload();p['match']['home']='wrong'
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(MarketError,'home mismatch'):
                run_pipeline(FIX['match'],FIX['ga3_rc2'],FIX['gts3_rc1'],p,d)

    def test_sha_original_enforced(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'source.json';p.write_text('original source file')
            m={'source_artifact_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
            self.assertEqual(verify_source_file(m,p,'GA3'),m['source_artifact_sha256'])
            m['source_artifact_sha256']='0'*64
            with self.assertRaises(MarketError): verify_source_file(m,p,'GA3')

    def test_betanalyzer_handoff_preserves_gts_descriptive_only(self):
        with tempfile.TemporaryDirectory() as d:
            r=run_pipeline(FIX['match'],FIX['ga3_rc2'],FIX['gts3_rc1'],price_payload(),d,
                bookmaker_executor=lambda p,o:copy.deepcopy(FIX['bookmaker_rc15_verdict_c']))
            self.assertFalse(r['betanalyzer_handoff']['gts3_descriptive']['numeric_fusion_with_ga3'])
            self.assertEqual(r['betanalyzer_handoff']['gts3_descriptive']['role'],
                             'DESCRIPTIVE_ONLY_NOT_A_SECOND_INDEPENDENT_PROBABILITY_MODEL')


if __name__=='__main__':unittest.main()
