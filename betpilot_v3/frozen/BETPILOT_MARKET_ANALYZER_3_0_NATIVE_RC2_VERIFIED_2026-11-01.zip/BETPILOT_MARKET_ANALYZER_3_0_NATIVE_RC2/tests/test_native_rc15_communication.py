"""Run only in the repo that has original RC15+Verdict C source installed."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from ma3.core import MarketError
from ma3.runtime import rc15_verdict_c_only
from ma3.final_sources import from_final_sources

ROOT=Path(__file__).resolve().parents[1]
FIX=json.loads((ROOT/'examples/FINAL_SOURCES_SYNTHETIC_INPUT.json').read_text('utf8'))

class NativeRC15Smoke(unittest.TestCase):
    @unittest.skipUnless((ROOT.parent/'betpilot/bookmaker_verdict_c.py').is_file(),
                         'Full original BETPILOT repo not mounted: native RC15 test not available')
    def test_real_native_corrected_rc15_without_step5_ga2_ma2(self):
        m=copy.deepcopy(FIX['match'])
        b={'match':m,'odds_snapshot':{
            'bookmaker':'Bet365','timestamp':'2026-11-01T09:00:00+00:00',
            'provenance':'SYNTHETIC','snapshot_id':'RC15ONLY-SYN-1'},
           'odds':{'q1':2.3,'qx':3.3,'q2':3.65,'qo':2.05,
                   'qu':1.82,'qgg':2.05,'qng':1.76}}
        with tempfile.TemporaryDirectory() as tmp:
            report=rc15_verdict_c_only(b,tmp)
            self.assertEqual(report['verdict_c_audit']['schema'],
                             'BETPILOT_BOOKMAKER_VERDICT_C_V1')
            self.assertEqual(report['rc15_report']['data_quality']['verdict_c_reference_policy'],
                             'FAIL_CLOSED: no unsupported history-based confidence')
            self.assertEqual(len(report['quotes']),7)
            f=copy.deepcopy(FIX);f['bookmaker_rc15_verdict_c']=report
            mapped,gts=from_final_sources(f)
            self.assertEqual(mapped['bookmaker_analyzer']['protocol'],'RC15+VERDICT_C')
            self.assertIn('FT.1X2.H',mapped['bookmaker_analyzer']['market_probabilities'])

if __name__=='__main__':unittest.main()
