"""Build fully synthetic PitchAPI-shaped fixtures for integration smoke only.
No event, quote, fixture, or statistic in these files is a real observation.
"""
from datetime import date,timedelta
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'native_synthetic'
ROOT.mkdir(parents=True,exist_ok=True)
IDS=['t_0BrMnM','t_3eV7Ev','t_AAA','t_BBB','t_CCC','t_DDD']
records={};gts_records={}
for i in range(210):
    day=(date(2026,3,1)+timedelta(days=i)).isoformat()
    home=IDS[(i*5+((i//6)%6))%6]
    away=IDS[(i*3+1+(i//6))%6]
    if home==away:away=IDS[(IDS.index(home)+1+(i%4))%6]
    hg=(i*7+3)%4; ag=(i*3+1)%3
    matchid=f'SYN-{i:04d}'
    h_xg=round(.8+(i%9)*.12,3);a_xg=round(.65+(i%7)*.13,3)
    rec={'match_id':matchid,'league_id':'eng-premier','date':day,
         'season':'2026/2027','qa_internal':'PASS',
         'home':{'id':home,'goals':hg,'xg':h_xg},
         'away':{'id':away,'goals':ag,'xg':a_xg}}
    encoded=json.dumps(rec,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
    rec['source_digest']=hashlib.sha256(encoded.encode()).hexdigest()
    records[matchid]=rec
    stats={'match_id':matchid,'home_team':{'id':home},'away_team':{'id':away},
       'periods':[{'period':'All','groups':[{'items':[
         {'key':'expected_goals','home':h_xg,'away':a_xg},
         {'key':'total_shots','home':12+(i%6),'away':9+(i%5)},
         {'key':'expected_goals_non_penalty','home':h_xg*.9,'away':a_xg*.9},
         {'key':'big_chance','home':2+(i%2),'away':1+(i%3)},
         {'key':'touches_opp_box','home':15+(i%9),'away':11+(i%7)},
         {'key':'red_cards','home':0,'away':0},
         ]}]}]}
    gts_records[matchid]={'fixture':{'match_id':matchid,'date':day,'season':'2026/2027',
                          'home':{'id':home},'away':{'id':away},
                          'home_goals':hg,'away_goals':ag},'statistics':stats}
ga3={'schema':'BETPILOT-PITCHAPI-HISTORY-ARCHIVE-RESEARCH-v1','provider':'PitchAPI',
     'as_of_utc_date':'2026-11-14','league':{'id':'eng-premier','name':'SYNTHETIC Premier League','country':'Italy'},
     'records':records,'warnings':{},'rejected':{}}
(ROOT/'ga3_pitchapi_synthetic.json').write_text(json.dumps(ga3,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(ROOT/'gts3_aggregates_synthetic.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('archive.json',json.dumps({'league':{'id':'eng-premier','name':'SYNTHETIC Premier League'},'records':gts_records}))
match={'event_id':'SYN_NATIVE_001','home':'Example Home','away':'Example Away',
       'competition':'England Premier League 2026','kickoff':'2026-11-15T17:00:00+00:00',
       'cutoff':'2026-11-14T12:00:00+00:00'}
identity={'league_id':'eng-premier','home_team_id':IDS[0],'away_team_id':IDS[1],
          'season':'2026/2027','identity_reference':'SYNTHETIC_MAP_001',
          'identity_provenance':'SYNTHETIC_TEST'}
(ROOT/'match.json').write_text(json.dumps(match,indent=2)+'\n')
(ROOT/'pitchapi_identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(ROOT/'RC15_EVENT_INPUT.json').write_text(json.dumps({'match':match,
 'odds_snapshot':{'bookmaker':'Bet365','timestamp':'2026-11-14T09:00:00+00:00',
                  'provenance':'SYNTHETIC','snapshot_id':'SYNTHETIC-ALL-MA3'},
 'odds':{'q1':2.3,'qx':3.3,'q2':3.65,'qo':2.05,'qu':1.82,'qgg':2.05,'qng':1.76}},indent=2)+'\n')
print('SYNTHETIC only',len(records),'history matches ->',ROOT)
