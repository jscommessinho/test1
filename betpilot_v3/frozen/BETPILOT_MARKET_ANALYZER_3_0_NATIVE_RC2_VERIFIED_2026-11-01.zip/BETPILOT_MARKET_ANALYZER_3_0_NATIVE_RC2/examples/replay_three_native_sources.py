"""Research integration replay: native GA3 + native GTS3 + native corrected RC15 JSON.

The input bookmaker bridge MUST originate from corrected RC15 native execution,
not from this script. Only fully SYNTHETIC fixture odds in bundled examples.
"""
import argparse
import json
from pathlib import Path
from ma3.native_exports import export_ga3,export_gts3
from ma3.runtime import run_pipeline,verify_source_file


def main(argv=None):
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--bookmaker-bridge',required=True,type=Path)
    a.add_argument('--gts3-parameters',type=Path,
                   default=Path(__file__).resolve().parent/'native_synthetic'/'GTS3_FROZEN_MODEL_PARAMS.json')
    a.add_argument('--output-dir',required=True,type=Path)
    args=a.parse_args(argv)
    here=Path(__file__).resolve().parent/'native_synthetic'
    def read(n):return json.loads((here/n).read_text(encoding='utf8'))
    match=read('match.json'); ids=read('pitchapi_identity.json')
    ga=export_ga3(here/'ga3_native_output.json',match,ids)
    gt=export_gts3(here/'gts3_native_output.json',match,ids,args.gts3_parameters)
    verify_source_file(ga,here/'ga3_native_output.json','GA3')
    verify_source_file(gt,here/'gts3_native_output.json','GTS3')
    bridge=json.loads(args.bookmaker_bridge.read_text(encoding='utf8'))
    orig=read('RC15_EVENT_INPUT.json')
    report=run_pipeline(match,ga,gt,orig,args.output_dir,
                        bookmaker_executor=lambda x,y:bridge,
                        native_parity_verified=True)
    assert report['market_analyzer']['upstream_status']['native_ga3_gts3_parity_verified']
    assert not report['market_analyzer']['operational_eligible']
    assert report['betanalyzer_handoff']['betting_recommendation'] is None
    print(json.dumps({'result':'THREE_NATIVE_OUTPUTS_CONNECTED_RESEARCH_ONLY',
         'markets':len(report['market_analyzer']['markets']),
         'native_ga3_gts3_parity_verified':True,'rc15_corrected':True,
         'operational_eligible':False},indent=2))

if __name__=='__main__':main()
