> DOCUMENTO STORICO RC1: stato precedente all'arrivo dei codici GA3 e GTS3. Per lo stato aggiornato consultare `NATIVE_INTEGRATION_AUDIT_RC2.md`.

# VALIDATION REPORT — final upstream source boundary

## Actually inspected

| Component | Source reviewed | Result |
|---|---|---|
| MA3 core | Previous standalone MA3 package | Code loaded, all remaining tests passed |
| RC15 + Verdict C | `jscommessinho/betpilot-prematch-analyzer/main`, `betpilot/bookmaker_verdict_c.py`, `docs/BOOKMAKER_VERDICT_C_FIX.md` | Actual audit/report keys inspected; mapped without changing source |
| GA3 RC2 | Prior chat's ZIP name identified but bytes unavailable | Native schema and native parity **not verified** |
| GTS3 RC1 | Prior chat's ZIP name identified but bytes unavailable | Native schema and native parity **not verified** |
| BetAnalyzer consumer | Existing previous Step5 MA2 interface, not MA3 native interface | New integration **not verified** |

## Synthetic deterministic tests

Test suite checks: bookmaker price mapping, RC15 1X2/BTTS/O-U normalization, historical-bin masking, native-team/competition mapping, timestamp cutoff, event identity, GTS invariance, explicit GA3 probabilities, no old GA2 fallback, 1X2, BTTS, Asian settlements, joint events, EV with pushes, refusal of unsupported corners/cards, no numeric confidence, and model-bookmaker dependence.

All example scores, bookmaker odds, score-matrix parameters and GTS metrics are **synthetic fixture numbers**. These tests cannot show empirical accuracy or economic benefit.

## Blockers to production acceptance

1. No native GA3 RC2 or GTS3 RC1 file bytes in current workspace or GitHub `main` branch; cannot write a verified field mapping without them.
2. No end-to-end replay from **actual** GA3/GTS3 outputs and corrected RC15 output of the **same** historical match with independently verified quote timestamps.
3. No BetAnalyzer consumer adapter regression using the newly structured MA3 response.
4. No frozen, chronologically independent holdout for calibration/rankings/EV or test of ROI with selection bias and uncertainty accounted for.
5. SHA256 references in the normalized payload are user/exporter supplied; values are syntactically checked but cannot be matched to unavailable upstream bytes.

## Declaration

`NORMALIZED CONTRACT IMPLEMENTATION`: COMPLETE and unit-tested.
`NATIVE FINAL ENGINES INTEGRATION`: NOT VERIFIED.
`INDEPENDENT STATISTICAL VALIDATION`: NOT COMPLETED.
`PRODUCTION READY`: NO.
`SOURCE CODE OF GA3/GTS3/RC15+Verdict C MODIFIED`: NO.
