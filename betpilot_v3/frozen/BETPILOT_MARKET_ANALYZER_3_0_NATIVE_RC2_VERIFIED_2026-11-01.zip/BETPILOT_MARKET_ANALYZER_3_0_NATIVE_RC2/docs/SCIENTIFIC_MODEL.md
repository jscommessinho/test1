# A — MARKET ANALYZER 3.0 | Scientific model

## Separation of responsibilities

**Goal Analyzer** supplies a joint score distribution, a binary event probability or a distribution across settlement states. MA3 **does not train, fit or recalibrate** that model. **Bookmaker Analyzer** supplies bookmaker probabilities and their methods; MA3 does not reproduce no-vig fitting or interpret betting-company intent. **Market Analyzer** translates events into score-space settlements, checks coherence and timestamps, compares independently labeled outputs and reports structured markets. **BetAnalyzer** makes the final decision, including NO BET, if separately authorized and validated.

## Accepted sample space

A period P ∈ {FT,HT,SH} requires an externally provided distribution of (home_goals, away_goals), finite, with nonnegative entries and total probability 1 ± 1e-8. Period distributions are not manufactured from full-time values; an explicit upstream period model is required. The frozen GA2 legacy adapter reconstructs the full-time independent-Poisson score space from the **original supplied λ**, without changing them or introducing a new model. This preserves a historical integration path, not predictive certification.

For binary event A, `p_event = sum_{(h,a) in A} p(h,a)`. Example: `BTTS YES ∩ OVER 1.5` is an intersection over scorelines, **not** `P(BTTS)×P(OVER 1.5)` because those events are dependent. Only same-period two-leg *binary* combinations are supported. A combination without either a joint distribution or a directly supplied upstream joint probability is `INSUFFICIENT_DATA`.

## Markets

- **1X2** `FT.1X2.H|D|A`; **double chance** `FT.DC.1X|X2|12`.
- **BTTS** `FT.BTTS.YES|NO`; **multigoal** `FT.MULTIGOAL.1.3` (inclusive range).
- **Total goals** `FT.TOTAL.OVER.2.5` or `FT.TOTAL_AH.UNDER.2.25`.
- **Team goals** `FT.TEAM.H.OVER.1.5`; **DNB** `FT.DNB.H`.
- **Asian handicap** `FT.AH.H.-0.25` (quarter lines, with split stakes).
- **European handicap** `FT.EURO_AH.D.-1`; **correct score** `FT.CS.1.0`; **win to nil** `FT.WIN_TO_NIL.H`.
- **Combinations** `FT.COMBO.FT.DC.1X&FT.TOTAL.OVER.1.5`.
- **HT / SH** use the same syntax only where an **explicit HT/SH distribution or direct upstream settlement** exists. No automatic halftime split.
- **Corner, cards and unsupported team-event markets:** not inferred from goals; `UNSUPPORTED_MARKET`.

The scoring/settlement definitions are only for regular-time 90-minute match outcomes and require confirmation against bookmaker-specific settlement rules before real-money use.

## Asian settlement / EV

The event is described by a five-outcome vector `W`, `HW`, `P`, `HL`, `L`: full-win / half-win / push / half-loss / full-loss. The probabilities sum to one. Quarter handicap `-0.25` splits into stakes on 0 and -0.5. Given actual **offered decimal odds** O:

`win_equivalent = P(W) + 0.5 P(HW)`

`loss_equivalent = P(L) + 0.5 P(HL)`

`EV_net_per_unit = (O-1) * win_equivalent - loss_equivalent`

`fair_odds = 1 + loss_equivalent / win_equivalent`, if win_equivalent > 0, otherwise null. For a pure binary W/L market: `EV = O * P(W) - 1`, `fair_odds = 1/P(W)`. A positive EV is *a mathematical estimate under the given probabilities*, not observed edge or profit guarantee.

For all outcomes, raw implied `1/O` is commercial price information; it is **not** automatically a fair model or calibrated bookmaker probability. Model-bookmaker probability comparison uses `bookmaker_analyzer.market_probabilities` and `probability_method` when provided and when timing and source match the quote (if any). The difference is `(P(model) - P(BA)) * 100` **percentage points**. For Asian markets `model_probability` and the associated binary difference are null; use the full settlement vector instead.

## Reliability, rank and abstention

**Reliability = NOT_CALIBRATED**, even for large event probabilities, until independently validated out-of-sample evidence exists. A declaration from an external model is preserved but **not certified** by MA3. No fabricated 9/10 confidence, no arbitrary weighted market score and no automatic global best bet.

Separate descriptive rankings: (i) binary event probability, (ii) signed positive model-minus-BA difference, (iii) model EV where offered prices and settlement exist. **Not directly equivalent economic objectives** and often strongly overlapping. Reliability/market-quality rankings are empty/unavailable pending prespecified evidence. Rankings are for upstream explanation to BetAnalyzer and must not be interpreted as recommendations.

Market `technical_status` distinguishes `VALID`, `INSUFFICIENT_DATA`, `BOOKMAKER_ONLY`, `INCONSISTENT_INPUT`, `UNSUPPORTED_MARKET`. Independently, `value_status` distinguishes `NOT_ASSESSED`, `NO_QUOTE`, `NO_DEMONSTRABLE_EDGE`, `POSITIVE_MODEL_EV_UNVALIDATED`. Actual final `selection_status=ABSTAIN_NOT_INDEPENDENTLY_VALIDATED`, with `operational_eligible=false`, `betting_recommendation=null`.

## Leakage safeguards

Input cutoff precedes kickoff, all upstream model/BA timestamps precede cutoff, all offered quote timestamps precede cutoff; snapshots for BA-versus-quote probability comparisons require matching source and **exact timestamp** in v3 (stricter than MA2's documented 60-second grouped-capture allowance). Price provenance must be attached; even a declared externally verified reference is *not authenticated* by MA3. Historical actual final scores are only allowed in the **separate** backtester, timestamped at least kickoff + 90 minutes, never as predictive input.

## Validation plan (not represented as done)

Capture pre-match snapshots prior to match kickoff; register periods, market definitions, provider timestamps and selection rules; split by season/date (train → tune → holdout), use the same independent fixtures and quotes for MA2 vs MA3 and consistent market scope. Primary measures: Brier and log loss for identical binary markets; calibration diagrams by family and competition; paired relative scores vs BA baseline, match-cluster/block bootstrap confidence intervals, time stability and analysis of missing quotes/abstentions. Economic validation is distinct and includes full settlement at historic offered prices, stake-equivalent ROI, uncertainty, concentration/multiple-comparisons correction and pre-registration. Tests on synthetic distributions are mathematical checks **only**.
