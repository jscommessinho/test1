# BETPILOT | MA3 Native Integration RC2 — Audit verificato

Data: **1 novembre 2026**. Campo: **PREMATCH — ricerca, non sistema di puntata certificato**.

## 1. Archivi ORIGINALI esaminati (inalterati)

- Goal Analyzer 3.0 RC2 PitchAPI-only: `BETPILOT_GOAL_ANALYZER_3_0_RC2_PITCHAPI_ONLY_2026-11-01(1).zip`.
- GTS 3.0 RC1: `BETPILOT_GTS3_RC1_2026-11-01(1).zip`.
- Bookmaker Analyzer 2.0 RC15 + Verdetto C: **codice immutato su GitHub**, ramo `main`, accessibile da `jscommessinho/betpilot-prematch-analyzer`.

Le manifest SHA256 interni dei due ZIP sono stati verificati: **21/21 file GA3** e **24/24 file GTS3** corrispondenti. Il controllo originale SHA256 dei due ZIP viene riportato nel file `SOURCE_INTEGRITY.json`.

## 2. Contratti REALI, verificati nel codice

**GA3**: `python -m goal_analyzer3.cli predict...` -> JSON con `status=RESEARCH_ONLY_NOT_VALIDATED_FOR_PRODUCTION`, `provider=PitchAPI`, `as_of`, `teams` `[home_id,away_id]`, `model` con fonte campionato `PitchAPI:<league_id>`, `quality`, `prediction.exact_scores` griglia quadrata, `prediction.markets` e `score_axis_max`.

**GTS3**: `python -m gts3.score...` -> `status=RESEARCH_ONLY_NO_BETTING`, `fixture_date`, `season`, `model_version=odh`, `period_calibration`, `snapshot_is_true_prematch=false`, `lambda_adjustment_allowed=false`, array `predictions` con due elementi `home` e `away`, `gts3_0_100_relative`, `goals_intensity_research`, `features` e date/contatori dello storico.

**Bookmaker**: funzione nativa isolata `_rc15_fixed` in `betpilot/bookmaker_verdict_c.py` produce output RC15 con correzioni C-01/C-02, senza chiamata a `native.run_full` / GA2 / MA2. Workflow GitHub CI verificato: https://github.com/jscommessinho/betpilot-prematch-analyzer/actions/runs/41280541287. L'artifact GitHub `ma3-rc15-synthetic-native-bridge` riproduce la stessa identità sintetica degli altri due motori.

## 3. Verifica effettiva della comunicazione

1. `examples/build_synthetic_native_history.py` ha generato **210 partite interamente sintetiche** nei due formati PitchAPI richiesti (storico risultati GA3 e storico xG aggregato GTS3).
2. La CLI **reale** GA3 RC2 ha generato `examples/native_synthetic/ga3_native_output.json` su quello storico, via fit RidgePoisson originale.
3. Il modulo **reale** GTS3 RC1 ha generato `examples/native_synthetic/gts3_native_output.json` con i parametri `odh` congelati.
4. Il workflow **reale** GitHub ha eseguito RC15 + Verdetto C sulle **sette quote sintetiche** e ha consegnato l'artifact `rc15_native_verdict_c_bridge.json`.
5. `ma3.native_exports` ha convertito GA3 e GTS3 in output normalizzati validati, **senza ricalcolare lambda né GTS**. Per GA3, ogni probabilità nativa (1X2, BTTS, O/U e team goal lines) è stata confrontata con la somma corrispondente sulla **matrice nativa** con tolleranza 1e-8.
6. MA3 ha analizzato **47 mercati** (solo 7 con quote effettivamente disponibili nel caso sintetico), generando `MA3_ANALYSIS.json`, `BETANALYZER_HANDOFF.json` e manifest. Ogni stato di EV è informativo e **non** costituisce pronostico consigliato.

La suite MA3 ha **107 test totali, 106 superati e 1 saltato** nel container locale; quello saltato richiede il repository RC15 disponibile come package Python. Lo stesso percorso RC15 nativo è **PASS** nel workflow GitHub separato. I test upstream eseguiti sul codice inalterato: **GA3 22/22**, **GTS3 16/16**.

## 4. Limitazioni — non occultare

- **Nessun replay storico point-in-time autentico.** GA3/GTS3 dichiarano dati di ricerca con origine e disponibilità storica non garantite da snapshot originali prima della partita.
- **Non è testata la redditività** e le stime GA3/GTS3 non sono certificate per puntate, bankroll o quote vere.
- GTS3 RC1 produce un **score descrittivo**; i suoi `goals_intensity_research` **non sostituiscono** né correggono le lambda di GA3.
- Il **BetAnalyzer attuale** usa la legacy pipeline Step5; qui è verificata la produzione di un **handoff JSON** indipendente, non l'esecuzione del suo decisore nativo aggiornato. Il contratto finale del decision engine deve essere compatibilizzato separatamente, senza ricadere su GA2/MA2.
- GA3 native non contiene un `fixture_id`, né la stagione del **target**; GTS3 native non contiene `league_id` del target o un timestamp di acquisizione credibile. MA3 richiede quindi una **mappatura di identità esplicita** (`pitchapi_identity.json`, con provenienza dichiarata). Le associazioni dei nomi alle ID NON vengono inferite.
- La prova completa qui descritta è **sintetica**: è una verifica di correttezza interfacce e percorso eseguibile, non una previsione per una partita reale.
- PR #2 è **draft** e isolata: il pacchetto MA3 RC2 qui distribuito non è ancora copiato nel repo `main`; nessun merge o deployment in produzione è stato effettuato.

## 5. Stati verificati

- `NATIVE_GA3_SCHEMA_AND_NUMERIC_PARITY_PASS`.
- `NATIVE_GTS3_SCHEMA_AND_DESCRIPTIVE_BOUNDS_PASS`.
- `NATIVE_RC15_VERDICT_C_COMMUNICATION_PASS` (GitHub).
- `THREE_NATIVE_OUTPUTS_TO_MA3_PASS` (synthetic integration replay).
- `BETANALYZER_HANDOFF_OUTPUT_PASS` (schema prodotto, consumer nativo non verificato).
- `PREDICTIVE_AND_ECONOMIC_VALIDATION=NOT_COMPLETE`.
- `PRODUCTION_READY=FALSE`.

Non modificati i tre motori sorgente, i loro coefficenti, la loro logica o i database originali. Nessuna chiamata web/API per quote o statistiche durante il replay sintetico.

### Intake JSON di BetAnalyzer

Il contratto `ma3.betanalyzer_contract` valida in modo read-only l'handoff nativo (protocollo, identità, stato NO BET, GTS sidecar senza fusione, 47 mercati / 7 quote); produce `BETANALYZER_INTAKE_AUDIT.json`. NON esegue l'orchestratore decisionale BetAnalyzer preesistente.

Il riferimento congelato `odh` è verificato numericamente e vincolato a SHA256. GTS3 aveva una ricerca prevalentemente Premier: la prova di connessione utilizza pertanto uno storico *sintetico* etichettato Premier, non pretende di validare la trasferibilità in altri campionati.
