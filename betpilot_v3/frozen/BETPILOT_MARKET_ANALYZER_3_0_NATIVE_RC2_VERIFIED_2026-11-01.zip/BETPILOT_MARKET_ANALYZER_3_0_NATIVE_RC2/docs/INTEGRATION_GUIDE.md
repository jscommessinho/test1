# BETPILOT Market Analyzer 3.0 | Integration guide

The **only** supported public CLI in this checkpoint is:

```bash
python -m ma3.cli examples/FINAL_SOURCES_SYNTHETIC_INPUT.json -o report.json
```

Input: explicit **normalized** GA3 RC2 (`ga3_rc2`), descriptive GTS3 RC1 (`gts3_rc1`), corrected RC15 plus Verdict C (`bookmaker_rc15_verdict_c`), `match`, and `requested_markets`. See `FINAL_SOURCES_CONTRACT.md`. These are normalized *consumer* fields, not asserted native upstream field names. A real-source exporter must be audited against the source ZIPs before claiming integration.

Output: the MA3 `markets`, `coherence_issues`, distinct `rankings`, probabilities and payoffs, plus `gts3_descriptive` (pass-through), `bookmaker_rc15_market_methods`, `upstream_status`, `source_input_sha256`, and `operational_eligible=false`.

No GA2, GTS2 or uncorrected RC15 fallback exists in the CLI or this package. `ma3/core.py` is an isolated market mathematics library; it is not an upstream model. The `ma3/backtest.py` generic helper is an offline research aid, not an operational prediction pipeline. BetAnalyzer must not be silently replaced: its consumer interface still needs separate compatibility and outcome tests.

Upstream Python packages, PitchAPI data warehouses and workflows are not modified, nor are their forecast probabilities transformed or fused. These adapters fail closed on inconsistent provenance, timestamps, identities, C-02 historical masking, and malformed probabilities.
