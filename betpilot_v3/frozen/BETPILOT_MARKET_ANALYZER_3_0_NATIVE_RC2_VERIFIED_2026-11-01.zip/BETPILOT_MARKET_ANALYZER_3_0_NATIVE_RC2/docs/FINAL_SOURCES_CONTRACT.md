> DOCUMENTO STORICO RC1: stato precedente all'arrivo dei codici GA3 e GTS3. Per lo stato aggiornato consultare `NATIVE_INTEGRATION_AUDIT_RC2.md`.

# BETPILOT | Market Analyzer 3.0 — Final-sources normalization contract

## Scope and essential distinction

**This is an implemented, tested normalization contract for read-only upstream outputs. It is NOT a native GA3 RC2 or GTS3 RC1 schema parser.** The finalized standalone ZIPs `BETPILOT_GOAL_ANALYZER_3_0_RC2_PITCHAPI_ONLY_2026-11-01.zip` and `BETPILOT_GTS3_RC1_2026-11-01.zip` were referenced in separate chats but were **not available for byte-level inspection in this session or in the GitHub `main` tree**. No source code, hashes or JSON native shapes have been inferred. Actual native-source parity is **BLOCKED** until those exact archives can be inspected.

The source tags `GA3_RC2` and `GTS3_RC1` used **within this interface** are integration labels and **are not claims about the programs' native `version` fields**. Before an actual match, a separately audited exporter must map the real native outputs to the exact normalized fields below. Missing or ambiguous fields must cause abstention, not invented defaults.

## Read-only event input

```json
{
  "match": {
    "event_id": "EVENT-IDENTIFIER", "home": "HOME", "away": "AWAY",
    "competition": "LEAGUE", "kickoff": "2026-11-15T15:00:00+00:00",
    "cutoff": "2026-11-15T14:00:00+00:00"
  },
  "ga3_rc2": {
    "contract": "MA3-FINAL-SOURCES-NORMALIZED-CONTRACT-1",
    "release": "GA3_RC2", "source": "PitchAPI",
    "event_id": "EVENT-IDENTIFIER", "home": "HOME", "away": "AWAY",
    "cutoff": "2026-11-15T14:00:00+00:00",
    "source_artifact_sha256": "[64 hex characters]",
    "scorelines": [
      {"home_goals": 0, "away_goals": 0, "probability": 0.10}
    ]
  },
  "gts3_rc1": {
    "contract": "MA3-FINAL-SOURCES-NORMALIZED-CONTRACT-1",
    "release": "GTS3_RC1", "source": "PitchAPI",
    "event_id": "EVENT-IDENTIFIER", "home": "HOME", "away": "AWAY",
    "cutoff": "2026-11-15T14:00:00+00:00",
    "source_artifact_sha256": "[64 hex characters]",
    "metrics": {"name_from_verified_upstream_exporter": 0}
  },
  "bookmaker_rc15_verdict_c": {
    "verdict_c_audit": {"schema": "BETPILOT_BOOKMAKER_VERDICT_C_V1"},
    "rc15_report": {},
    "quotes": []
  },
  "requested_markets": ["FT.1X2.H"]
}
```

This is an **illustrative, intentionally incomplete** structure, not a runnable fixture. The `scorelines` probabilities must form a complete distribution summing to 1 within the numerical tolerance used by `ma3.core.load_matrix`; otherwise use GA3's independently supplied `event_probabilities` for binary markets, and `settlement_probabilities` for refund/partial-settlement markets. **No Poisson distribution is fabricated from lambdas**. No GA2 fallback exists in this release.

### GTS3 read-only contract

GTS must be included with matching event identity and PitchAPI source. MA3 copies the `metrics` JSON tree verbatim (except a deep copy to avoid mutation), validates it contains finite JSON values and carries it as `gts3_descriptive`. It never maps GTS scores into probabilities, reweights Goal Analyzer, computes a consensus score or promotes GTS to independent market evidence.

### RC15 + Verdict C contract — observed repository fields

The GitHub repo contains `betpilot/bookmaker_verdict_c.py` and the original RC15 `single_market_probabilities_RC12_experimental` family data. The corrected wrapper produces the audit `BOOKMAKER_VERDICT_C_AUDIT.json` with schema `BETPILOT_BOOKMAKER_VERDICT_C_V1`, `competition_mapping`, `unavailable_reference_events`, `coefficients_changed=false`, and `prospective_prediction_validated=false`.

Use the **corrected** `rc15_native/RC15_Analysis.json` report's `reports[0]` as `rc15_report`, not the unpatched historic RC15 report. Preserve `identity`, `data_quality`, `single_market_probabilities_RC12_experimental`, `historical_support`, `bise_structural`, `optional_market_diagnostics`. Provide *captured* Bet365 `quotes` explicitly with cutoff-aware timezone timestamps, synchronized snapshot, market IDs, and provenance: the RC15 report alone does not authenticate quote capture. The map is:

- `1X2.p.1/.X/.2` -> `FT.1X2.H/.D/.A`
- `1X2.p.1X/.X2/.12` -> `FT.DC.1X/.X2/.12`
- `OU2_5.p.Over_2_5/.Under_2_5` -> `FT.TOTAL.OVER.2.5/.UNDER.2.5`
- `BTTS.p.GG/.NG` -> `FT.BTTS.YES/.NO`

Methods are **market specific** (e.g. `direct` vs `RC11.2`) and retained in `bookmaker_rc15_market_methods`. They remain bookmaker-derived, **not independent corroborating probability forecasts**. The correction adapter's C-02 historical-reference mismatch bins must be null for `n`, `mean_prediction`, `observed_frequency`, `bias_pp`. A failed condition rejects the input.

### Version, validation and integrity

The GA3/GTS3 SHA256 values are provided *as metadata* by the exporter and their syntax is checked, **but MA3 cannot authenticate their original bytes**. Likewise `VERIFIED_EXTERNAL_SNAPSHOT` with a capture reference is an **unverified assertion** until external source records are independently audited. At present `native_ga3_gts3_parity_verified=false`, `operational_eligible=false` and `betting_recommendation=null` regardless of whether other gates pass.

## Running

```bash
python -m unittest discover -s tests -v
python -m ma3.cli examples/FINAL_SOURCES_SYNTHETIC_INPUT.json -o example_output.json
```

**No `--native-ma2` flag or GA2 adapter is included in this final-sources checkpoint.** Previous source files remain available only in the separately preserved older ZIP and GitHub archives, not as a runtime dependency here.

### Needed for actual verified native integration

Inspect the two finalized GA3/GTS3 ZIPs, record immutable SHA256 identifiers, review their real output field names and cutoff timestamps, write minimal one-to-one exporter mappings, run parity tests using original upstream outputs for the same held-out fixtures, verify live corrected RC15 snapshots and BetAnalyzer's consumer contract. Only then is native integration verified. Statistical out-of-sample validation is a separate requirement.
