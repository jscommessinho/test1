# F — Scientific independent audit | Status and residual risks

## Verified strengths

- Explicit model-bookmaker responsibility split and no illegal independent reuse of RC15/Bet365 as a second forecast.
- Reuses sound MA2 principles: score-space event definition, five-state settlement, no invented HT parameters, no score or tip based on uncalibrated confidence.
- Asian quarter-line payoff formula tested. Combined-event dependence calculated from upstream joint scores rather than independent marginals.
- UTC-aware cutoffs, quote metadata and separate provenance status.
- Dedicated `UNSUPPORTED_MARKET` for corner/cards; `INSUFFICIENT_DATA` for missing temporal or joint distributions; no forced winner/pick.

## Problems corrected in this standalone release

- Added a **model-neutral** joint-score input path and explicit source-of-probability explanation. The original MA2 was hardcoded to frozen GA2 reference λ as its sole model path.
- Clarified separation of technical validity from probability, reliability and economic status; retained no-calibrated-score discipline.
- The history evaluator now captures *settled realized ROI for nonbinary markets*, while limiting binary Brier/log loss to appropriate binary-event forecasts.
- Added direct marginal partition/monotonicity/matrix coherence checks and strict synchronized BA-versus-quote comparisons.

## Blocking before production (P0)

1. **No independent statistical validation**: absent verified future/holdout joined GA/BA prediction snapshots, prices, and results. Neither the 58 tests nor original MA2 source history fills this gap.
2. **No native GA3 / BA3 schema verification**: only frozen MA2 native GA2 + RC15 compatibility adapter is executable. A separate connector matching actual outputs is mandatory.
3. **No completed BetAnalyzer production adapter/integration**: MA3 output differs from MA2 and is not connected to existing native end-to-end pipeline. No original motor should be silently replaced.
4. **No independent quote capture verification**: timestamps and claimed provenance can be validated for format, not authenticated against bookmaker records inside MA3.
5. **No demonstrated economic edge** or validated abstention/selection threshold. `POSITIVE_MODEL_EV_UNVALIDATED` is descriptive and must not be promoted to a positive bet.

## Important follow-on work (P1)

- Compare the new report against frozen MA2 on a **real same-event panel**; obtain score-state grading for match/market not only overlap in output names.
- Include provider-specific settlement edge cases: void fixtures, overtime exclusion, abandoned matches, bookmaker-specific quirks and line rule conventions; live deployment must fail closed before unverified market families.
- Add independent *per-market-family* calibration and temporal uncertainty/clustered stability analysis with preregistered diagnostic thresholds.
- Clarify if native BetAnalyzer requires BA group-level overround or monotonicity diagnostics; MA3 intentionally does not implement duplicate no-vig estimation and delegates that task upstream.

## Minor limitations / explicit tradeoffs

- Fractional/quarter lines are supported when multiples of .25; source JSON input uses string market IDs and must be mapped by upstream adapter.
- For direct marginal-only upstream inputs, compound/Asian markets require the proper joint/settlement probability upstream; they are not extrapolated.
- Quote/BA exact timestamp matching is more conservative than MA2's <=60s shared-snapshot condition; may reduce coverage until provider captures improve.
- Current event-wise backtester supplies descriptive averages, not calibrated confidence intervals or a claim of independent matched seasonal splits.
- No assigned stake, bankroll, Kelly fraction or winning recommendation: these are intentionally excluded.

## Independent conclusion

**Research architecture / isolated implementation:** acceptable research checkpoint with defensible mathematics on tested contracts. **Production authorization:** denied pending P0 evidence. **Statistical or economic superiority to MA2:** not established. **Original GA2/RC15/MA2 and all databases:** unchanged by the package.


## Update 2026-11-01 — Final source boundary
The runtime GA2 adapter has been removed from this checkpoint. Only the normalized GA3 RC2 + GTS3 RC1 + RC15 Verdict C entrypoint remains; native GA3/GTS3 files were unavailable so this is not a full native parity claim. See FINAL_SOURCES_CONTRACT.md and VALIDATION_REPORT_FINAL_SOURCES.md.
