> DOCUMENTO STORICO RC1: stato precedente all'arrivo dei codici GA3 e GTS3. Per lo stato aggiornato consultare `NATIVE_INTEGRATION_AUDIT_RC2.md`.

# MA3 Communication RC1 — integration & scientific audit

**2026-11-01** · Source engine changes: **none**.

## Verified source reality

- The GitHub `main` tree at `b4ec14fed7488a28059ab40a06eea0fd5342435b` includes archived MA2/GA2, native RC15 and `betpilot/bookmaker_verdict_c.py` (the non-invasive Verdict C correction).
- The same tree contains **no GA3 RC2/GTS3 RC1 source release**; previously delivered ZIPs from other conversations are not mounted in this session. Consequently, schema parity, exact upstream output formats, and source native invocations are **NOT VERIFIED**.
- Original Verdict C `run_full_fixed` calls frozen Step5 `run_full`, which still calls MA2; this route is intentionally excluded in the new runtime. Instead the isolated wrapper invokes **only** existing native RC15+Verdict C corrections via `_rc15_fixed(..., native.native_rc15, ...)`. This deliberately depends on an existing private helper: verify its version/signature in CI before enabling a production path.

## Module responsibilities

| Module | Role | Native execution confirmed? |
|---|---|---|
| Goal Analyzer 3.0 RC2 | Sole probability source via externally supplied normalized output | No; code unavailable |
| GTS 3.0 RC1 | Descriptive metrics only, no probability fusion | No; code unavailable |
| Bookmaker 2.0 RC15 + Verdict C | Real corrected-market quote/pricing adapter | Code inspected; smoke requires full original repository |
| Market Analyzer 3.0 | Settlement, scenario, market comparison, EV, separate rankings | Yes, deterministic tests |
| BetAnalyzer | Receives `BETANALYZER_HANDOFF.json`, final decision reserved | Native reader unverified |

## Operational safeguards

1. Fail closed if GA3/GTS3 normalized release/contract/source/event_id/cutoff/source hash invalid.
2. Require original artifact checksum match in the CLI; no fabricated GA3 or GTS3 evidence.
3. Reject any legacy `goal_analyzer` in direct RC15 payload. Do **not** call historic GA2 or MA2.
4. Require Bet365 seven odds in one snapshot, with explicit provenance, all timestamped before cutoff.
5. Preserve RC15 Verdict C C-01 BIG5 competition normalization, C-02 masked unmatched historical reference bins. Do not alter calibrated probabilities.
6. Never treat GTS3 as an independent or numerically fused probability signal.
7. No confidence number without independently calibrated evidence, no automatic selection, no betting strategy/stake.
8. No alteration to originals; run artifacts only under output directory.

## Outstanding tasks that cannot be claimed complete

- Obtain original GA3 RC2 and GTS3 RC1 ZIPs and inspect their actual schemas/commands; build genuine exporters without editing originals.
- Run native corrected RC15 smoke inside the full repository and check workflow CI.
- Validate official BetAnalyzer's latest native input schema and integrate its invocation (this checkpoint provides a stable explicit handoff only).
- Test real prematch data with provable capture timestamps and independent temporal calibration; classify production readiness separately from technical correctness.

## User deliverable

Use `python -m unittest discover -s tests -q` and `python -m ma3.cli_pipeline --help`. See README for required files. The pipeline is implemented but cannot be called *fully operational with native GA3/GTS3* until the original source packages and verified exporters are available.
