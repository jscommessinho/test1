# D — Comparison | Market Analyzer 2.0 vs isolated 3.0

**Source inspected:** original MA2 `market_analyzer.py`, tests, `A_PROTOCOLLO_CONSOLIDATO.md`, `F_CHECKPOINT.md`, RC15 native `integrate_native.py` in the private repository at tree `b4ec14fed7488a28059ab40a06eea0fd5342435b`. Version 2 is a research-only implementation, not a certified betting predictor. This comparison concerns *verified code/design differences*, **not** retrospective predictive superiority.

| Dimension | MA2 native (verified code) | MA3 isolated implementation |
|---|---|---|
| Market settlement | Full/half wins, push, full/half loss, including AH/DNB | Preserved semantics; external settlement vectors additionally accepted |
| Score distribution | Frozen GA2 λ → independent Poisson; optional period λ adapters | Model-independent score-grid input; separate frozen GA2 λ adapter |
| Combination probabilities | Joint score-space intersection for 2 binary same-period legs | Same principle, no multiplication of dependent marginals |
| Odds | Proportional no-vig of complete concurrent exclusive groups computed in MA2 | Consume BA estimated probabilities; display raw implied 1/odds separately; no duplicated no-vig method |
| Price timing | Quote cutoff and per-group synchronization <=60s under specific snapshot conditions | Cutoff/identity plus exact BA ↔ quote timestamp and source for paired comparisons |
| GA interface | Hardcoded `GA2-RESEARCH-20261029-v1` | Generic model probabilities/joint score grid; version-locked adapter for frozen GA2 |
| BA interface | RC15 pass-through, separate experimental probabilities | BA pass-through, method label, explicit timestamp/source compatibility check |
| Confidence | `NOT_CALIBRATED`, no numeric score | Preserved `NOT_CALIBRATED`; no unsupported reliability ranking |
| Market rankings | Intragroup scenario leaders and descriptive candidates | Separate flat probability / probability difference / EV rank; no final bet |
| Coherence | Cross-group price-order diagnostics, descriptive | Explicit direct model marginal/score-grid consistency and subset checks |
| Native BetAnalyzer | Existing Step3/5 MA2 integration | New isolated JSON output; native BetAnalyzer 3 integration not tested |
| Software tests | 27 frozen MA2 tests documented in original checkpoint | 58 deterministic MA3 tests executed in this work environment |
| Statistical validation | Not completed according to MA2 source | Not completed: no independent contemporaneous test set supplied here |

**Preserved**: correct settlement math, compound-event intersection, no-fake-confidence abstention, timestamp controls, modular separation. **Added**: explicit joint-score input, named probability basis, direct marginal & settlement adapters, model coherence diagnostics, separated ranking axes and history evaluator. **Changed with tradeoff**: MA3 intentionally delegates no-vig and does not yet replicate all of MA2's price-only cross-line diagnostics; the latter remain available in frozen Bookmaker/MA2 implementations. This is not proof MA3 dominates MA2 in aggregate.

**No quantification of improvement in predictive skill, bookmaker pricing, ROI, economic profitability or out-of-sample generalization is possible** from the inspected records. Genuine numerical MA2/MA3 comparison requires matching real pre-match forecasts, quotes and post-match results for both versions, with prespecified same-fixture analysis and independent holdout.
