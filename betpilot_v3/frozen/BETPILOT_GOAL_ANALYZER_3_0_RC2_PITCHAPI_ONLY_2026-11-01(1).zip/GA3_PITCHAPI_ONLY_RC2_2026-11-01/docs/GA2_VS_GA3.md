# GA2 vs GA3 RC2 — confronto di struttura, NON risultato statistico

| Aspetto | GA2 riferimento congelato | GA3 RC2 |
|---|---|---|
| Fonte previsioni | storico interno congelato | **solo PitchAPI** |
| FootyStats | non richiesto nel frozen GA2 | **solo audit esterno isolato** |
| Stima λ | Poisson ridge H=365, κ=10, venue=True | GA2-like default, candidati H e venue sottoposti a selezione temporale |
| xG | non utilizzati nel frozen GA2 | solo PitchAPI: candidato opzionale, **off di default** |
| Provenienza | storico usato nella ricerca GA2 | per-match ID/digest/QA PASS/league pin, date-only + 3 giorni |
| Giudizio sui dati PitchAPI | non applicabile | confronto di score/xG con FootyStats in processo separato, mai input |
| Test statistici su stessi dati | non riprodotti in questa release | **non ancora eseguiti** |
| Stato | baseline storico | RC2 implementato, research-only |

La disponibilità di script per confrontare modelli non equivale a maggiore accuratezza dimostrata. Ricostruire GA2 e GA3 sul medesimo universo di partite, con lo stesso cutoff informativo, prima di attribuire un miglioramento reale.
