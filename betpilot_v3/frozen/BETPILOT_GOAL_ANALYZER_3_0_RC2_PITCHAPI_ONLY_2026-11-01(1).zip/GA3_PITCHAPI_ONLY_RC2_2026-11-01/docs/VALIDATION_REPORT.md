# GOAL ANALYZER 3.0 — RC2 Validation Report

## Stato effettivo (2026-11-01)

- **22 test Python superati** nel runtime locale.
- Verificate proprietà delle matrici dei punteggi (normalizzazione, BTTS, Over/Under, 1X2), controllo degli input PitchAPI, assenza di training FootyStats, cutoff con ritardo a tre giorni, mancata mutazione della sorgente predittiva dopo un audit su CSV discordanti, sistema temporale su fixture sintetiche.
- Test end-to-end su dati sintetici **solo per comportamento del software**.
- Non eseguiti in RC2 backtest, calibrazione e cross-provider parity su dati storici reali perché gli archivi PitchAPI originali non erano localmente disponibili nel runtime.

## Metriche empiriche

| Misura | Risultato RC2 |
|---|---|
| Joint negative log-likelihood su partite vere | NON MISURATO |
| Brier BTTS | NON MISURATO |
| Brier Over 2.5 | NON MISURATO |
| Calibrazione reale | NON MISURATA |
| GA2 vs GA3 stesso holdout | NON MISURATO |
| Audit PitchAPI vs FootyStats su matching reale | NON ESEGUITO in questa release |

`STATISTICAL VALIDATION COMPLETE = NO`. `PRODUCTION READY = NO`.

Il percorso di training si basa **esclusivamente** su PitchAPI. Un eventuale rapporto di confronto con CSV FootyStats è solo un output descrittivo di controllo qualità e non modifica automaticamente la selezione delle osservazioni o la calibrazione. Gli xG dei due provider possono avere definizioni non equivalenti; validare anche contro riferimenti terzi ove possibile.
