# GOAL ANALYZER 3.0 — Audit indipendente RC2

## Regola architetturale

**Solo PitchAPI alimenta `model.py`, `evaluation.py` e `probability.py`.** `Match` richiede `provider='PitchAPI'`, l'ID lega deve essere pinned e `require_pitchapi` impedisce mixing e duplicati. La CLI di previsione/backtest non espone `--provider=footystats`.

## Audit esterno separato

`external_audit.py` è l'unico modulo che apre file FootyStats: produce report read-only con matching data/team a partire da un mapping esplicito verificato. Metriche: partite abbinate, non abbinate, ambigue, concordanza risultati, differenza xG casa/ospite. Non produce λ, coefficienti né probabilità. Confrontare due fonti non equivale a verificare con un arbitraggio ufficiale indipendente; le definizioni xG possono divergere.

## Limiti importanti

1. **Storico reale ancora non backtestato in RC2.** Nessuna affermazione di maggiore accuratezza.
2. **Snapshot PitchAPI retrospettivi:** SHA-256 prova integrità del record archiviato, NON veridicità né disponibilità al tempo della previsione storica. Potenziali revision leakage non risolti.
3. **Precisione temporale giorno:** `kickoff` nella struttura dati rappresenta 00:00 UTC del giorno della partita, NON l'orario preciso. Disponibilità conservativa a +3 giorni.
4. **xG PitchAPI:** la verifica interna tra endpoint dello stesso provider non certifica qualità verso fonti indipendenti. Candidato xG disabilitato per default, opt-in solo sperimentale.
5. **Team mapping:** l'alias tra ID PitchAPI e nomi FootyStats deve essere revisionato. Evitare fuzzy matching silenzioso e crossing tra competizioni omonime.
6. **Validità di training manuale:** la API Python `Match(provider='PitchAPI')` è un contratto dichiarativo; non è una prova crittografica di origine quando un chiamante costruisce oggetti arbitrari. L'ingresso operativo deve avvenire dall'archive loader con firma digest e pin verificati.
7. **Nessun collegamento quote** e nessun esito sulla redditività.

## Esito audit

- Separazione origine delle previsioni: **IMPLEMENTATA / TESTATA**.
- Comparatore read-only: **IMPLEMENTATO / TESTATO CON FIXTURE SINTETICHE**.
- Verifica indipendente di affidabilità real-world: **IN ATTESA DI VERIFICA**.
- Prontezza per scommesse operative: **NON CERTIFICATA**.
