# GA3 RC2 | Modello matematico — Fonte dati PitchAPI ONLY

## Input e provenance

Sono ammesse solo osservazioni di partite completate dagli archivi PitchAPI con pin campionato e squadre native, risultati, stagione e data, `qa_internal=PASS`, digest valido. `xG` (stesso provider) è ammesso solo nel candidato sperimentale esplicitamente abilitato. Non si usano feature, quote o output di FootyStats in fitting, stima, calibrazione o backtest.

## Intensità dei gol

Il motore implementa un modello ridge-Poisson di log-intensità per ogni squadra con attacco, vulnerabilità difensiva, intercetta, casa e, opzionalmente, venue deviations. Minimizza la loss Poisson pesata nel tempo più la penalità L2 su coefficienti non d'intercetta. Il decadimento usa pesi `2**(-days_since_match/half_life)`. Configurazione GA2 di riferimento: half-life 365 giorni, ridge 10, venue=True.

L'opzione sperimentale xG usa un pseudo-target `y=(1-b)*gol + b*xG_PitchAPI`. **Non** costituisce una likelihood generativa correttamente specificata degli xG. `b=0` di default e la candidatura xG è esclusa dalla selezione automatica salvo opt-in esplicito.

## Distribuzione congiunta

La distribuzione indipendente base è `P(H=h,A=a)=Pois(h;lambda_H)*Pois(a;lambda_A)`. Ogni probabilità 1X2, GG/NG, Over/Under e score deriva dalla stessa matrice di risultati normalizzata. Dixon–Coles è una capacità matematica opzionale della libreria, non un correttore validato o selezionato automaticamente.

## Sele-zione temporale

La CLI richiede selezione, calibrazione e test su intervalli disgiunti e cronologicamente ordinati. Il modello è rifittato su base mensile e usa solo match disponibili almeno 3 giorni dopo la data PitchAPI; lo snapshot del database, tuttavia, può essere stato revisionato retroattivamente: la sola sequenza cronologica è insufficiente per certificare *point-in-time*.

Le metriche includono joint NLL e Brier dei mercati, con bootstrap settimanale appaiato. Un cambiamento non è automaticamente promosso per mera riduzione in sample.
