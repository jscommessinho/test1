# Goal Analyzer 3.0 RC2 — Integrazione sicura

**Sorgente unica per la previsione: PitchAPI**.

Percorso permesso: `PitchAPI history JSON` → `load_pitchapi()` → `Match(provider='PitchAPI', competition='PitchAPI:<ID>')` → `RidgePoisson.fit()` → `predict_markets()`. I campi obbligatori sono league ID, team IDs, data, stagione e gol. Gli xG di PitchAPI sono opzionali, e disabilitati salvo sperimentazione esplicita.

La predizione CLI restituisce JSON con `provider=PitchAPI`, `quality`, `as_of`, parametri modello e probabilità coerenti. `status=RESEARCH_ONLY_NOT_VALIDATED_FOR_PRODUCTION` impedisce di trattare la previsione come segnale operativo certificato. Le squadre di input sono identificatori **PitchAPI nativi**, non nomi FootyStats né API-Football.

L'utility `python -m goal_analyzer3.external_audit ...` è completamente separata: prende CSV FootyStats solo per **comparare** risultati e xG su fixture e ID mappati con conferma dell'operatore. Il suo JSON non è input per il motore. Non usare output di audit come feature, regularizer, parametro, probabilità, stima di xG o forza squadra.

Per integrarsi con BetAnalyzer creare in futuro un adapter **nuovo** read-only, senza modificare GA2, Market Analyzer 2.0, RC15, GTS o gli altri sistemi. L'integrazione deve verificare kickoff effettivo, identità campionato/squadre, versione del modello, disponibilità di dati prima del calcio d'inizio e assenza di fuga temporale. Non usare `RESEARCH_ONLY` per allocare stake o individuare automaticamente giocate.
