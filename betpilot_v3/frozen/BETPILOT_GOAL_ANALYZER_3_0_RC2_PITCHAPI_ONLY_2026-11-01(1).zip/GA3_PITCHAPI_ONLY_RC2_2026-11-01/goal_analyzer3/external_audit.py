"""Strictly OUTSIDE the predictive pipeline: independent FootyStats-vs-PitchAPI audit.

No routines in model.py, evaluation.py or cli.py import this module.
FootyStats figures are NEVER fitted, blended, calibrated or backtested as GA3
inputs. This audit can expose disagreements, but two providers agreeing does NOT
constitute independent verification against official match/event ground truth.
"""
from __future__ import annotations
import argparse,csv,json,math,re,sys
from datetime import datetime,timezone
from pathlib import Path
from collections import defaultdict,Counter
from .pitchapi import load_pitchapi
from .data import DataError


def _parse_fs(files):
    entries=[];seen_files=set()
    needed={'timestamp','status','home_team_name','away_team_name',
            'home_team_goal_count','away_team_goal_count'}
    for f in files:
        path=Path(f)
        if str(path.resolve()) in seen_files:raise DataError('Duplicate FootyStats file')
        seen_files.add(str(path.resolve()))
        if not re.search(r'matches-\d{4}-to-\d{4}-stats\.csv$',path.name):
            raise DataError('FootyStats audit only: unexpected Match Stats season filename')
        with path.open(encoding='utf-8-sig',newline='') as handle:
            reader=csv.DictReader(handle)
            if reader.fieldnames is None or len(reader.fieldnames)!=len(set(reader.fieldnames)) or not needed<=set(reader.fieldnames):
                raise DataError('Invalid FootyStats comparison CSV headers')
            for line,r in enumerate(reader,2):
                if None in r:raise DataError(f'Malformed FootyStats row {path.name}:{line}')
                if (r.get('status') or '').strip().lower()!='complete':continue
                try:
                    dt=datetime.fromtimestamp(int(r['timestamp']),tz=timezone.utc).date()
                    home=r['home_team_name'].strip();away=r['away_team_name'].strip()
                    hg=int(r['home_team_goal_count']);ag=int(r['away_team_goal_count'])
                    if not home or not away or home==away or not 0<=hg<=30 or not 0<=ag<=30:raise ValueError()
                    def xg(k):
                        v=r.get(k)
                        if v is None or str(v).strip() in ('','N/A','-'):return None
                        x=float(v)
                        if not math.isfinite(x) or not 0<=x<=15:raise ValueError()
                        return x
                    hxg=xg('team_a_xg');axg=xg('team_b_xg')
                except (ValueError,OverflowError) as ex:
                    raise DataError(f'Invalid FootyStats audit row {path.name}:{line}') from ex
                entries.append({'date':dt,'home':home,'away':away,'hg':hg,'ag':ag,
                                'hxg':hxg,'axg':axg,'file':path.name,'line':line})
    if not entries:raise DataError('No completed FootyStats audit fixtures')
    keys=[(r['date'],r['home'],r['away']) for r in entries]
    if len(set(keys))!=len(keys):raise DataError('Duplicate comparison fixture')
    return entries


def compare_sources(pitchapi_files,footystats_files,mapping_path,max_days=1,xg_reference_difference=0.5):
    """Read-only independent audit; does not mutate/generate training features."""
    if max_days not in (0,1):raise DataError('Only 0/1 day UTC date tolerance allowed')
    mapping=json.loads(Path(mapping_path).read_text(encoding='utf-8'))
    league_id=mapping.get('pitchapi_league_id')
    team_map=mapping.get('team_id_to_footystats_name')
    if not isinstance(league_id,str) or not league_id or not isinstance(team_map,dict) or not team_map:
        raise DataError('Explicit competition and team ID mapping required')
    if any(not isinstance(k,str) or not k or not isinstance(v,str) or not v for k,v in team_map.items()):
        raise DataError('Invalid native-ID to FootyStats team name mapping')
    if len(set(team_map.values()))!=len(team_map):
        raise DataError('Ambiguous mapped team names')
    pa,pa_qa=load_pitchapi(pitchapi_files,league_id=league_id)
    fs=_parse_fs(footystats_files)
    by_pair=defaultdict(list)
    for i,r in enumerate(fs):by_pair[(r['home'],r['away'])].append((i,r))
    used=set();matched=[];unmapped=[];unmatched=[];ambiguous=[]
    for p in pa:
        h=team_map.get(p.home);a=team_map.get(p.away)
        if h is None or a is None:
            unmapped.append({'date':p.kickoff.date().isoformat(),'home_id':p.home,'away_id':p.away})
            continue
        candidates=[(i,r) for i,r in by_pair.get((h,a),[]) if abs((r['date']-p.kickoff.date()).days)<=max_days]
        if len(candidates)>1:
            ambiguous.append({'date':p.kickoff.date().isoformat(),'home':h,'away':a,'candidate_count':len(candidates)})
            continue
        if not candidates:
            unmatched.append({'date':p.kickoff.date().isoformat(),'home':h,'away':a})
            continue
        i,r=candidates[0]
        if i in used:raise DataError('Nonunique many-to-one fixture resolution')
        used.add(i)
        gh=p.hg==r['hg'];ga=p.ag==r['ag']
        xh=abs(p.hxg-r['hxg']) if p.hxg is not None and r['hxg'] is not None else None
        xa=abs(p.axg-r['axg']) if p.axg is not None and r['axg'] is not None else None
        matched.append({'pitchapi_date':p.kickoff.date().isoformat(),
                        'footystats_date':r['date'].isoformat(),
                        'pitchapi_team_ids':[p.home,p.away],
                        'footystats_names':[h,a],
                        'date_offset_days':(r['date']-p.kickoff.date()).days,
                        'goals_pitchapi':[p.hg,p.ag],
                        'goals_footystats':[r['hg'],r['ag']],
                        'goals_match':gh and ga,
                        'xg_pitchapi':[p.hxg,p.axg],
                        'xg_footystats':[r['hxg'],r['axg']],
                        'absolute_xg_difference':[xh,xa]})
    diffs=[d for r in matched for d in r['absolute_xg_difference'] if d is not None]
    mismatches=[r for r in matched if not r['goals_match']]
    return {'status':'EXTERNAL_AUDIT_ONLY_NOT_MODEL_INPUT',
            'model_training_allowed_from_footystats':False,
            'mapping':'EXPLICIT_OPERATOR_REVIEW_REQUIRED; names/IDs are not auto-inferred',
            'pitchapi_quality':pa_qa,
            'footystats_source_role':'READ_ONLY_COMPARISON',
            'pitchapi_n':len(pa),'footystats_n':len(fs),
            'matched_n':len(matched),'unmatched_pitchapi_n':len(unmatched),
            'unmapped_pitchapi_n':len(unmapped),'ambiguous_pitchapi_n':len(ambiguous),
            'unmatched_footystats_n':len(fs)-len(used),
            'goal_mismatch_n':len(mismatches),
            'goal_agreement_rate':(1-len(mismatches)/len(matched)) if matched else None,
            'xg_comparable_team_observations':len(diffs),
            'mean_absolute_xg_discrepancy':sum(diffs)/len(diffs) if diffs else None,
            'xg_difference_reference_threshold':xg_reference_difference,
            'xg_observations_above_reference_threshold':sum(v>xg_reference_difference for v in diffs),
            'limitations':['PitchAPI and FootyStats xG may have distinct model definitions and rounding',
                           'Agreement between two providers does not prove official correctness',
                           'Historical archive point-in-time revisions remain unaudited',
                           'FootyStats has zero access to prediction, fit, model choice and calibration'],
            'goal_mismatches':mismatches,'unmapped_pitchapi':unmapped,
            'unmatched_pitchapi':unmatched,'ambiguous_pitchapi':ambiguous,
            'matched':matched}


def main(argv=None):
    p=argparse.ArgumentParser(description='Independent read-only PitchAPI/FootyStats cross-provider audit; never trains GA3')
    p.add_argument('--pitchapi',nargs='+',required=True,help='PitchAPI JSON archive paths')
    p.add_argument('--footystats',nargs='+',required=True,help='FootyStats Match Stats CSV paths')
    p.add_argument('--team-map',required=True,help='Explicitly reviewed native ID -> FootyStats name JSON')
    p.add_argument('--max-days',type=int,choices=(0,1),default=1)
    p.add_argument('--output')
    a=p.parse_args(argv)
    result=compare_sources(a.pitchapi,a.footystats,a.team_map,a.max_days)
    txt=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)
    if a.output:
        target=Path(a.output);target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(txt,encoding='utf-8');print(f'Wrote {target}')
    else:print(txt)
    return 0

if __name__=='__main__':sys.exit(main())
