"""BETPILOT Goal Analyzer 3.0 research implementation (no betting recommendations)."""
__version__ = "3.0.0-rc2"
from .data import Match, DataError
from .model import RidgePoisson, ModelConfig
from .probability import joint_scores, market_probs
