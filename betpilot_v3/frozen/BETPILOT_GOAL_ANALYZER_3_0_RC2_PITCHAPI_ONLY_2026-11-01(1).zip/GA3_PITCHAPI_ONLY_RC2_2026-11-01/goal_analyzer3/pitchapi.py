"""PitchAPI verified archive -> GA3 exclusive historical match contract.

Accept ONLY warehouse schema and internally PASS-validated match aggregates.
Do not equate internal xG checks with independent official xG verification.
Never silently merge providers; team identifiers are provider-native.
"""
from __future__ import annotations
from datetime import datetime,timezone,timedelta
from pathlib import Path
from collections import Counter
import hashlib,json,math,re
from .data import Match,DataError,BAD_COMP,require_pitchapi

SCHEMA='BETPILOT-PITCHAPI-HISTORY-ARCHIVE-RESEARCH-v1'

def _digest(o):
    payload={k:v for k,v in o.items() if k not in ('source_digest','retrieved_at_utc')}
    encoded=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
    return hashlib.sha256(encoded.encode()).hexdigest()

def load_pitchapi(paths,league_id:str|None=None):
    records={};skipped=Counter();pins=set();last_asof=None
    for path in paths:
        file=Path(path)
        archive=json.loads(file.read_text(encoding='utf-8'))
        if archive.get('schema')!=SCHEMA or archive.get('provider')!='PitchAPI':
            raise DataError(f'Unknown PitchAPI archive schema/provider: {file}')
        league=archive.get('league')
        if not isinstance(league,dict) or not league.get('id') or not league.get('name'):
            raise DataError('Missing pinned league identity')
        pin=(str(league.get('id')),str(league.get('name')),str(league.get('country')))
        if BAD_COMP.search(pin[1]):raise DataError('Nonstandard competition')
        if league_id is not None and pin[0]!=str(league_id):raise DataError('League pin mismatch')
        pins.add(pin)
        if len(pins)!=1:raise DataError('Archives from multiple leagues: forbidden')
        date_asof=archive.get('as_of_utc_date')
        if not isinstance(date_asof,str):raise DataError('Missing archive-as-of')
        asof=datetime.fromisoformat(date_asof).replace(tzinfo=timezone.utc)
        last_asof=max(last_asof,asof) if last_asof else asof
        if not isinstance(archive.get('records'),dict):raise DataError('No PitchAPI records mapping')
        skipped['archived_warning']+=len(archive.get('warnings',{}))
        skipped['archived_rejected']+=len(archive.get('rejected',{}))
        for mid,r in archive['records'].items():
            if str(r.get('match_id'))!=str(mid) or str(r.get('league_id'))!=pin[0]:
                raise DataError('Inconsistent match or league ID')
            if r.get('qa_internal')!='PASS':raise DataError('Non-pass PitchAPI match in accepted records')
            if r.get('source_digest')!=_digest(r):raise DataError('PitchAPI digest mismatch')
            if mid in records:
                if _digest(records[mid])!=_digest(r):raise DataError('Conflicting repeated fixture')
                skipped['duplicate_identical_snapshot']+=1;continue
            records[mid]=r
    if not pins:raise DataError('No archives supplied')
    output=[];comp='PitchAPI:'+next(iter(pins))[0]
    for mid,r in records.items():
        # archive carries only YYYY-MM-DD; assume 00:00 UTC for conservative
        # availability and add 3 full days (day uncertainty + 2 days).
        dt=datetime.fromisoformat(r['date']).replace(tzinfo=timezone.utc)
        if dt+timedelta(days=3)>last_asof:raise DataError('Record not sufficiently old versus archive as-of')
        home,away=r['home'],r['away']
        if not all(isinstance(x,dict) for x in (home,away)) or home.get('id')==away.get('id'):
            raise DataError('Invalid team payload')
        def number(obj,key,kind):
            x=obj.get(key)
            if kind=='g':
                if type(x)!=int or not 0<=x<=30:raise DataError('Invalid score')
            else:
                if not isinstance(x,(int,float)) or isinstance(x,bool) or not math.isfinite(x) or not 0<=x<=15:
                    raise DataError('Invalid xG')
            return x
        h,a=(str(v['id']) for v in (home,away))
        if not h or not a or h==a:raise DataError('Invalid team IDs')
        season=str(r.get('season') or '')
        if not season:raise DataError('Missing season')
        output.append(Match(dt,h,a,number(home,'goals','g'),number(away,'goals','g'),season,comp,
                            provider='PitchAPI',hxg=number(home,'xg','x'),axg=number(away,'xg','x')))
    output.sort(key=lambda r:(r.kickoff,r.home,r.away))
    require_pitchapi(output)
    return output,{'provider':'PitchAPI','competition':comp,'n_completed':len(output),
                   'source_quality':'INTERNAL_PASS_ONLY; OFFICIAL_XG_NOT_INDEPENDENTLY_VERIFIED',
                   'date_precision':'DAY_ONLY','required_result_lag_days':3,
                   'archive_asof_max':last_asof.isoformat(),'point_in_time_original_publication_verified':False,'skipped':dict(skipped)}
