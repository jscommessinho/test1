"""Canonical *PitchAPI-only* observation contract for GA3 prediction.

No FootyStats ingestion or model feature building exists in this module.
PitchAPI archives contain calendar dates, NOT exact kickoff timestamps. The
`kickoff` attribute is the UTC start of that date (historical ordering proxy),
and availability is deliberately delayed by three full calendar days.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta
import math,re

BAD_COMP = re.compile(r'esoccer|efootball|futsal|indoor|beach soccer|\b\d+\s*mins?\s*play\b|kings league|queens league|socca',re.I)

class DataError(ValueError):
    pass

@dataclass(frozen=True)
class Match:
    kickoff: datetime
    home: str                 # provider-native ID, not a club display name
    away: str
    hg: int
    ag: int
    season: str
    competition: str         # must be 'PitchAPI:<pinned league ID>'
    provider: str            # must be EXACTLY 'PitchAPI', never defaulted
    hxg: float | None = None
    axg: float | None = None

    def __post_init__(self):
        if self.provider != 'PitchAPI':
            raise DataError('GA3 predictions accept ONLY PitchAPI records; FootyStats is verification-only')
        if not isinstance(self.competition,str) or not self.competition.startswith('PitchAPI:') or not self.competition[9:] or BAD_COMP.search(self.competition):
            raise DataError('Missing or nonstandard PitchAPI pinned competition')
        if self.kickoff.tzinfo is None or self.kickoff.utcoffset() is None:
            raise DataError('Historical date needs a timezone-aware UTC timestamp')
        if not self.home or not self.away or self.home == self.away:
            raise DataError('Invalid provider-native team identities')
        if not isinstance(self.season,str) or not self.season:
            raise DataError('Season is required')
        for v in (self.hg,self.ag):
            if type(v) is not int or not 0<=v<=30:
                raise DataError('Invalid completed-match goal count')
        for v in (self.hxg,self.axg):
            if v is not None and (isinstance(v,bool) or not isinstance(v,(float,int)) or not math.isfinite(v) or not 0<=v<=15):
                raise DataError('Invalid historical PitchAPI xG')

    @property
    def available(self):
        return self.kickoff + timedelta(days=3)

    @property
    def key(self):
        return (self.competition,self.season,self.kickoff,self.home,self.away)


def require_pitchapi(rows):
    """Enforce provenance even for externally supplied Python lists, not just CLI."""
    if not rows:
        raise DataError('No PitchAPI match history')
    for r in rows:
        if not isinstance(r, Match) or r.provider != 'PitchAPI' or not r.competition.startswith('PitchAPI:'):
            raise DataError('Only validated PitchAPI Match inputs are permitted')
    if len({r.competition for r in rows})!=1:
        raise DataError('Mixed leagues are prohibited')
    if len({r.key for r in rows})!=len(rows):
        raise DataError('Duplicate historical fixtures')
    return rows
