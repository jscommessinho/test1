"""Chronological selection/calibration/independent test, never odds-dependent.
The final test is ONLY reported, never used to choose the model.
"""
from __future__ import annotations
from datetime import datetime,timezone,timedelta
from collections import defaultdict
from dataclasses import asdict
import math
import numpy as np
from scipy.stats import poisson
from .model import ModelConfig,RidgePoisson
from .data import require_pitchapi
from .probability import joint_scores,market_probs

UTC=timezone.utc

def day(s):return datetime.strptime(s,'%Y-%m-%d').replace(tzinfo=UTC)
def first_of_month(d):return d.replace(day=1,hour=0,minute=0,second=0,microsecond=0)

def league_baseline(rows,cutoff,decay=None):
    require_pitchapi(rows)
    rr=[r for r in rows if r.available<=cutoff and r.kickoff<cutoff]
    if not rr:raise ValueError('no past matches')
    weights=np.ones(len(rr)) if decay is None else np.array([2**(-((cutoff-r.kickoff).total_seconds()/86400)/decay) for r in rr])
    return tuple(float(np.average([getattr(r,col) for r in rr],weights=weights)) for col in ('hg','ag'))

def predict_period(rows,start,end,config=None,scale=1,baseline=None):
    require_pitchapi(rows)
    start,end=day(start),day(end)
    if start>=end:raise ValueError('bad period')
    target=[r for r in rows if start<=r.kickoff<end]
    out=[];models={}
    for r in target:
        cut=first_of_month(r.kickoff)
        if cut not in models:
            models[cut]=(RidgePoisson(config).fit(rows,cut) if config is not None else None)
        if config is not None:
            lh,la=models[cut].predict(r.home,r.away,as_of=r.kickoff)
        else:
            lh,la=league_baseline(rows,cut,decay=baseline)
        out.append(dict(key=str(r.key),kickoff=r.kickoff.isoformat(),home=r.home,away=r.away,
                        hg=r.hg,ag=r.ag,lh=lh*scale,la=la*scale,fit_cutoff=cut.isoformat(),
                        train_n=models[cut].train_n if config else None))
    return out

def evaluate(preds):
    if not preds:raise ValueError('no eval predictions')
    losses=[]; brier=defaultdict(list);cal=defaultdict(list)
    for r in preds:
        lh,la=r['lh'],r['la']
        nll=-poisson.logpmf(r['hg'],lh)-poisson.logpmf(r['ag'],la)
        losses.append(float(nll))
        g,_=joint_scores(lh,la);p=market_probs(g)
        h,a=r['hg'],r['ag'];y={"btts_yes":int(h>0 and a>0),"over_2.5":int(h+a>=3),
                                  "home_over_0.5":int(h>0),"away_over_0.5":int(a>0),
                                  "home_win":int(h>a),"draw":int(h==a),"away_win":int(h<a)}
        for k,v in y.items():brier[k].append((p[k]-v)**2);cal[k].append((p[k],v))
        r['joint_nll']=float(nll)
        r['events']={k:{'p':p[k],'y':v} for k,v in y.items()}
    score={"n":len(preds),"joint_nll":float(np.mean(losses)),"brier":{k:float(np.mean(v)) for k,v in brier.items()},
           "mean_brier_primary":float(np.mean([np.mean(brier[k]) for k in ('btts_yes','over_2.5','home_over_0.5','away_over_0.5')]))}
    return score

def block_bootstrap_pair(ours,reference,reps=1000,seed=291026):
    if len(ours)!=len(reference) or [x['key'] for x in ours]!=[x['key'] for x in reference]:
        raise ValueError('Paired predictions must be identical fixtures in identical order')
    groups=defaultdict(list)
    for i,r in enumerate(ours):
        # ISO week is evaluated by original fixture kickoff; week blocks cluster match dependence.
        dt=datetime.fromisoformat(r['kickoff']);year,week,_=dt.isocalendar();groups[f'{year}-W{week:02d}'].append(i)
    blocks=list(groups.values());rng=np.random.default_rng(seed)
    diff=np.asarray([a['joint_nll']-b['joint_nll'] for a,b in zip(ours,reference)])
    draws=[]
    for _ in range(reps):
        order=rng.integers(0,len(blocks),len(blocks));inds=[i for k in order for i in blocks[k]]
        draws.append(float(np.mean(diff[inds])))
    return {"n_calendar_week_blocks":len(blocks),"mean_delta_joint_nll":float(np.mean(diff)),
            "ci_95_percentile":[float(x) for x in np.quantile(draws,[.025,.975])],
            "negative_is_better":True}

def run_backtest(rows,selection=('2024-08-01','2025-01-01'),calibration=('2025-01-01','2025-06-01'),
                 test=('2025-08-01','2026-06-01'),allow_experimental_pitchapi_xg=False):
    require_pitchapi(rows)
    if not (day(selection[1])<=day(calibration[0])<day(calibration[1])<=day(test[0])<day(test[1])):
        raise ValueError('Overlapping temporal splits')
    cand=[ModelConfig(365,10,True,0),ModelConfig(180,10,True,0),ModelConfig(365,10,False,0)]
    # Explicit opt-in required: PitchAPI xG still lacks independent definition verification.
    if allow_experimental_pitchapi_xg and all(r.hxg is not None and r.axg is not None for r in rows):
        cand += [ModelConfig(365,10,True,.5),ModelConfig(180,10,True,.5)]
    selection_scores=[]
    for cfg in cand:
        pred=predict_period(rows,*selection,config=cfg)
        sc=evaluate(pred)
        selection_scores.append({'config':asdict(cfg),'metrics':sc})
    selection_scores.sort(key=lambda x:x['metrics']['joint_nll'])
    # Parsimony rule: if GA2 reference within 0.002 NLL of best, keep GA2 specification.
    top=selection_scores[0]
    ref=next(x for x in selection_scores if x['config']['half_life']==365 and x['config']['ridge']==10 and x['config']['venue'] and x['config']['xg_blend']==0)
    if ref['metrics']['joint_nll'] <= top['metrics']['joint_nll']+.002:top=ref
    selected=ModelConfig(**top['config'])
    cal_pred=predict_period(rows,*calibration,config=selected)
    unscaled=evaluate(cal_pred)
    proposed_scale=sum(x['hg']+x['ag'] for x in cal_pred)/sum(x['lh']+x['la'] for x in cal_pred)
    if not .6<=proposed_scale<=1.4:proposed_scale=1.
    scaled=evaluate([{**x,'lh':x['lh']*proposed_scale,'la':x['la']*proposed_scale} for x in cal_pred])
    scale=proposed_scale if (scaled['joint_nll']<unscaled['joint_nll'] and scaled['mean_brier_primary']<unscaled['mean_brier_primary']) else 1.
    # DO NOT use final-test outcomes until selected / scale have been locked.
    pred=predict_period(rows,*test,config=selected,scale=scale)
    reference=predict_period(rows,*test,config=ModelConfig(365,10,True,0))
    baseline=predict_period(rows,*test,baseline=None)
    decay_baseline=predict_period(rows,*test,baseline=365)
    score=evaluate(pred);refscore=evaluate(reference);bscore=evaluate(baseline);wscore=evaluate(decay_baseline)
    ci=block_bootstrap_pair(pred,reference)
    ci_league=block_bootstrap_pair(pred,baseline)
    verdict=('OUTPERFORMS_REFERENCE_95pct' if ci['ci_95_percentile'][1]<0 else 'NO_DEMONSTRATED_IMPROVEMENT')
    return {'provider':'PitchAPI','experimental_pitchapi_xg_candidates_enabled':allow_experimental_pitchapi_xg,'status':'STATISTICAL_VALIDATION_SINGLE_LEAGUE_TEST_COMPLETED','selection_window':selection,
           'calibration_window':calibration,'test_window':test,'selection_candidates':selection_scores,
           'selected_config':asdict(selected),'locked_scale':scale,
           'calibration_raw':unscaled,'calibration_scaled_candidate':scaled,
           'final_test':{'ga3':score,'ga2_config_replay':refscore,'league_average':bscore,
                         'decayed_league_average':wscore,'ga3_vs_ga2':ci,'ga3_vs_league':ci_league,
                         'scientific_verdict':verdict},
           'limitation':'Retrospective archive: source point-in-time publication/revisions unverified; GA2-config replay only, not original frozen historical dataset; single-league validation.',
           'per_fixture_predictions':pred}
