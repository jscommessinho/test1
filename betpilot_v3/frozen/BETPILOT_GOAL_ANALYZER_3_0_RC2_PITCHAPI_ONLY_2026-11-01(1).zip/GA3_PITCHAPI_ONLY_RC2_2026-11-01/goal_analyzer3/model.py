"""Regularized dynamic Poisson log-linear attack/defence intensities.

GA2 reference: half-life 365 days, ridge 10, venue=True, target_blend=0.
The xG pseudo-count candidate is a quasi-likelihood, *not* a Poisson likelihood
on xG observations. It must outperform the reference on independent match goals.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime,timezone
import math
import numpy as np
from scipy.optimize import minimize
from .data import Match,require_pitchapi

@dataclass(frozen=True)
class ModelConfig:
    half_life: float = 365.
    ridge: float = 10.
    venue: bool = True
    xg_blend: float = 0.
    min_train: int = 150
    def __post_init__(self):
        if self.half_life<=0 or self.ridge<0 or not 0<=self.xg_blend<=1 or self.min_train<1:
            raise ValueError("Invalid model config")

class RidgePoisson:
    def __init__(self, config: ModelConfig=ModelConfig()):
        self.config=config

    def _design(self,home:str,away:str)->np.ndarray:
        n=len(self.teams)
        x=np.zeros((2,2+n*(4 if self.config.venue else 2)))
        x[:,0]=1;x[0,1]=1
        for side,(team,opp) in enumerate(((home,away),(away,home))):
            if team in self.idx:
                j=self.idx[team];x[side,2+j]=1
                if self.config.venue:x[side,2+2*n+j]=1 if side==0 else -1
            if opp in self.idx:
                j=self.idx[opp];x[side,2+n+j]=1
                if self.config.venue:x[side,2+3*n+j]=1 if side==1 else -1
        return x

    def fit(self, rows:list[Match], cutoff:datetime):
        require_pitchapi(rows)
        if cutoff.tzinfo is None:raise ValueError("cutoff must be aware")
        rr=[r for r in rows if r.available<=cutoff and r.kickoff<cutoff]
        if len(rr)<self.config.min_train:raise ValueError(f"Training history insufficient: {len(rr)}")
        if len({r.competition for r in rr})!=1:raise ValueError("Cross-competition pooling prohibited")
        if self.config.xg_blend>0 and any(r.hxg is None or r.axg is None for r in rr):
            raise ValueError("xG candidate requires 100% valid historical xG; use goals-only fallback")
        self.teams=sorted({r.home for r in rr}|{r.away for r in rr})
        self.idx={t:i for i,t in enumerate(self.teams)}
        X=np.vstack([self._design(r.home,r.away) for r in rr])
        goals=np.asarray([v for r in rr for v in (r.hg,r.ag)],dtype=float)
        if self.config.xg_blend>0:
            xg=np.asarray([v for r in rr for v in (r.hxg,r.axg)],dtype=float)
            y=(1-self.config.xg_blend)*goals+self.config.xg_blend*xg
        else:y=goals
        ages=np.array([(cutoff-r.kickoff).total_seconds()/86400 for r in rr])
        w=np.repeat(2**(-ages/self.config.half_life),2)
        penalty=np.full(X.shape[1],self.config.ridge,dtype=float);penalty[:2]=0
        if self.config.venue:penalty[2+2*len(self.teams):]*=4
        def objective(beta):
            z=np.clip(X@beta,-20,20)
            mu=np.exp(z)
            loss=(w*(mu-y*z)).sum()+.5*(penalty*beta**2).sum()
            grad=X.T@(w*(mu-y))+penalty*beta
            return float(loss),grad
        initial=np.zeros(X.shape[1]);initial[0]=math.log(max(np.average(y,weights=w),.001))
        result=minimize(objective,initial,jac=True,method='L-BFGS-B',options={'maxiter':1500,'ftol':1e-10,'gtol':1e-6})
        if not result.success and np.linalg.norm(result.jac)>1e-3:
            raise RuntimeError(f"Optimizer failed: {result.message}")
        self.beta=result.x
        self.cutoff=cutoff
        self.train_n=len(rr)
        ww=w[::2];self.ess=float(ww.sum()**2/(ww@ww))
        self.training_last_kickoff=max(r.kickoff for r in rr)
        self.competition=rr[0].competition
        self.provider="PitchAPI"
        return self

    def predict(self,home:str,away:str,as_of:datetime|None=None):
        if not hasattr(self,'beta'):raise RuntimeError("Unfitted model")
        if home==away:raise ValueError("Same team")
        if as_of is not None and as_of<self.cutoff:raise ValueError("Prediction predates model fit")
        z=self._design(home,away)@self.beta
        lh,la=tuple(float(x) for x in np.exp(np.clip(z,-12,12)))
        if not (0<lh<100 and 0<la<100):raise ValueError("Implausible intensities; abstain")
        return lh,la

    def metadata(self):
        return {"config":asdict(self.config),"cutoff":self.cutoff.isoformat(),"train_n":self.train_n,
                "train_ess":self.ess,"provider":"PitchAPI","competition":self.competition,"unseen_policy":"zero team effects (league baseline)",
                "training_last_kickoff":self.training_last_kickoff.isoformat()}
