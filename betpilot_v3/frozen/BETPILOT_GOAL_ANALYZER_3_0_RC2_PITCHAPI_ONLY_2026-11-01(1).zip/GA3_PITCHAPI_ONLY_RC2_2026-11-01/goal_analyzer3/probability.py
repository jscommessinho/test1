"""Joint score grid and internally consistent derived markets.
Dixon-Coles is optional and allowed only if all four correction factors > 0.
"""
from __future__ import annotations
import math
import numpy as np
from scipy.stats import poisson

def tau_factors(lh:float,la:float,rho:float):
    return (1-lh*la*rho,1+lh*rho,1+la*rho,1-rho)

def joint_scores(lh:float,la:float,dist:str='poisson',rho:float=0.,tail_tol:float=1e-12):
    if not (math.isfinite(lh) and math.isfinite(la) and 0<lh<100 and 0<la<100):
        raise ValueError("Positive finite lambda required")
    if not 0<tail_tol<1e-5:raise ValueError("Invalid tolerance")
    if dist not in ('poisson','dixon_coles'):raise ValueError("Unrecognized distribution")
    if dist=='dixon_coles' and min(tau_factors(lh,la,rho))<=0:
        raise ValueError("Invalid Dixon-Coles rho at current lambda; abstain")
    k=int(max(8,poisson.ppf(1-tail_tol/2,lh),poisson.ppf(1-tail_tol/2,la)))
    axis=np.arange(k+1)
    G=np.outer(poisson.pmf(axis,lh),poisson.pmf(axis,la))
    if dist=='dixon_coles':
        t=tau_factors(lh,la,rho)
        G[0,0]*=t[0];G[0,1]*=t[1];G[1,0]*=t[2];G[1,1]*=t[3]
    residual=float(1-G.sum())
    if residual>tail_tol*3 or residual< -1e-10:
        raise ArithmeticError(f"Excessive / negative probability mass: {residual}")
    G/=G.sum() # only numerical tail of <= 3e-12; reported separately
    if (G<0).any():raise ArithmeticError("Negative joint mass")
    return G,max(0,residual)

def market_probs(G:np.ndarray)->dict[str,float]:
    h,a=np.indices(G.shape)
    t=h+a
    probs={"home_win":float(G[h>a].sum()),"draw":float(G[h==a].sum()),"away_win":float(G[h<a].sum()),
           "btts_yes":float(G[(h>0)&(a>0)].sum()),
           "btts_no":float(G[(h==0)|(a==0)].sum())}
    for i in range(0,7):
        probs[f'over_{i}.5']=float(G[t>=i+1].sum())
        probs[f'under_{i}.5']=float(G[t<=i].sum())
        probs[f'home_over_{i}.5']=float(G[h>=i+1].sum())
        probs[f'home_under_{i}.5']=float(G[h<=i].sum())
        probs[f'away_over_{i}.5']=float(G[a>=i+1].sum())
        probs[f'away_under_{i}.5']=float(G[a<=i].sum())
    return probs

def validate_market_probs(G,probs,tol=1e-9):
    if not np.isclose(G.sum(),1,atol=tol):raise AssertionError("Joint not normalized")
    if np.min(G)<0 or max(probs.values())>1+tol or min(probs.values())<0:raise AssertionError("Invalid probability")
    for x,y in [('btts_yes','btts_no'),('home_win','draw')]:
        pass
    if not np.isclose(probs['home_win']+probs['draw']+probs['away_win'],1,atol=tol):raise AssertionError("1X2")
    if not np.isclose(probs['btts_yes']+probs['btts_no'],1,atol=tol):raise AssertionError("BTTS")
    for prefix in ('','home_','away_'):
        for i in range(7):
            if not np.isclose(probs[f'{prefix}over_{i}.5']+probs[f'{prefix}under_{i}.5'],1,atol=tol):raise AssertionError('Over/Under')
            if i and probs[f'{prefix}over_{i}.5']>probs[f'{prefix}over_{i-1}.5']+tol:raise AssertionError('Non-monotone over')
    return True

def predict_markets(lh,la,dist='poisson',rho=0.):
    G,tail=joint_scores(lh,la,dist,rho)
    p=market_probs(G);validate_market_probs(G,p)
    return {'lambda_home':lh,'lambda_away':la,'distribution':dist,'rho':rho,'tail_truncation':tail,
            'markets':p,'exact_scores':G.tolist(),'score_axis_max':G.shape[0]-1}
