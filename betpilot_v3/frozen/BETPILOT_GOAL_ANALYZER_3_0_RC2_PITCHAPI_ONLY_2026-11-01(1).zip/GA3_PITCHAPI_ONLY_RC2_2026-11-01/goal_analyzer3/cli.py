"""Production-facing research CLI: PitchAPI historical archives ONLY.

FootyStats comparison lives in the *separate* external_audit module and can
never be invoked through `predict` or `backtest`.
"""
from __future__ import annotations
import argparse,json,sys
from datetime import datetime
from pathlib import Path
from .pitchapi import load_pitchapi
from .evaluation import run_backtest,first_of_month
from .model import ModelConfig,RidgePoisson
from .probability import predict_markets


def main(argv=None):
    ap=argparse.ArgumentParser(description='BETPILOT GA3 RC2 — PitchAPI-only research engine')
    sub=ap.add_subparsers(dest='command',required=True)
    for c in ('audit','backtest','predict'):
        p=sub.add_parser(c)
        p.add_argument('files',nargs='+',help='PitchAPI history warehouse JSON archive(s)')
        p.add_argument('--league-id',required=True,help='Exact pinned PitchAPI league ID')
        p.add_argument('--output',help='Output JSON; defaults to stdout')
        if c=='predict':
            p.add_argument('--home',required=True,help='Native PitchAPI home team ID')
            p.add_argument('--away',required=True,help='Native PitchAPI away team ID')
            p.add_argument('--as-of',required=True,help='Prediction UTC ISO time, before actual kickoff')
            p.add_argument('--config-json',help='Validated model configuration JSON')
            p.add_argument('--allow-experimental-pitchapi-xg',action='store_true',help='Explicit opt-in; xG experimental and unvalidated')
        if c=='backtest':
            p.add_argument('--allow-experimental-pitchapi-xg',action='store_true',help='Explicit opt-in; after separate data audit')
            for n in ('selection-start','selection-end','calibration-start','calibration-end','test-start','test-end'):
                p.add_argument('--'+n,required=True,help='Required YYYY-MM-DD chronological window')
    args=ap.parse_args(argv)
    rows,audit=load_pitchapi(args.files,league_id=args.league_id)
    if args.command=='predict':
        as_of=datetime.fromisoformat(args.as_of.replace('Z','+00:00'))
        if as_of.tzinfo is None:ap.error('--as-of must be timezone aware')
        if args.home==args.away:ap.error('Teams cannot be the same')
        cfg=ModelConfig(**json.loads(args.config_json)) if args.config_json else ModelConfig()
        if cfg.xg_blend>0 and not args.allow_experimental_pitchapi_xg:
            ap.error('xG needs --allow-experimental-pitchapi-xg explicit opt-in')
        fitted=RidgePoisson(cfg).fit(rows,first_of_month(as_of))
        lh,la=fitted.predict(args.home,args.away,as_of=as_of)
        output={'status':'RESEARCH_ONLY_NOT_VALIDATED_FOR_PRODUCTION','provider':'PitchAPI',
                'as_of':as_of.isoformat(),'teams':[args.home,args.away],
                'model':fitted.metadata(),'quality':audit,'prediction':predict_markets(lh,la),
                'point_in_time_original_publication_verified':False}
    elif args.command=='audit':
        output=audit
    else:
        output=run_backtest(rows,selection=(args.selection_start,args.selection_end),
             calibration=(args.calibration_start,args.calibration_end),test=(args.test_start,args.test_end),
             allow_experimental_pitchapi_xg=args.allow_experimental_pitchapi_xg)
        output['quality']=audit
    raw=json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False)
    if args.output:
        path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(raw,encoding='utf-8')
        print(f'Wrote {path} ({len(raw)} chars)')
    else:print(raw)
    return 0

if __name__=='__main__':sys.exit(main())
