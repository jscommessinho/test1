from datetime import datetime,timedelta,timezone
import numpy as np
import pytest
from goal_analyzer3.data import Match,DataError
from goal_analyzer3.model import ModelConfig,RidgePoisson
from goal_analyzer3.probability import joint_scores,market_probs,validate_market_probs,predict_markets
from goal_analyzer3.evaluation import predict_period,block_bootstrap_pair,run_backtest

UTC=timezone.utc

def make_rows(n=160):
    start=datetime(2023,8,1,tzinfo=UTC)
    return [Match(start+timedelta(days=2*i),f'Team{i%6}',f'Team{(i+1)%6}',
                  (i*7)%4,(i*5)%3,'2023/2024','PitchAPI:league',provider='PitchAPI',hxg=1.4,axg=.9) for i in range(n)]

@pytest.mark.parametrize('lh,la',[(.07,.08),(.8,1.2),(1.5,1.8),(4.,4.),(14.,11.)])
def test_joint_markets(lh,la):
    g,tail=joint_scores(lh,la)
    assert 0<=tail<1e-10
    assert validate_market_probs(g,market_probs(g))
    assert abs(g.sum()-1)<1e-12
    assert abs(g[0,0]-np.exp(-lh-la))<1e-9

@pytest.mark.parametrize('rho',[-.05,.02])
def test_dixon_coles(rho):
    g,tail=joint_scores(1.5,1.2,'dixon_coles',rho)
    assert validate_market_probs(g,market_probs(g))
    assert g[0,0]>0

def test_invalid_parameters():
    for lh,la in [(0,1),(1,-1),(float('nan'),2),(300,1)]:
        with pytest.raises(ValueError):joint_scores(lh,la)
    with pytest.raises(ValueError):joint_scores(3.,4.,'dixon_coles',1.0)

def test_known_fixture_leakage_removed():
    rr=make_rows()
    cutoff=rr[150].kickoff
    m=RidgePoisson(ModelConfig(min_train=140)).fit(rr,cutoff)
    assert m.training_last_kickoff<=cutoff-timedelta(days=2)
    assert m.train_n==149  # date-only PitchAPI fixture+3 day conservative availability
    # A future fixture changing its score must not change the previous fit.
    rr2=rr[:150]+[Match(r.kickoff,r.home,r.away,17,12,r.season,r.competition,r.provider,r.hxg,r.axg) for r in rr[150:]]
    m2=RidgePoisson(ModelConfig(min_train=140)).fit(rr2,cutoff)
    assert np.allclose(m.beta,m2.beta)

def test_no_new_team_prior():
    m=RidgePoisson(ModelConfig(min_train=100)).fit(make_rows(),datetime(2024,8,1,tzinfo=UTC))
    lh,la=m.predict('Unseen','Another')
    assert lh>0 and la>0
    assert m.metadata()['train_n']==160

def test_xg_requires_coverage():
    rr=make_rows();r=rr[-1];rr[-1]=Match(r.kickoff,r.home,r.away,r.hg,r.ag,r.season,r.competition,provider='PitchAPI')
    with pytest.raises(ValueError):RidgePoisson(ModelConfig(min_train=100,xg_blend=.5)).fit(rr,datetime(2024,8,1,tzinfo=UTC))

def test_competition_guard():
    rr=make_rows();r=rr[-1];rr[-1]=Match(r.kickoff,r.home,r.away,r.hg,r.ag,r.season,'PitchAPI:Other',provider='PitchAPI',hxg=1,axg=2)
    with pytest.raises(ValueError):RidgePoisson(ModelConfig(min_train=100)).fit(rr,datetime(2024,8,1,tzinfo=UTC))

def test_footystats_cannot_enter_predictor(tmp_path):
    import inspect
    from goal_analyzer3 import cli
    assert 'load_footystats' not in inspect.getsource(cli)
    assert not hasattr(__import__('goal_analyzer3'), 'load_footystats')
    with pytest.raises(DataError,match='ONLY PitchAPI'):
        Match(datetime(2024,1,1,tzinfo=UTC),'h','a',1,2,'2023/2024',
              'PitchAPI:league',provider='FootyStats',hxg=1.,axg=2.)
    with pytest.raises(SystemExit):
        cli.main(['audit','/tmp/example.csv','--league-id','ita-seriea','--provider','footystats'])

def test_pair_bootstrap_rejects_nonmatching():
    with pytest.raises(ValueError):block_bootstrap_pair([{'key':'a'}],[{'key':'b'}])

def test_analytic_btts_independent():
    lamh,lama=1.24,1.6
    p=predict_markets(lamh,lama)['markets']['btts_yes']
    assert abs(p-(1-np.exp(-lamh))*(1-np.exp(-lama)))<1e-9

def test_pitchapi_archive_integrity(tmp_path):
    import json
    from goal_analyzer3.pitchapi import SCHEMA,_digest,load_pitchapi
    rec={'match_id':'m001','league_id':'ita-seriea','season':'2025/2026','date':'2025-10-01',
         'qa_internal':'PASS','home':{'id':'h01','name':'A','goals':2,'xg':1.22},
         'away':{'id':'a01','name':'B','goals':1,'xg':.97},'qa_external':'OFFICIAL_REFERENCE_NOT_VERIFIED'}
    rec['source_digest']=_digest(rec)
    a={'schema':SCHEMA,'provider':'PitchAPI','league':{'id':'ita-seriea','name':'Serie A','country':'IT'},
       'as_of_utc_date':'2025-11-01','records':{'m001':rec},'warnings':{},'rejected':{}}
    f=tmp_path/'archive.json';f.write_text(json.dumps(a))
    rows,qa=load_pitchapi([f],league_id='ita-seriea')
    assert len(rows)==1 and qa['date_precision']=='DAY_ONLY'
    assert rows[0].available==datetime(2025,10,4,tzinfo=UTC)
    a['records']['m001']['home']['xg']=9
    f.write_text(json.dumps(a))
    with pytest.raises(DataError):load_pitchapi([f],league_id='ita-seriea')

def test_monthly_pseudodata_end_to_end():
    # Synthetic-only functional check. This says nothing about betting accuracy.
    from goal_analyzer3.evaluation import run_backtest
    rng=np.random.default_rng(12)
    rows=[]
    d0=datetime(2023,8,1,tzinfo=UTC)
    clubs=[f'C{i}' for i in range(12)]
    for i in range(1030):
        h,a=rng.choice(clubs,size=2,replace=False)
        date=d0+timedelta(days=i)
        rows.append(Match(date,h,a,int(rng.poisson(1.5)),int(rng.poisson(1.2)),
                          str(date.year),'PitchAPI:SyntheticTest',provider='PitchAPI',hxg=float(rng.gamma(2, .7)),axg=float(rng.gamma(2,.6))))
    z=run_backtest(rows)
    assert z['final_test']['ga3']['n']>250
    assert all(0<r['lh']<100 and 0<r['la']<100 for r in z['per_fixture_predictions'])
    assert z['final_test']['ga3_vs_ga2']['n_calendar_week_blocks']>=30
    assert z['status'].startswith('STATISTICAL_VALIDATION')

def test_source_audit_is_separate_and_scores_are_not_training_features(tmp_path):
    import json
    from goal_analyzer3.pitchapi import _digest, SCHEMA
    from goal_analyzer3.external_audit import compare_sources
    rec={'match_id':'m001','league_id':'ita-seriea','season':'2025/2026','date':'2025-10-01',
         'qa_internal':'PASS','home':{'id':'h01','name':'A','goals':2,'xg':1.20},
         'away':{'id':'a01','name':'B','goals':1,'xg':.90},
         'qa_external':'OFFICIAL_REFERENCE_NOT_VERIFIED'}
    rec['source_digest']=_digest(rec)
    arc={'schema':SCHEMA,'provider':'PitchAPI','league':{'id':'ita-seriea','name':'Serie A','country':'IT'},
         'as_of_utc_date':'2025-11-01','records':{'m001':rec},'warnings':{},'rejected':{}}
    archive=tmp_path/'pitchapi.json';archive.write_text(json.dumps(arc))
    file=tmp_path/'italy-serie-a-matches-2025-to-2026-stats.csv'
    file.write_text('timestamp,status,home_team_name,away_team_name,home_team_goal_count,away_team_goal_count,team_a_xg,team_b_xg\n'
                    '1759276800,complete,Team A,Team B,2,1,1.60,1.10\n')
    mapping=tmp_path/'mapping.json'
    mapping.write_text(json.dumps({'pitchapi_league_id':'ita-seriea',
                                   'team_id_to_footystats_name':{'h01':'Team A','a01':'Team B'}}))
    report=compare_sources([archive],[file],mapping)
    assert report['matched_n']==1 and report['goal_mismatch_n']==0
    assert report['xg_comparable_team_observations']==2
    assert report['model_training_allowed_from_footystats'] is False
    assert report['mean_absolute_xg_discrepancy']>0
    with pytest.raises(DataError,match='Ambiguous mapped'):
        mapping.write_text(json.dumps({'pitchapi_league_id':'ita-seriea',
                   'team_id_to_footystats_name':{'h01':'Same','a01':'Same'}}))
        compare_sources([archive],[file],mapping)


def test_only_pitchapi_backtest_not_cross_providers():
    from dataclasses import replace
    rr=make_rows()
    with pytest.raises(DataError,match='ONLY PitchAPI'):
        replace(rr[0],provider='FootyStats')
    with pytest.raises(DataError,match='Mixed leagues'):
        from goal_analyzer3.data import require_pitchapi
        require_pitchapi(rr+[replace(rr[0],competition='PitchAPI:other')])


def test_external_audit_cannot_be_imported_by_core():
    import inspect
    import goal_analyzer3.model as model
    import goal_analyzer3.evaluation as evaluation
    import goal_analyzer3.cli as cli
    import ast
    for module in (model,evaluation,cli):
        tree=ast.parse(inspect.getsource(module))
        imports=[node.module for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)]
        assert not any(i and ('external_audit' in i or 'footystats' in i) for i in imports)




def test_xg_candidate_requires_explicit_optin():
    import inspect
    from goal_analyzer3.evaluation import run_backtest
    assert inspect.signature(run_backtest).parameters['allow_experimental_pitchapi_xg'].default is False
    from goal_analyzer3.cli import main
    with pytest.raises(SystemExit):
        main(['predict','a.json','--league-id','ita-seriea','--provider','footystats'])


def test_source_audit_disagrees_without_rewriting_pitchapi(tmp_path):
    import json
    from goal_analyzer3.pitchapi import _digest,SCHEMA,load_pitchapi
    from goal_analyzer3.external_audit import compare_sources
    rec={'match_id':'m007','league_id':'eng-premier','season':'2025/2026','date':'2025-10-02',
         'qa_internal':'PASS','home':{'id':'h07','name':'A','goals':2,'xg':1.25},
         'away':{'id':'a07','name':'B','goals':0,'xg':.8}}
    rec['source_digest']=_digest(rec)
    a={'schema':SCHEMA,'provider':'PitchAPI','league':{'id':'eng-premier','name':'Premier League','country':'GB'},
       'as_of_utc_date':'2025-11-20','records':{'m007':rec},'warnings':{},'rejected':{}}
    af=tmp_path/'p.json';af.write_text(json.dumps(a))
    f=tmp_path/'england-premier-matches-2025-to-2026-stats.csv'
    f.write_text('timestamp,status,home_team_name,away_team_name,home_team_goal_count,away_team_goal_count,team_a_xg,team_b_xg\n'
                 '1759363200,complete,Club A,Club B,1,0,2.30,.50\n')
    mp=tmp_path/'map.json';mp.write_text(json.dumps({'pitchapi_league_id':'eng-premier',
                 'team_id_to_footystats_name':{'h07':'Club A','a07':'Club B'}}))
    before, _=load_pitchapi([af],league_id='eng-premier')
    report=compare_sources([af],[f],mp)
    after, _=load_pitchapi([af],league_id='eng-premier')
    assert report['matched_n']==1 and report['goal_mismatch_n']==1
    assert before==after
