# BETPILOT | GOAL ANALYZER 3.0 — RC2 CHECKPOINT

**Data:** 2026-11-01  
**Versione:** 3.0.0-rc2, PITCHAPI ONLY, RESEARCH ONLY

## Modifiche concrete rispetto a RC1

1. `data.py` ora definisce solo record `Match` di origine obbligatoriamente PitchAPI. Il vecchio `load_footystats` è stato eliminato dalla pipeline predittiva e dall'API pubblica.
2. `model.py` e `evaluation.py` applicano `require_pitchapi()` anche quando usati da Python senza CLI; il modello non accetta competizioni miste o record duplicati.
3. `cli.py` accetta solo archivi PitchAPI `audit/predict/backtest`. Nessun flag `--provider footystats` è accettato. Le finestre di backtest sono esplicite e obbligatorie.
4. `external_audit.py` è una funzione separata per confronto dei risultati e degli xG FootyStats/PitchAPI con mapping ID manualmente verificato. Non importa il modello né modifica i dati di training.
5. Candidati xG PitchAPI automaticamente disabilitati in `run_backtest`; richiesta esplicita `--allow-experimental-pitchapi-xg` per test opzionali. Non esiste training xG FootyStats.
6. `examples/github_actions_ga3_research.yml` aggiornato a PitchAPI; `README.md`, documentazione e manifesto aggiornati.

## Verifiche

- Test Python: **22/22 superati** (uso di fixture sintetiche esclusivamente per i controlli software).
- Sono coperti: isolamento FootyStats, integrità archivi PitchAPI, coerenza distribuzione, sicurezza temporale, audit disaccoppiato e differenze di score senza mutazione degli input.
- Un set di 4 CSV reali FootyStats era stato ispezionato nel repository nella fase RC1, ma i CSV NON sono parte del motore e non sono inclusi nel pacchetto.

## Verifiche ancora aperte

- Eseguire su veri archivi PitchAPI il backtest con split temporali adeguati e verificare quantità, distribuzione e qualità delle osservazioni.
- Abbinare in modo certo identità squadre PitchAPI/FootyStats, poi eseguire solo il confronto esterno su match reali e riesaminare le discrepanze.
- Verificare indipendentemente gli xG (modello/provenienza, differenze di definizione, revisione retroattiva). I controlli interni `/shots` vs `/stats` del medesimo provider NON bastano.
- Riprodurre GA2 su input PitchAPI identici prima di dichiarare miglioramenti; GA2-config replay non replica perfettamente il modello congelato.
- Replicare su Premier League, Serie A, La Liga, Bundesliga, Ligue 1 e altri campionati con storico completo; testare calibration e robustezza.
- Verificare gli snapshot *point-in-time* e il timestamp di pubblicazione prima di dichiarare un backtest storico senza revision leakage.

## Gate

- Technical RC2: **IMPLEMENTED AND TECHNICALLY TESTED**.
- Research complete: **NO**.
- Statistical validation complete: **NO**.
- Production ready: **NO**.

Non sono state effettuate modifiche alla branch principale GitHub, agli automi o agli Analyzer già pubblicati.
