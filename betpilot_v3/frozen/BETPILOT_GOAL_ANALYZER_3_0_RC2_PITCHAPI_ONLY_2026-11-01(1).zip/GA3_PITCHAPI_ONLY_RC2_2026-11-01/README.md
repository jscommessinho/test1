# BETPILOT | GOAL ANALYZER 3.0 — RC2 PITCHAPI ONLY

**1 novembre 2026 · Implementazione isolata · RESEARCH ONLY**

## Regola fondamentale

**L'unica fonte dei dati per le previsioni di GA3 è PitchAPI.** L'ingestione FootyStats è stata **rimossa dalla pipeline predittiva**. I CSV FootyStats sono consentiti **solo** nell'utility read-only `external_audit.py`, che confronta fonti e genera un rapporto indipendente. L'utility non può correggere, allenare, calibrare, fare backtest o modificare gli input del motore di previsione.

```text
                     ┌───────────────────────────────┐
                     │ PitchAPI historical archives  │
                     │ JSON · ID nativi · QA PASS     │
                     └──────────────┬────────────────┘
                                    │
                     ┌──────────────▼────────────────┐
                     │ pitchapi.py: integrity + QA   │
                     │ data.py: ONLY PitchAPI match  │
                     └──────────────┬────────────────┘
                                    │
          ┌─────────────────────────▼─────────────────────────┐
          │ model.py → evaluation.py → probability.py → cli.py │
          │        FIT / CALIBRATION / PREDICTION              │
          └───────────────────────────────────────────────────┘

       ┌───────────────────┐   ┌────────────────────────┐
       │ PitchAPI archive  │──▶│ external_audit.py       │──▶ audit JSON
       └───────────────────┘   │ (READ-ONLY, ISOLATED)   │
       ┌───────────────────┐   │ Explicit team-ID map   │
       │ FootyStats CSVs   │──▶│ Result + xG comparison │
       └───────────────────┘   └────────────────────────┘

  There is NO arrow from external_audit.py to any prediction component.
```

## Dati PitchAPI accettati come input del motore

- ID ufficiale della competizione *nel provider* e identificativi stabili delle squadre **nativi PitchAPI**;
- stagione e giorno della partita, stato finale / risultati casa-trasferta;
- gol segnati e subiti, da cui il modello ricostruisce attacco, difesa, vantaggio del campo e andamento temporale;
- xG per partita **solo come candidato sperimentale opzionale**: default disabilitato in model selection e prediction; serve `--allow-experimental-pitchapi-xg` e successiva verifica empirica.

Archivi input: formato JSON `BETPILOT-PITCHAPI-HISTORY-ARCHIVE-RESEARCH-v1`, con `qa_internal=PASS`, `source_digest` SHA-256 e league pin. Warning/REJECTED esclusi dagli input, non trasferiti in modo implicito. Il loader non fa chiamate all'API e non richiede chiavi. Il record contiene solo `YYYY-MM-DD`: si usa un **lag prudenziale di 3 giorni** per la disponibilità.

## Installazione e test

```bash
python -m pip install -r requirements.txt
python -m pytest -q
```

## 1 — Audit tecnico degli archivi PitchAPI

```bash
python -m goal_analyzer3.cli audit /percorso/pitchapi-archivio.json \
  --league-id eng-premier --output pitchapi_data_qa.json
```

L'ID deve corrispondere **esattamente** al league pin dell'archivio. Non utilizzare nomi team al posto degli ID provider.

## 2 — Previsione (solo PitchAPI)

```bash
python -m goal_analyzer3.cli predict /percorso/pitchapi-archivio.json \
  --league-id eng-premier --home 'ID_CASA' --away 'ID_OSPITE' \
  --as-of '2026-11-05T12:00:00Z' --output ga3_previsione.json
```

**Esempio di interfaccia, non di partita reale.** La data di previsione deve precedere il calcio d'inizio verificato da una fonte schedulazione separata. Di default si usa la specifica di riferimento di GA2 (Poisson, H=365, ridge=10, correzione venue); ciò NON significa che il vecchio modello sia stato validato su PitchAPI.

## 3 — Backtest temporale (solo PitchAPI)

Ogni campionato richiede finestre compatibili con la reale copertura degli archivi. Le sei date **sono obbligatorie**: non presumere che quelle della Serie A siano applicabili ad altri tornei.

```bash
python -m goal_analyzer3.cli backtest /percorso/pitchapi-archivio.json \
  --league-id eng-premier \
  --selection-start 2024-08-01 --selection-end 2025-01-01 \
  --calibration-start 2025-01-01 --calibration-end 2025-06-01 \
  --test-start 2025-08-01 --test-end 2026-06-01 \
  --output ga3_pitchapi_backtest.json
```

Sono date **esemplificative**: occorrono sufficienti risultati PitchAPI anteriori alla prima finestra. La verifica è cronologica ma gli archivi retrospettivi possono essere stati rivisti dopo l'evento. Non chiamarla validazione *point-in-time* certificata senza snapshot storici autentici.

## 4 — FootyStats come controllo esterno, MAI come input del modello

Richiede mapping creato e verificato dall'operatore: gli ID PitchAPI non devono essere dedotti automaticamente dai nomi FootyStats.

Esempio di `team_map.json` (placeholder da compilare con ID autentici):

```json
{
  "pitchapi_league_id": "eng-premier",
  "team_id_to_footystats_name": {
    "ID_1": "Club A",
    "ID_2": "Club B"
  }
}
```

```bash
python -m goal_analyzer3.external_audit \
  --pitchapi /percorso/pitchapi-archivio.json \
  --footystats /percorso/england-premier-matches-2025-to-2026-stats.csv \
  --team-map team_map.json --max-days 1 \
  --output audit_pitchapi_vs_footystats.json
```

Confronta, sulle partite abbinate senza ambiguità, **identità, giorno, risultato finale e xG**; conta le mancanze e le differenze. Una soglia descrittiva xG di 0,50 non è una prova che una fonte sia sbagliata: i modelli xG possono differire per definizione, eventi e arrotondamenti. Una discrepanza nei risultati è un segnale più direttamente verificabile, ma richiede un controllo terzo in caso di conflitto. La sola coincidenza fra due provider non prova l'esattezza ufficiale.

Il confronto **non decide automaticamente** quali record PitchAPI vadano usati per allenare il modello: questa decisione rimane nella validazione della qualità del dataset PitchAPI e richiede eventualmente revisione umana. Nessun output di questo audit viene letto da `goal_analyzer3.cli`.

## Stato scientifico

- La versione RC2 modifica effettivamente architettura, CLI, test e documentazione. I vecchi moduli GA2, GTS, MA2, Bookmaker Analyzer, BetAnalyzer e la branch main del repository originario NON sono stati modificati.
- I test automatici provano le proprietà tecniche, non l'accuratezza calcistica o la redditività.
- **Nessun backtest comparativo nuovo su campionati reali è stato eseguito in questa RC2.** I dati PitchAPI archiviati erano consultabili come struttura, ma non trasferibili in modo verificato all'ambiente di esecuzione locale.
- `PRODUCTION READY = NO`. In particolare: non usare le quote, non attivare la confidence di rendimento, non applicare correzioni GTS arbitrarie.

Consulta `CHECKPOINT.md` e `docs/` per limiti, confronto RC1/RC2 e istruzioni d'integrazione.
