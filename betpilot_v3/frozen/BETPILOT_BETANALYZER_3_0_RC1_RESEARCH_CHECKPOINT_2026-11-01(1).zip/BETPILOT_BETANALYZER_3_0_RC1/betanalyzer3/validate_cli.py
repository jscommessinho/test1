"""Offline chronological replay on real externally supplied records, if provided."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from .validation import assess_snapshots

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True,help='JSON array of immutable prematch handoffs with resolved outcomes')
    ap.add_argument('--output',required=True)
    a=ap.parse_args()
    result=assess_snapshots(json.loads(Path(a.input).read_text('utf8')))
    Path(a.output).write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n','utf8')
    print(json.dumps({'snapshots':result['observation_count'],'results_scored':result['selected_settled_count']}))
if __name__=='__main__':main()
