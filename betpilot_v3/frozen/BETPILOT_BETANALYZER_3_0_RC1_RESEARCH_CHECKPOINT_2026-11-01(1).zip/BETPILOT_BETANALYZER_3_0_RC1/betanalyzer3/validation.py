"""Chronological replay from externally supplied immutable match-level snapshots.
This module does not create odds, history, model fits, calibration or claims of edge.
"""
from __future__ import annotations
import math
from .contracts import dt, ContractError,require
from .decision import analyze, payout


def assess_snapshots(observations):
    """observations: [{handoff:{...}, resolved_at: ISO, settlements:{MARKET_ID:'win'|'loss'|...}}].
    No model fitting, future feature generation or hyperparameter tuning.
    """
    require(isinstance(observations,list),'observations must be a list')
    # Require unique fixture IDs and strict chronological input ordering.
    ids=set();prev=None;prediction_errors=[];outcomes=[];picks=[];abstentions={}
    for obs in observations:
        handoff=obs['handoff'];m=handoff['match'];kickoff=dt(m['kickoff'])
        require(prev is None or kickoff>prev,'kickoffs must be strictly increasing')
        prev=kickoff;key=(m['competition'],m['event_id']);require(key not in ids,'duplicate match');ids.add(key)
        require(dt(obs['resolved_at'])>=kickoff,'result known before kickoff')
        r=analyze(handoff)
        settlements=obs.get('settlements',{})
        require(isinstance(settlements,dict),'settlements object required')
        for market in handoff['markets']:
            mid=market['market_id'];state=settlements.get(mid)
            if state is None or set(market['outcomes'])!={'win','loss'}:continue
            require(state in ('win','loss'),'invalid binary settlement')
            p=market['outcomes']['win'];y=1 if state=='win' else 0
            # Log loss clipped only to avoid log(0); exact degenerate forecast given infinite loss.
            log=-math.log(max(1e-15,p if y else 1-p))
            prediction_errors.append({'market_id':mid,'brier':(p-y)**2,'log_loss':log})
        if r['primary_research_candidate']:
            pick=r['primary_research_candidate'];mid=pick['market_id']
            if mid in settlements:
                quote=pick['quote'];state=settlements[mid]
                require(state in handoff['markets'][[x['market_id'] for x in handoff['markets']].index(mid)]['outcomes'],'invalid settled state')
                # Historical quote provenance already validated by analyze().
                profit=payout(state,quote['decimal_odds'])
                picks.append({'event_id':m['event_id'],'market_id':mid,'profit_units':profit,'quote':quote['decimal_odds']})
            else:abstentions['UNRESOLVED_SELECTION']=abstentions.get('UNRESOLVED_SELECTION',0)+1
        else:abstentions[r['decision']]=abstentions.get(r['decision'],0)+1
    n=len(picks)
    return {'schema':'BETPILOT_BA3_VALIDATION_V1','observation_count':len(observations),
            'probabilistic_scoring_count':len(prediction_errors),
            'brier_mean':sum(x['brier'] for x in prediction_errors)/len(prediction_errors) if prediction_errors else None,
            'log_loss_mean':sum(x['log_loss'] for x in prediction_errors)/len(prediction_errors) if prediction_errors else None,
            'selected_settled_count':n,
            'selected_roi_per_unit':sum(x['profit_units'] for x in picks)/n if n else None,
            'selected_win_rate':sum(x['profit_units']>0 for x in picks)/n if n else None,
            'abstention_reasons':abstentions,
            'selection_details':picks,
            'limitations':['Observational chronological replay, no refit or independent audit of odds feeds',
                           'Intervals and OOS validation labels must be independently substantiated',
                           'Multiple markets per fixture create within-fixture dependence',
                           'No claim of profitability or superiority without adequate independent test set and benchmarks']}
