"""Deterministic autonomous selection with guarded abstention.
All math is for decimal odds and explicit settlement outcomes, no GTS vote.
"""
from __future__ import annotations
from .contracts import validate, number, dt, SETTLEMENT


def payout(state, decimal_odds):
    return (decimal_odds-1)*SETTLEMENT[state] if SETTLEMENT[state]>0 else SETTLEMENT[state]


def ev(outcomes, decimal_odds):
    number(decimal_odds,'odds',1.000000001)
    return sum(p*payout(state,decimal_odds) for state,p in outcomes.items())


def lower_ev(bounds, decimal_odds):
    """Exact minimization on independent marginal probability intervals and sum(p)=1.
    Greedy fill lower-payoff states first is optimal for this linear program.
    Intervals must be joint-feasible; this gives a conservative outer bound.
    """
    alloc={k:v['lower'] for k,v in bounds.items()}
    remainder=1-sum(alloc.values())
    for state in sorted(bounds, key=lambda x:(payout(x,decimal_odds), x)):
        extra=min(remainder,bounds[state]['upper']-alloc[state]);alloc[state]+=extra;remainder-=extra
        if remainder<=1e-10:break
    if remainder>1e-8:raise ValueError('uncertainty interval infeasible')
    return ev(alloc,decimal_odds)


def analyze(payload):
    data=validate(payload)
    m=data['match'];market=data['markets'];ga=data['engines']['goal_analyzer'];ma=data['engines']['market_analyzer']
    engine_audit={k:{'version':v['version'],'source_sha256':v['source_sha256'],
                      'data_cutoff':v['data_cutoff'],'native_output_verified_flag':v['native_output_verified']}
                  for k,v in data['engines'].items()}
    rows=[];eligible=[];stat=[]
    for row in market:
        market_id=row['market_id'];p=row['outcomes'].get('win');q=row.get('quote')
        reasons=[]
        if row['status']!='EVALUATED':reasons.append('MARKET_REJECTED')
        if 'BLOCKING' in row.get('conflicts',[]):reasons.append('UNRESOLVED_BLOCKING_CONFLICT')
        if row.get('ga3_calibration')!='VALIDATED_OUT_OF_SAMPLE':reasons.append('UNCALIBRATED_GA3')
        if not row.get('validation_reference'):reasons.append('VALIDATION_REFERENCE_MISSING')
        if row.get('uncertainty_bounds') is None:reasons.append('UNCERTAINTY_BOUNDS_MISSING')
        if q is None:reasons.append('QUOTE_MISSING')
        else:
            if q.get('provenance')!='VERIFIED_EXTERNAL_SNAPSHOT' or not q.get('capture_reference'):
                reasons.append('QUOTE_NOT_EXTERNALLY_VERIFIED')
            if q.get('valid_at_cutoff') is not True:reasons.append('QUOTE_AVAILABILITY_NOT_VERIFIED')
            if q.get('source')!='Bet365':reasons.append('UNSUPPORTED_BOOKMAKER_SOURCE')
        mean=None;worst=None
        if q:
            mean=ev(row['outcomes'],q['decimal_odds'])
            if row.get('uncertainty_bounds'):worst=lower_ev(row['uncertainty_bounds'],q['decimal_odds'])
            if worst is None or worst<=0:reasons.append('NO_ROBUST_POSITIVE_EDGE')
        result={
            'market_id':market_id,'event_probability':p,
            'estimation_reliability':'OUT_OF_SAMPLE_VALIDATED_WITH_BOUNDS' if not any(x in reasons for x in ('UNCALIBRATED_GA3','VALIDATION_REFERENCE_MISSING','UNCERTAINTY_BOUNDS_MISSING')) else 'NOT_DEMONSTRATED',
            'market_analyzer_rank':row.get('ma3_rank'),
            'gts_diagnostic':row.get('gts_diagnostic'),
            'quote':q, 'estimated_ev':mean,'worst_case_ev':worst,
            'dependence_group':row.get('dependence_group') or 'UNKNOWN_CORRELATION',
            'dependence_reviewed':row.get('dependence_reviewed') is True,
            'conflicts':row.get('conflicts',[]),
            'decision':'ELIGIBLE_RESEARCH_CANDIDATE' if not reasons else 'EXCLUDED',
            'exclusion_reasons':reasons,
        }
        rows.append(result)
        if row['status']=='EVALUATED' and 'BLOCKING' not in row.get('conflicts',[]) and set(row['outcomes'])=={'win','loss'}:
            stat.append(result)
        if not reasons:eligible.append(result)
    # A high probability is a descriptive statistical pick, not a bet.
    stat.sort(key=lambda r:(-r['event_probability'],r['market_id']))
    eligible.sort(key=lambda r:(-r['worst_case_ev'],-r['estimated_ev'],r['market_id']))
    primary=eligible[0] if eligible else None
    alternatives=[];used={primary['dependence_group']} if primary else set()
    for c in eligible[1:]:
        if c['dependence_group'] in used or not (c['dependence_reviewed'] and primary['dependence_reviewed']):continue
        alternatives.append(c);used.add(c['dependence_group'])
        if len(alternatives)==1:break
    # Software can identify research candidates, but cannot self-certify a validated live deployment.
    reasons=set(z for r in rows for z in r['exclusion_reasons'])
    if not primary:
        if not market:decision='NO_BET_NO_SUPPORTED_MARKETS'
        elif 'QUOTE_MISSING' in reasons or 'QUOTE_NOT_EXTERNALLY_VERIFIED' in reasons or 'QUOTE_AVAILABILITY_NOT_VERIFIED' in reasons:
            decision='NO_BET_INSUFFICIENT_MARKET_EVIDENCE'
        elif 'UNCALIBRATED_GA3' in reasons or 'UNCERTAINTY_BOUNDS_MISSING' in reasons:
            decision='NO_BET_UNVALIDATED_PROBABILITIES'
        else:decision='NO_BET_NO_ROBUST_EDGE_OR_CONFLICT'
    else:decision='RESEARCH_CANDIDATE_IDENTIFIED_NOT_PRODUCTION_AUTHORIZED'
    return {'schema':'BETPILOT_BA3_DECISION_V1','research_only':True,'operational_eligible':False,
            'decision':decision,'match':m,'engine_audit':engine_audit,
            'statistical_pick':stat[0] if stat else None,
            'primary_research_candidate':primary,'secondary_research_candidate':alternatives[0] if alternatives else None,
            'markets':rows,'policy':{
                'selection':'First validate all four engines, then select eligible market maximizing conservative lower EV, without arbitrary weighting',
                'probability_source':'GA3 only (GTS remains diagnostic)',
                'no_bet':'No research candidate passes all provenance, calibration, quote, settlement and positive robust EV gates',
                'production':'Independent historical validation and native adapter verification required before operational deployment',
                'correlation':'Select at most one candidate per declared dependence group. Secondary requires explicit reviewed dependence on both markets; unknown correlation gets one common group',
            }}


def markdown_report(r):
    m=r['match']
    lines=[f"# BETPILOT | FULL ANALYSIS: {m['home']} – {m['away']}",'',
           f"- Competizione: {m['competition']}",f"- Inizio: {m['kickoff']}",f"- Cutoff: {m['cutoff']}",
           '- Stato: **RESEARCH_ONLY** (nessuna puntata autorizzata)','',
           '## Motori','']
    for k,v in r['engine_audit'].items():lines.append(f"- {k}: `{v['version']}` · SHA256 `{v['source_sha256']}`")
    lines+=['','## Pronostico statistico','']
    sp=r['statistical_pick']
    lines.append(f"{sp['market_id']}: p={sp['event_probability']:.2%} (solo descrittivo, non implica valore)" if sp else 'Nessun mercato binario con probabilità analizzabile.')
    lines+=['','## Decisione finale','',f"**{r['decision']}**",'']
    for label,key in [('Primary research candidate','primary_research_candidate'),('Secondary research candidate','secondary_research_candidate')]:
        v=r.get(key)
        if v:
            lines.append(f"- {label}: {v['market_id']} · p={v['event_probability']:.2%} · quota {v['quote']['decimal_odds']:.3f} · EV {v['estimated_ev']:+.2%} · EV conservativo {v['worst_case_ev']:+.2%}")
    lines+=['','## Esclusioni e conflitti','']
    for x in r['markets']:
        if x['exclusion_reasons']:lines.append(f"- `{x['market_id']}`: {', '.join(x['exclusion_reasons'])}")
    if not r['markets']:lines.append('- Nessun mercato consegnato.')
    lines+=['','## Limiti','',
        'Selezione tecnica a scopo di ricerca. Le evidenze dichiarate nell’handoff non equivalgono a verifica indipendente dei file nativi.',
        'Nessun dato reale, ROI o validazione predittiva viene inferito da prove sintetiche.',
        'Un candidato con EV stimato positivo non rappresenta una garanzia di rendimento.','']
    return '\n'.join(lines)
