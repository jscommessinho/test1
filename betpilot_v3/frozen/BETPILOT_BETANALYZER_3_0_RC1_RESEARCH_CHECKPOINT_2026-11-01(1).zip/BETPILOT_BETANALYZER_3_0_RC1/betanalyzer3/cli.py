"""Offline CLI: python -m betanalyzer3.cli --input handoff.json --output-dir ./out"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from .contracts import ContractError
from .decision import analyze,markdown_report


def main(argv=None):
    p=argparse.ArgumentParser(description='BETPILOT BetAnalyzer3 offline fail-closed decision engine')
    p.add_argument('--input',required=True)
    p.add_argument('--output-dir',required=True)
    args=p.parse_args(argv)
    output=Path(args.output_dir);output.mkdir(parents=True,exist_ok=True)
    try:
        data=json.loads(Path(args.input).read_text('utf-8'))
        result=analyze(data)
    except (ContractError,ValueError,TypeError,KeyError) as e:
        fail={'schema':'BETPILOT_BA3_ERROR_V1','status':'INTEGRATION_BLOCKED','error_type':type(e).__name__,'error':str(e)}
        (output/'INTEGRATION_ERROR.json').write_text(json.dumps(fail,indent=2)+'\n','utf-8')
        print(json.dumps(fail,ensure_ascii=False));return 2
    files={'BETANALYZER_3_ANALYSIS.json':json.dumps(result,ensure_ascii=False,allow_nan=False,sort_keys=True,indent=2)+'\n',
           'BETANALYZER_3_REPORT.md':markdown_report(result)}
    for name,content in files.items():(output/name).write_text(content,encoding='utf8')
    manifest={'sha256':{name:hashlib.sha256(content.encode('utf8')).hexdigest() for name,content in files.items()},
              'external_engines_modified':False,'native_end_to_end_verified':False,
              'real_world_validation_claimed':False,'production_ready':False}
    (output/'RUN_MANIFEST.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n','utf8')
    print(json.dumps({'status':result['decision'],'files':list(files)},ensure_ascii=False));return 0

if __name__=='__main__':raise SystemExit(main())
