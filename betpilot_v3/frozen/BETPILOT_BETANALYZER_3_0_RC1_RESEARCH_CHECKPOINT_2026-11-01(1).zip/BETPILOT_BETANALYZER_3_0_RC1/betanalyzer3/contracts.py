"""Fail-closed cross-engine file contract. This is BA3's own interchange schema,
NOT a claim that any upstream engine already emits this structure.
"""
from __future__ import annotations
from datetime import datetime, timezone
from math import isfinite

EXPECTED = {
    'goal_analyzer': 'GOAL_ANALYZER_3.0_RC2_PITCHAPI_ONLY',
    'gts': 'GTS_3.0_RC1',
    'bookmaker_analyzer': 'BOOKMAKER_ANALYZER_2.0_RC15_VERDETTO_C',
    'market_analyzer': 'MARKET_ANALYZER_3.0_NATIVE_RC2',
}
SCHEMA = 'BETPILOT_BA3_HANDOFF_V1'
PROVENANCE = {'VERIFIED_EXTERNAL_SNAPSHOT', 'USER_SUPPLIED_NOT_TIMESTAMP_VERIFIED', 'SYNTHETIC'}
SETTLEMENT = {'win': 1, 'loss': -1, 'push': 0, 'half_win': .5, 'half_loss': -.5}

class ContractError(ValueError):
    pass

def require(ok, msg):
    if not ok: raise ContractError(msg)

def dt(value):
    require(isinstance(value,str), 'timestamp must be ISO-8601 string')
    try:
        v=datetime.fromisoformat(value.replace('Z','+00:00'))
        require(v.tzinfo is not None and v.utcoffset() is not None, 'timezone required')
        return v.astimezone(timezone.utc)
    except ValueError as exc:
        raise ContractError(f'invalid timestamp: {value!r}') from exc

def number(n, field, lo=None, hi=None):
    require(isinstance(n,(float,int)) and not isinstance(n,bool) and isfinite(n),f'{field}: finite number required')
    if lo is not None: require(n >= lo, f'{field}: below {lo}')
    if hi is not None: require(n <= hi, f'{field}: above {hi}')
    return float(n)

def validate_match(m):
    require(isinstance(m,dict), 'match required')
    for k in ('event_id','competition','home','away','kickoff','cutoff'):
        require(isinstance(m.get(k),str) and m[k].strip(),f'match.{k} missing')
    require(m['home'].strip().casefold()!=m['away'].strip().casefold(),'same home and away')
    require(dt(m['cutoff'])<dt(m['kickoff']),'analysis cutoff must precede kickoff')
    return m

def _same_match(expected,actual,name):
    require(isinstance(actual,dict),f'{name}.match absent')
    for k in ('event_id','competition','home','away','kickoff','cutoff'):
        require(expected[k]==actual.get(k),f'{name}.match.{k} mismatch')

def validate_engine(m,name,engine):
    require(isinstance(engine,dict), f'{name} absent')
    require(engine.get('version')==EXPECTED[name],f'{name} version mismatch')
    _same_match(m,engine.get('match'),name)
    require(engine.get('source_sha256') and len(engine['source_sha256'])==64 and all(c in '0123456789abcdef' for c in engine['source_sha256']),f'{name} source SHA-256 required')
    require(engine.get('native_output_verified') is True, f'{name}: native output not verified')
    require(dt(engine.get('data_cutoff'))<=dt(m['cutoff']), f'{name}: data leakage')
    if name=='goal_analyzer':
        require(engine.get('stats_provider')=='PitchAPI','GA3 must use PitchAPI only')
    if name=='gts':
        require(engine.get('stats_provider')=='PitchAPI','GTS3 data source must be PitchAPI')
        require(engine.get('probability_adjustment') is False,'GTS must not change probabilities')
    if name=='bookmaker_analyzer':
        audit=engine.get('verdict_c_audit')
        require(isinstance(audit,dict) and audit.get('applied') is True,'Verdict C audit required')
        require(audit.get('reference_alignment_handled') is True,'Verdict C reference masking unverified')
        require(audit.get('coefficients_changed') is False, 'RC15 coefficients changed')
    return engine

def validate_market(row, m, supported):
    require(isinstance(row,dict), 'market object required')
    market_id=row.get('market_id')
    require(isinstance(market_id,str) and market_id and market_id in supported,f'unsupported market: {market_id}')
    require(row.get('settlement_type')=='DECIMAL_FIXED',f'{market_id}: unsupported settlement')
    require(row.get('probability_source')=='goal_analyzer',f'{market_id}: probabilistic provenance must be GA3')
    require(row.get('market_analyzer_evaluated') is True,f'{market_id}: not evaluated in MA3')
    require(row.get('status') in ('EVALUATED','REJECTED'),f'{market_id}: invalid market status')
    require(isinstance(row.get('outcomes'),dict) and row['outcomes'],f'{market_id}: outcomes required')
    require(set(row['outcomes']).issubset(SETTLEMENT) and {'win','loss'}<=set(row['outcomes']),f'{market_id}: invalid settlement states')
    total=0.0
    for state, pr in row['outcomes'].items(): total+=number(pr,f'{market_id} {state}',0,1)
    require(abs(total-1)<1e-8,f'{market_id}: probabilities do not sum to 1')
    bounds=row.get('uncertainty_bounds')
    if bounds is not None:
        require(isinstance(bounds,dict) and set(bounds)==set(row['outcomes']),f'{market_id}: bounds mismatch')
        lo=hi=0.
        for state,b in bounds.items():
            require(isinstance(b,dict),f'{market_id}: bounds object required')
            lower=number(b.get('lower'),'lower',0,1)
            upper=number(b.get('upper'),'upper',0,1)
            require(lower<=row['outcomes'][state]<=upper and lower<=upper,f'{market_id}: incompatible bounds')
            lo+=lower;hi+=upper
        require(lo<=1+1e-9 and hi>=1-1e-9,f'{market_id}: globally impossible interval bounds')
    if row.get('dependence_group') is not None:
        require(isinstance(row['dependence_group'],str) and row['dependence_group'].strip(),'dependence_group must be non-empty string')
    if row.get('dependence_reviewed') is not None:
        require(isinstance(row['dependence_reviewed'],bool),'dependence_reviewed must be bool')
    for item in row.get('conflicts',[]):
        require(item in ('NONE','REVIEW','BLOCKING'),'invalid conflict flag')
    quote=row.get('quote')
    if quote is not None:
        require(isinstance(quote,dict),'quote must be object')
        number(quote.get('decimal_odds'),'decimal_odds',1.000000001)
        require(quote.get('market_id')==market_id,'quote market_id mismatch')
        require(quote.get('source') and quote.get('timestamp'),'quote source/timestamp missing')
        require(quote.get('provenance') in PROVENANCE,'invalid quote provenance')
        require(dt(quote['timestamp'])<=dt(m['cutoff']),f'{market_id}: quote after cutoff')
    return row

def validate(payload):
    require(isinstance(payload,dict) and payload.get('schema')==SCHEMA,'unsupported handoff schema')
    m=validate_match(payload.get('match'))
    engines=payload.get('engines')
    require(isinstance(engines,dict),'engines object required')
    for name in EXPECTED:validate_engine(m,name,engines.get(name))
    supported=payload['engines']['goal_analyzer'].get('supported_markets')
    require(isinstance(supported,list) and supported and len(supported)==len(set(supported)), 'GA3 supported_markets required')
    ma_supported=payload['engines']['market_analyzer'].get('supported_markets')
    require(isinstance(ma_supported,list),'MA3 supported_markets required')
    supported=set(supported)&set(ma_supported)
    require(isinstance(payload.get('markets'),list),'markets array required')
    seen=set()
    for r in payload['markets']:
        validate_market(r,m,supported)
        require(r['market_id'] not in seen, 'duplicate market '+r['market_id'])
        seen.add(r['market_id'])
    return payload
