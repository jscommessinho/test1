import copy
import unittest
from betanalyzer3.contracts import EXPECTED,ContractError
from betanalyzer3.decision import analyze, ev, lower_ev
from betanalyzer3.validation import assess_snapshots

M={'event_id':'SYNTHETIC_1','competition':'Italy Serie A 2026','home':'Demo Home','away':'Demo Away',
   'kickoff':'2026-11-04T20:00:00+00:00','cutoff':'2026-11-04T12:00:00+00:00'}

def fixture(odds=True, bounded=True, calibrated=True, valid=True):
    engines={k:{'version':v,'match':copy.deepcopy(M),'source_sha256':'a'*64,
                'native_output_verified':True,'data_cutoff':M['cutoff']} for k,v in EXPECTED.items()}
    engines['goal_analyzer'].update(stats_provider='PitchAPI',supported_markets=['FT.TOTAL.OVER.1.5','FT.BTTS.YES'])
    engines['gts']['probability_adjustment']=False
    engines['gts']['stats_provider']='PitchAPI'
    engines['market_analyzer']['supported_markets']=['FT.TOTAL.OVER.1.5','FT.BTTS.YES']
    engines['bookmaker_analyzer']['verdict_c_audit']={'applied':True,'reference_alignment_handled':True,'coefficients_changed':False}
    def row(mid,p,q,grp):
        quote={'market_id':mid,'decimal_odds':q,'source':'Bet365',
               'timestamp':'2026-11-04T10:00:00+00:00','provenance':'VERIFIED_EXTERNAL_SNAPSHOT',
               'capture_reference':'SYNTHETIC_REF','valid_at_cutoff':True} if odds else None
        return {'market_id':mid,'status':'EVALUATED','probability_source':'goal_analyzer',
                'market_analyzer_evaluated':True,'settlement_type':'DECIMAL_FIXED',
                'outcomes':{'win':p,'loss':1-p},
                'ga3_calibration':'VALIDATED_OUT_OF_SAMPLE' if calibrated else 'UNVALIDATED',
                'validation_reference':'TEST_ONLY_CANNOT_PROVE_OOS' if calibrated else None,
                'uncertainty_bounds':{'win':{'lower':p-.02,'upper':p+.02},'loss':{'lower':1-p-.02,'upper':1-p+.02}} if bounded else None,
                'quote':quote,'dependence_group':grp,'conflicts':[]}
    return {'schema':'BETPILOT_BA3_HANDOFF_V1','match':copy.deepcopy(M),'engines':engines,
            'markets':[row('FT.TOTAL.OVER.1.5',.7,1.8,'GOALS'),row('FT.BTTS.YES',.62,2.1,'GOALS')]}

class TestDecision(unittest.TestCase):
    def test_ev_binary(self):
        self.assertAlmostEqual(ev({'win':.6,'loss':.4},2),.2)
        self.assertAlmostEqual(ev({'win':.4,'loss':.6},2),-.2)
    def test_payoff_push_half(self):
        self.assertAlmostEqual(ev({'win':.35,'loss':.35,'push':.1,'half_win':.1,'half_loss':.1},2),0.0)
    def test_robust_lp_exact(self):
        b={'win':{'lower':.55,'upper':.7},'loss':{'lower':.3,'upper':.45}}
        self.assertAlmostEqual(lower_ev(b,2.5),.375)
    def test_primary_deterministic(self):
        f=fixture();r=analyze(f)
        self.assertEqual(r['decision'],'RESEARCH_CANDIDATE_IDENTIFIED_NOT_PRODUCTION_AUTHORIZED')
        self.assertEqual(r['primary_research_candidate']['market_id'],'FT.BTTS.YES')
        self.assertIsNone(r['secondary_research_candidate'])
        self.assertEqual(r['statistical_pick']['market_id'],'FT.TOTAL.OVER.1.5')
        self.assertFalse(r['operational_eligible'])
        self.assertEqual(r,analyze(copy.deepcopy(f)))
    def test_no_odds_no_bet(self):
        r=analyze(fixture(odds=False));self.assertEqual(r['decision'],'NO_BET_INSUFFICIENT_MARKET_EVIDENCE')
        self.assertIsNotNone(r['statistical_pick'])
    def test_not_calibrated_abstains(self):
        r=analyze(fixture(calibrated=False));self.assertIsNone(r['primary_research_candidate'])
    def test_no_bounds_abstains(self):
        r=analyze(fixture(bounded=False));self.assertIsNone(r['primary_research_candidate'])
    def test_fake_provenance_abstains(self):
        x=fixture();x['markets'][0]['quote']['provenance']='SYNTHETIC'
        x['markets'][1]['quote']['provenance']='SYNTHETIC'
        self.assertIsNone(analyze(x)['primary_research_candidate'])
    def test_quote_after_cutoff_rejected(self):
        x=fixture();x['markets'][0]['quote']['timestamp']=M['kickoff']
        with self.assertRaises(ContractError):analyze(x)
    def test_prohibited_ga2_version(self):
        x=fixture();x['engines']['goal_analyzer']['version']='GA2'
        with self.assertRaises(ContractError):analyze(x)
    def test_gts_probability_mutation_rejected(self):
        x=fixture();x['engines']['gts']['probability_adjustment']=True
        with self.assertRaises(ContractError):analyze(x)
    def test_footystats_not_allowed_in_ga3(self):
        x=fixture();x['engines']['goal_analyzer']['stats_provider']='FootyStats'
        with self.assertRaises(ContractError):analyze(x)
    def test_bookmaker_without_verdict_c_rejected(self):
        x=fixture();x['engines']['bookmaker_analyzer']['verdict_c_audit']['reference_alignment_handled']=False
        with self.assertRaises(ContractError):analyze(x)
    def test_identity_mismatch(self):
        x=fixture();x['engines']['market_analyzer']['match']['away']='Wrong Club'
        with self.assertRaises(ContractError):analyze(x)
    def test_leakage(self):
        x=fixture();x['engines']['goal_analyzer']['data_cutoff']=M['kickoff']
        with self.assertRaises(ContractError):analyze(x)
    def test_unsupported_market(self):
        x=fixture();x['markets'][0]['market_id']='FT.CORNER.OVER.10.5'
        with self.assertRaises(ContractError):analyze(x)
    def test_conflict_blocks(self):
        x=fixture();x['markets'][0]['conflicts']=['BLOCKING'];x['markets'][1]['conflicts']=['BLOCKING']
        self.assertIsNone(analyze(x)['primary_research_candidate'])
    def test_duplicate_market(self):
        x=fixture();x['markets'].append(x['markets'][0])
        with self.assertRaises(ContractError):analyze(x)
    def test_aggregation_no_leakage(self):
        x=fixture();obs=[{'handoff':x,'resolved_at':'2026-11-05T00:00:00+00:00',
          'settlements':{'FT.TOTAL.OVER.1.5':'win','FT.BTTS.YES':'loss'}}]
        r=assess_snapshots(obs)
        self.assertEqual(r['observation_count'],1)
        self.assertEqual(r['selected_settled_count'],1)
        self.assertAlmostEqual(r['selected_roi_per_unit'],-1.)
    def test_empty_results(self):
        x=fixture();x['markets']=[]
        self.assertEqual(analyze(x)['decision'],'NO_BET_NO_SUPPORTED_MARKETS')

if __name__=='__main__':unittest.main()
