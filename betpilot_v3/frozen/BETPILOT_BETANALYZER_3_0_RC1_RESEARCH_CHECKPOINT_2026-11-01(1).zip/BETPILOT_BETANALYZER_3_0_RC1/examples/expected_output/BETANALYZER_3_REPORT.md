# BETPILOT | FULL ANALYSIS: Demo Home – Demo Away

- Competizione: Italy Serie A 2026
- Inizio: 2026-11-04T20:00:00+00:00
- Cutoff: 2026-11-04T12:00:00+00:00
- Stato: **RESEARCH_ONLY** (nessuna puntata autorizzata)

## Motori

- goal_analyzer: `GOAL_ANALYZER_3.0_RC2_PITCHAPI_ONLY` · SHA256 `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`
- gts: `GTS_3.0_RC1` · SHA256 `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`
- bookmaker_analyzer: `BOOKMAKER_ANALYZER_2.0_RC15_VERDETTO_C` · SHA256 `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`
- market_analyzer: `MARKET_ANALYZER_3.0_NATIVE_RC2` · SHA256 `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`

## Pronostico statistico

FT.TOTAL.OVER.1.5: p=70.00% (solo descrittivo, non implica valore)

## Decisione finale

**NO_BET_INSUFFICIENT_MARKET_EVIDENCE**


## Esclusioni e conflitti

- `FT.TOTAL.OVER.1.5`: UNCALIBRATED_GA3, VALIDATION_REFERENCE_MISSING, QUOTE_NOT_EXTERNALLY_VERIFIED, QUOTE_AVAILABILITY_NOT_VERIFIED
- `FT.BTTS.YES`: UNCALIBRATED_GA3, VALIDATION_REFERENCE_MISSING, QUOTE_NOT_EXTERNALLY_VERIFIED, QUOTE_AVAILABILITY_NOT_VERIFIED

## Limiti

Selezione tecnica a scopo di ricerca. Le evidenze dichiarate nell’handoff non equivalgono a verifica indipendente dei file nativi.
Nessun dato reale, ROI o validazione predittiva viene inferito da prove sintetiche.
Un candidato con EV stimato positivo non rappresenta una garanzia di rendimento.
