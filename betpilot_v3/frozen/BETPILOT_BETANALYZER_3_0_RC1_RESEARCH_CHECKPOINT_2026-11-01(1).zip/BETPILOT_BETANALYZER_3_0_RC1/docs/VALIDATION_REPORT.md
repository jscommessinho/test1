# BA3 RC1 — Validation Report (2026-11-01)

## Available data

**Only synthetic testing data** in `examples/handoff_synthetic.json` and unit-test inputs. There is **no genuine fixture-level set of four upstream native outputs**, independently verified pre-kickoff odds snapshots, outcome data and out-of-sample calibration data supplied to this execution environment.

## Performed

- Automated Python unittest mathematical and functional tests.
- Reproducible offline CLI smoke using explicitly synthetic example.
- Static inspection of GitHub BA2/Verdetto C/MA3 bridge code (not native replay of frozen engines).

## Not performed

- No genuine chronological four-way backtest; no time-varying model refit; no calibration test.
- No empirical validation of actual OOS probability intervals; no true confidence certification.
- No actual GA3/GTS3/MA3 native archived execution; no real Bet365 live call.
- No comparative win rate / ROI / performance gains vs GA-only, MA3 rank or bookmaker baseline.
- No production/real-money operation.

## Future evaluation protocol

Freeze candidate selection criteria before testing; acquire pre-kickoff immutable inputs and authentic quotes with independently verified capture timestamps. Create chronological train, validation and fully held-out test periods with embargo where required, avoiding information leakage. Evaluate probability Brier/log-loss/calibration **per market**, selection coverage and abstention reasons, risk and within-match dependence, conservative EV sensitivity, and settled ROI with intervals and benchmarks. Never tune on final held-out test. Document unavailable markets and data coverage.

**Result:** Local synthetic software QA can pass; statistical and economic validation remains **NOT COMPLETE**.
