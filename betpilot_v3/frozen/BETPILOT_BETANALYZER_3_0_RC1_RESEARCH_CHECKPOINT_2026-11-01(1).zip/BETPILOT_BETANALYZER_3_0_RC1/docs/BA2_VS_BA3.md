# BetAnalyzer 2.0 vs BetAnalyzer 3.0 RC1

| Topic | Prior BA2 Step5 (source inspected) | BA3 RC1 checkpoint (implemented) |
|---|---|---|
| Statistical model | Optional GA2 retrospective research | GA3 RC2 only: strict handoff contract, native adapter pending |
| Goal threat | Not connected | GTS3 diagnostic-only contract; no independence assumption |
| Bookmaker | Native RC15, MA2 legacy; Verdetto C requires wrapper | Exact RC15 + Verdetto C audit required; native adapter pending |
| Market ranking | MA2 descriptive ranking | MA3 Native RC2 required; ranking informational, never automatically primary |
| Selection | BA2 Step5 emits descriptive candidates and `betting_recommendation=None` | New deterministic robust-EV research selection + explicit NO BET gates |
| Confidence | Research-only historical bins | Separates event probability, estimation reliability and decision quality; no numeric confidence invented |
| Conflict/uncertainty | Legacy descriptive status | Explicit blocking conflicts, uncertainty interval minimization |
| Native execution | BA2 RC15→MA2 with optional GA2 | No proven native GA3→GTS3→RC15+VerC→MA3 E2E yet |
| Prospective validity | Not established | Not established; real OOS data pending |
| Production | Research-only | Research-only |

No numerical comparison of predictive performance can be made without a frozen genuine historical dataset and consistent dated odds/settlement records. The historical code is not copied into new operational paths; it remains available independently for audit.
