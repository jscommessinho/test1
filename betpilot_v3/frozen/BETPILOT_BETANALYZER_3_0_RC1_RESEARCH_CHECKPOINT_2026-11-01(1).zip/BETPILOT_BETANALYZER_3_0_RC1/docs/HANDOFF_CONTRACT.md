# BA3 handoff protocol — schema V1

Every handoff must identify **one** precise fixture and four authorized versioned components.

```
{
  "schema": "BETPILOT_BA3_HANDOFF_V1",
  "match": {
    "event_id": "provider:fixture:ID", "competition": "country/league/season",
    "home": "...", "away": "...",
    "kickoff": "ISO8601 with UTC offset", "cutoff": "ISO8601 with UTC offset"
  },
  "engines": {
    "goal_analyzer": {"version":"GOAL_ANALYZER_3.0_RC2_PITCHAPI_ONLY", "stats_provider":"PitchAPI", "supported_markets":["FT.BTTS.YES"], "...":"..."},
    "gts": {"version":"GTS_3.0_RC1", "stats_provider":"PitchAPI", "probability_adjustment":false,"...":"..."},
    "bookmaker_analyzer": {"version":"BOOKMAKER_ANALYZER_2.0_RC15_VERDETTO_C", "verdict_c_audit":{"applied":true,"reference_alignment_handled":true,"coefficients_changed":false},"...":"..."},
    "market_analyzer": {"version":"MARKET_ANALYZER_3.0_NATIVE_RC2", "supported_markets":["FT.BTTS.YES"],"...":"..."}
  },
  "markets": [
    {"market_id":"FT.BTTS.YES", "status":"EVALUATED", "probability_source":"goal_analyzer",
      "market_analyzer_evaluated":true,"settlement_type":"DECIMAL_FIXED",
      "outcomes":{"win":0.6,"loss":0.4},
      "uncertainty_bounds":{"win":{"lower":0.55,"upper":0.65},"loss":{"lower":0.35,"upper":0.45}},
      "ga3_calibration":"VALIDATED_OUT_OF_SAMPLE","validation_reference":"immutable-test-report-ID",
      "quote":{"market_id":"FT.BTTS.YES","decimal_odds":2.0,"source":"Bet365",
        "timestamp":"ISO8601 before cutoff","provenance":"VERIFIED_EXTERNAL_SNAPSHOT",
        "capture_reference":"signed-source-record", "valid_at_cutoff":true},
      "conflicts":[],"dependence_group":"GG_OU_CLUSTER", "dependence_reviewed":true
    }
  ]
}
```

Each engine also **must contain** `match` (identical to top-level match), `data_cutoff` (no later than shared analysis cutoff), `source_sha256` (lowercase SHA256 hex digest), and `native_output_verified` (boolean true, attested by upstream exporter). Again, attestation is **not** proof of independent authentication and BA3 RC1 remains research-only.

## Required semantics

- `market_id` must be supported by both GA3 and MA3. The code does not assume corners/cards/time-period markets exist just because a bookmaker offers them.
- `outcomes` contains a full exclusive and exhaustive distribution over combinations of `win`, `loss`, `push`, `half_win` and `half_loss`; all sum to one.
- `uncertainty_bounds` contains a lower and upper probability per settlement class, each enclosing the point estimate, collectively feasible with sum 1. These must come from a scientifically defensible method; software never invents the intervals.
- EV for a binary market: `p * (decimal_odds-1) - (1-p)`. Push is 0; half-win is half profit; half-loss is -0.5. The conservative EV is the minimum over all feasible marginal probabilities in the rectangular bounds. A positive mean EV **alone** does not pass the filter.
- For cash-out, combination parlays, nonuniform odds or other payoff rules, this schema is **not supported** until the proper settlement mechanics are implemented.
- GTS outputs are diagnostics, not an additional independent probability; MA3 ranking is descriptive, not decisive.
- If quote availability at cutoff is unverified or quote provenance is synthetic, the operational candidate is excluded; missing quotes may still allow a descriptive statistical pick.
- Every unknown or unreviewed dependence must be considered potentially correlated. Only one alternative from a separate, **reviewed** dependence group can be surfaced.
- A `RESEARCH_CANDIDATE` is *never* permission to place a bet. RC1 does not have a production promotion switch.

This handoff contract is newly defined for BA3, **not** the verified native JSON schema of Market Analyzer 3.0 RC2 or of any other upstream engine.
