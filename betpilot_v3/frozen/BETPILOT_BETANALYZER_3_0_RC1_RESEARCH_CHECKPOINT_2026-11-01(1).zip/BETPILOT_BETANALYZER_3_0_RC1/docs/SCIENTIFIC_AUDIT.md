# Independent scientific/software audit — BetAnalyzer 3.0 RC1

## Architecture and selection policy

Inputs first must pass **contract validation**. Every upstream engine has a fixed version identifier, exact event identity, pre-kickoff cutoff and documented provider. A supported market must appear in GA3 and MA3 support lists. GTS is diagnostic only and never changes λ or event probability. Bookmaker market probabilities are not substituted for GA3 probability. No four-vote ensemble.

**Statistical candidate:** choose the most probable binary market among evaluated, non-blocking markets; show probability without implying economic advantage. An uncalibrated statistical candidate is explicitly labeled *estimation reliability not demonstrated*.

**Research pricing candidate:** requires valid native interface claim, documented OOS validation and uncertainty bounds, verified externally captured Bet365 market price at cutoff, correct settlement and no blocking conflicts. For settlement outcome `i` and decimal odds `o`, profit is `o-1` on win, `-1` on loss, `0` on push, `(o-1)/2` on half-win and `-1/2` on half-loss. Calculate mean EV, then **minimize** EV under joint-feasible interval bounds and sum probabilities = 1. Select the candidate with the largest *strictly positive* conservative EV; deterministic second key is mean EV, third market ID. This is a transparent **research criterion, not a validated optimal betting strategy**; choosing maximin-EV itself still needs prospective evaluation. No empirical threshold or confidence weights invented.

**Alternative:** cannot be shown as independently corroborating primary without explicit reviewed dependence groups. Same or unknown group means no alternative. The engine never authorizes real bets in RC1.

## Risks and severity

| Level | Finding | Current mitigation/status |
|---|---|---|
| BLOCKING | Native GA3/GTS3/MA3 archives and native output schemas unavailable in this session | Native four-way integration **not verified**; no production claim |
| BLOCKING | No independent dated real match-level calibration/quote snapshots for full BA3 selection | Out-of-sample predictive/financial validity **not established** |
| IMPORTANT | `native_output_verified` and hash supplied as text can be forged by a producer | Handoff regarded as untrusted attestation. Build source-file checking and signed provenance native adapters before production |
| IMPORTANT | Probability uncertainty bounds may not be simultaneous and may understate real model risk | Treat interval bounds as conditional evidence; require independent method audit |
| IMPORTANT | Cross-market dependence and data reuse can create duplicate information | No GTS vote, conservative dependent-group alternative rule; validate joint dependencies in native adapter |
| IMPORTANT | Optimizing conservative EV can overselect high-variance or selective market cases | Fixed policy, future pre-registered OOS comparison required; no operational stake sizing |
| IMPORTANT | Bookmaker quote timestamp and availability may be incorrectly attested | Require explicit provenance, capture reference and availability flag; external audit still pending |
| MINOR | Historical replay reports descriptive aggregated results, without empirical confidence bands or baselines | Extend after genuine dataset provided; do not infer superiority now |
| MINOR | Statistical pick compares winning probabilities across binary markets with different payoff semantics | Labeled descriptive only; no claim of economic equivalence |

## Test interpretation

`tests/test_ba3.py` contains **synthetic** fixtures and mathematical invariants. The tests exercise version rejection, cutoff leakage checks, strict provider restrictions, mixed-market constraints, deterministic selection, correlation, pricing math, abstention and replay. This does *not* demonstrate performance on real football matches.

## Release verdict

- **RESEARCH COMPLETE:** Preliminary decision architecture and explicit gate rules defined for RC1; policy superiority not independently demonstrated.
- **IMPLEMENTATION COMPLETE:** Core **standalone research checkpoint** implemented and locally tested. This is narrower than full BA3 native system.
- **NATIVE INTEGRATION VERIFIED:** **NO**.
- **STATISTICAL VALIDATION COMPLETE:** **NO**.
- **PRODUCTION READY:** **NO**.

The absence of a production status is a deliberate, verifiable safety and scientific decision; it does not imply the standalone code is nonfunctional.
