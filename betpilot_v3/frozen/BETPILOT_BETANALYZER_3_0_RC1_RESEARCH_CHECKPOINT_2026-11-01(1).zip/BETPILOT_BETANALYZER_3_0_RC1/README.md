# 🧠 BETPILOT | BetAnalyzer 3.0 — RC1 research checkpoint

**Date:** 2026-11-01 · **Scope:** PREMATCH only · **Operational status:** **RESEARCH_ONLY / NOT PRODUCTION READY**.

This repository snapshot is a **working standalone decision engine and explicit integration protocol**, not a claim that four upstream analyzers have been natively executed together. It does not contain or change source code of the frozen upstream engines. It makes **no API calls**, uses **no credentials**, does not bet, and has no scheduled execution.

## What works

- Deterministic calculation of event probability, decimal payoff, mean expected value and exact conservative lower EV over interval probability bounds (linear program on the probability simplex).
- Version-locked, fail-closed `BETPILOT_BA3_HANDOFF_V1` contract for four engines; exact identity, time and cutoff alignment; no GA2/GTS2/MA2 fallback.
- Strict GA3 provenance (`PitchAPI`), GTS3 diagnostic-only, mandatory Bookmaker RC15 **Verdetto C** attestation and MA3 market intersection.
- Separates descriptive statistical pick, candidate research pick and operational betting recommendation (never authorized at RC1).
- Abstains on missing odds, unverifiable capture, uncertain/unvalidated probabilities, unsupported markets, blocking conflicts, missing provenance, non-positive conservative EV.
- Prevents claims of independent alternatives without declared and reviewed dependence; deterministic tie-breaking; machine-readable reasons.
- Chronological observation-only replay scorer (Brier, log loss, settled ROI on observed verified price snapshots). Does **not** train/tune/recalibrate any model.
- Local unit tests with **synthetic assertions** only. Tests prove code behavior, not predictive accuracy.

## Explicitly NOT implemented / not verified

- Native input adapters for the actual GA3 RC2, GTS3 RC1, **MA3 RC2** ZIP JSON schemas; those archives were **not available inside this turn's working environment**. The only inspectable upstream code was GitHub's existing BA2/RC15-VerC and a MA3→RC15 synthetic bridge in PR #2.
- Native four-engine end-to-end from a real fixture, authenticated PitchAPI or Bet365 acquisition, current GA3 model calibration, historical independent backtest, validated probability intervals, independent verification of handoff producer claims.
- Automatic `FULL ANALYSIS: A - B` from team names without a reliable fixture lookup and the four verified upstream outputs.
- Production eligibility or profit claim.

## Installation / execution

Requires Python 3.10+; no third-party runtime dependencies.

```sh
cd BETPILOT_BETANALYZER_3_0_RC1
python -m unittest discover -s tests -v
python -m betanalyzer3.cli --input examples/handoff_synthetic.json --output-dir output/synthetic_demo
# When real immutable dated records become available:
python -m betanalyzer3.validate_cli --input /secure/path/real_snapshots.json --output /secure/path/validation.json
```

Outputs: `BETANALYZER_3_ANALYSIS.json`, `BETANALYZER_3_REPORT.md`, `RUN_MANIFEST.json`, or `INTEGRATION_ERROR.json` on contract failure.

## Native integration strategy

1. Read and hash frozen archives; verify their manifest, release identifiers and native run functions.
2. Add external **source-specific adapters** (`adapters/ga3_native.py`, etc.) *without modifying the four engines*; each adapter must map actual native data to `BETPILOT_BA3_HANDOFF_V1` and verify semantic equivalence and file checksums. Never claim adapter verification from the synthetic example.
3. Supply one shared, unambiguous event identifier, league, teams, kickoff, and a verified, pre-kickoff cutoff on every engine envelope.
4. Export only supported GA3 markets and MA3-reviewed markets; preserve full settlement rules, OOS calibration references, uncertainty bounds, odds capture and provenance.
5. Verify actual serial execution and output parity on synthetic and **genuine dated historical inputs**; run independent chronological validation before promotion.
6. Use source wrappers only: RC15 Verdetto C must be called through `betpilot/bookmaker_verdict_c.py`, not the old Step5 direct `integrate_native.py` pathway.

### Official release identifiers (BA3 interchange protocol)

- `GOAL_ANALYZER_3.0_RC2_PITCHAPI_ONLY` — Goal Analyzer 3.0 RC2.
- `GTS_3.0_RC1` — Goal Threat Score 3.0 RC1.
- `BOOKMAKER_ANALYZER_2.0_RC15_VERDETTO_C` — Bookmaker Analyzer 2.0 with fixes.
- `MARKET_ANALYZER_3.0_NATIVE_RC2` — Market Analyzer 3.0 native RC2.

These are **internal adapter version strings**, not assertions about upstream machine-native `version` fields. Source-specific adapters must translate documented upstream versions to these exact fixed identifiers after verifying the upstream binaries/manifests.

**Important:** The fields `native_output_verified`, `source_sha256`, `ga3_calibration`, `validation_reference` and `valid_at_cutoff` are claims from the handoff producer. A standalone JSON handoff does not itself authenticate them; consequently RC1 outputs are strictly research-only, even if the handoff contains `true` flags. An independent native-validation layer and matching immutable source bytes are required before treating any such claim as established.

Read `docs/INTEGRATION_REPORT.md`, `docs/SCIENTIFIC_AUDIT.md`, and `docs/HANDOFF_CONTRACT.md` before wiring to production.
