import copy
from datetime import date,timedelta
import math
import unittest
import numpy as np
from gts3.source import extract_stats, SourceError, Match
from gts3.features import prepare, midrank, gts2_score, ecdf_reference
from gts3.models import fit, CANDIDATES
from gts3.metrics import outcomes, paired_bootstrap
from gts3.incremental import OffsetCorrection


def stats(xg=1.4,shots=12,duplicate=False,blankyellow=False):
    items=[{'key':'expected_goals','home':str(xg),'away':'1.1'},
           {'key':'total_shots','home':str(shots),'away':'11'},
           {'key':'shots_inside_box','home':'7','away':'6'},
           {'key':'shots_outside_box','home':str(shots-7),'away':'5'},
           {'key':'ShotsOnTarget','home':'4','away':'3'},
           {'key':'ShotsOffTarget','home':'5','away':'5'},
           {'key':'blocked_shots','home':str(shots-9),'away':'3'},
           {'key':'red_cards','home':'0','away':'0'},
           {'key':'BallPossesion','home':'50','away':'50'}]
    if duplicate:items.append({'key':'expected_goals','home':str(xg),'away':'1.1'})
    if blankyellow:items.extend([{'key':'yellow_cards','home':'3','away':'2'},
                                 {'key':'yellow_cards','home':'','away':''}])
    return {'match_id':'m_111111','home_team':{'id':'t_111111'},'away_team':{'id':'t_222222'},
            'periods':[{'period':'All','groups':[{'items':items}]}]}


def fixture(k,day,home,away,xgh=1.5,xga=1.2):
    h={'expected_goals':xgh,'total_shots':14,'expected_goals_non_penalty':xgh,
       'big_chance':2,'touches_opp_box':20,'red_cards':0}
    a={'expected_goals':xga,'total_shots':10,'expected_goals_non_penalty':xga,
       'big_chance':1,'touches_opp_box':15,'red_cards':0}
    return Match('m_'+str(k).zfill(6),day,'2021/2022','TEST',home,away,1,1,h,a)

class TestSource(unittest.TestCase):
    def test_duplicate_xg_deduplicated(self):
        h,a,dup=extract_stats(stats(duplicate=True),'m_111111','t_111111','t_222222')
        self.assertEqual(h['expected_goals'],1.4);self.assertEqual(a['expected_goals'],1.1)
        self.assertGreaterEqual(dup,1)
    def test_conflicting_duplicate_rejected(self):
        x=stats(duplicate=True)
        x['periods'][0]['groups'][0]['items'][-1]['home']='2.6'
        with self.assertRaises(SourceError):extract_stats(x,'m_111111','t_111111','t_222222')
    def test_missing_xg_is_not_zero(self):
        x=stats();x['periods'][0]['groups'][0]['items'][0]['home']=''
        with self.assertRaises(SourceError):extract_stats(x,'m_111111','t_111111','t_222222')
    def test_blank_duplicate_does_not_overwrite_number(self):
        h,a,dup=extract_stats(stats(blankyellow=True),'m_111111','t_111111','t_222222')
        self.assertEqual(h['yellow_cards'],3)
    def test_mismatched_ids_fail(self):
        with self.assertRaises(SourceError):extract_stats(stats(),'m_111111','wrong','t_222222')
    def test_shot_endpoint_unnecessary(self):
        x=stats();x['shots']=[{'expected_goals':9999}]
        h,a,_=extract_stats(x,'m_111111','t_111111','t_222222')
        self.assertEqual(h['expected_goals'],1.4)
    def test_no_missing_optional_as_zero(self):
        h,a,_=extract_stats(stats(),'m_111111','t_111111','t_222222')
        self.assertIsNone(h['touches_opp_box'])
    def test_shot_totals_inconsistent(self):
        x=stats();x['periods'][0]['groups'][0]['items'][1]['home']='20'
        with self.assertRaises(SourceError):extract_stats(x,'m_111111','t_111111','t_222222')

class TestFeatures(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        matches=[];d=date(2021,8,1);k=0
        for i in range(12):
            for j in range(i+1,12):
                matches.append(fixture(k,d+timedelta(days=k*4),f't_{i}',f't_{j}',1.0+i*.06,1.2+j*.02));k+=1
                matches.append(fixture(k,d+timedelta(days=k*4),f't_{j}',f't_{i}',1.5+j*.02,1.1+i*.04));k+=1
        cls.matches=matches
    def test_no_targets_from_future(self):
        orig,_=prepare(self.matches,min_games=3,min_venue=1)
        tail=self.matches[-1]
        mut=copy.deepcopy(self.matches)
        mut[-1]=fixture(999,tail.date,tail.home,tail.away,20.,15.)
        # Target xG/observed result may change, but prior data features must not.
        revised,_=prepare(mut,min_games=3,min_venue=1)
        oi=[r for r in orig if r.date==tail.date.isoformat()]
        ri=[r for r in revised if r.date==tail.date.isoformat()]
        self.assertEqual(len(oi),2);self.assertEqual(len(ri),2)
        for a,b in zip(oi,ri):
            self.assertEqual(a.features,b.features)
            self.assertLess(a.latest_history_date,a.date)
    def test_mutating_future_does_not_change_past_features(self):
        orig,_=prepare(self.matches,min_games=3,min_venue=1)
        altered=copy.deepcopy(self.matches)
        last=altered[-1]
        altered[-1]=fixture(999,last.date,last.home,last.away,12.,10.)
        rev,_=prepare(altered,min_games=3,min_venue=1)
        old={ (r.match_id,r.team_id):r.features for r in orig if r.date<last.date.isoformat()}
        new={ (r.match_id,r.team_id):r.features for r in rev if r.date<last.date.isoformat()}
        self.assertEqual(old,new)
    def test_score_scale(self):
        o,_=prepare(self.matches,min_games=3,min_venue=1)
        ref=ecdf_reference(o)
        self.assertTrue(all(0<=gts2_score(r,ref)<=100 for r in o))
    def test_midrank_duplicates(self):
        self.assertEqual(midrank(1,np.array([1,1,2,3])),.25)
        self.assertEqual(midrank(-2,np.array([1,1,2,3])),0.)
        self.assertEqual(midrank(4,np.array([1,1,2,3])),1.)

class TestModels(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.obs,_=prepare(TestFeatures.matches,min_games=3,min_venue=1)
    def test_all_candidates_fit(self):
        for name in CANDIDATES:
            mod=fit(name,self.obs)
            pred=mod.predict(self.obs)
            self.assertEqual(len(pred),len(self.obs))
            self.assertTrue(np.isfinite(pred).all())
            self.assertTrue((pred>0).all())
            self.assertTrue(((mod.score(self.obs)>=0)&(mod.score(self.obs)<=100)).all())
    def test_target_free_outcome_metrics(self):
        o=self.obs
        m=fit('odh',o)
        grouped=outcomes(o,m.predict(o))
        self.assertEqual(len(grouped)*2,len(o))
        self.assertTrue(all(x['metrics']['nll']>0 for x in grouped))
    def test_bootstrap_identical_zero(self):
        o=self.obs;pred=fit('od',o).predict(o)
        m=outcomes(o,pred)
        v=paired_bootstrap(m,m,repetitions=50)
        self.assertAlmostEqual(v['delta_mean'],0.)
    def test_offset_no_signal_identical(self):
        a=np.array([1.3,1.9,1.7,1.4]*15)
        c=OffsetCorrection().fit([1,2,1,2]*15,a,a)
        self.assertAlmostEqual(c.beta,0.,places=7)

if __name__=='__main__':unittest.main()
