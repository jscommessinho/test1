# BETPILOT | GTS 3.0 — Validation Report RC1

**Generato da un'esecuzione locale offline, 1 novembre 2026.** Stato: `IMPLEMENTATION COMPLETE (research prototype)`; `PREDICTIVE VALIDATION COMPLETE = FALSE`; `PRODUCTION READY = FALSE`.

## 1. Input reali e qualità

Sono state aperte le risposte PitchAPI originali `/stats` presenti negli artifact privati GitHub Actions del 31/10/2026. Per Premier i 1.980 valori xG delle partite provengono **esclusivamente** da `raw/*_stats.json`, ignorando gli xG storici del vecchio archivio derivati dai tiri. Per le altre quattro leghe le risposte sono state lette dagli archivi `BETPILOT_PITCHAPI_TEAM_STATS_v1`. Nessun evento/tiro individuale è stato usato nella costruzione del dataset.

| Lega | Partite eligibili elencate | Payload accettati | Copertura archiviata | Errori strutturali in sample | xG home | Tocchi in area home |
|---|---:|---:|---:|---:|---:|---:|
| Premier League | 1980 | 1980 | 100.00% | 0 | 1980 | 1727 |
| seriea | 1989 | 320 | 16.09% | 0 | 320 | 260 |
| laliga | 1998 | 320 | 16.02% | 0 | 320 | 259 |
| bundes | 1592 | 320 | 20.10% | 0 | 320 | 304 |
| ligue1 | 1750 | 320 | 18.29% | 0 | 320 | 260 |

*Attenzione:* le quattro leghe esterne non hanno dati completi; 320 payload per lega sono controlli di disponibilità, **non** un campione indipendente di test. L'assenza di rifiuti in questi payload non dimostra assenza di errori sulle gare non raccolte. Tutte le metriche di validazione qui sotto sono solo della Premier League.

In totale 3.260 fixture-PitchAPI con xG aggregati di entrambe le squadre presenti e numericamente utilizzabili. I controlli interni hanno verificato valori finiti, identità squadra/fixture, deduplica, consistenza tiri e possesso; duplicazioni di campo sono presenti e sono state deduplicate. Assente comparatore xG esterno ufficiale. Alcune stagioni nella lista provider hanno conteggi da riconciliare; il parser non equipara la sua presenza a accuratezza indipendente.

## 2. Definizione e preparazione GTS

Un'osservazione è una squadra in una gara futura, con il suo avversario e il campo. Il cutoff ammette soltanto gare con `data_gara_precedente + 2 giorni < data_target`, usando uno storico dinamico. Minimi 10 gare per squadra e 4 per sede pertinente. Media xG di lega e prior xG/tiri vengono calcolati **solo** sullo storico disponibile in quel momento, mai dalla gara target.

Si conservano i componenti legacy O/D/H/Q/F e il riferimento GTS2 fonte-omogeneo con ECDF training e pesi `25:25:15:10:10`.

Il candidato selezionato usa **O/D/H** con:

\[Z_k=(x_k-\bar x_{k,train})/s_{k,train};\quad \lambda_{GTS3}=\exp(\beta_0+\beta_O Z_O+\beta_D Z_D+\beta_H Z_H)\]

Poisson GLM con L2 `alpha=0.20`. Lo score 0–100 è il rango ECDF delle intensità predette sul train: un profilo relativo, non una percentuale di gol realizzati né una probabilità. Pesi/coef non hanno significato causale, per collinearità.

## 3. Partizioni e campioni

| Ruolo | Stagioni | Righe squadra-gara | Partite utilizzate |
|---|---|---:|---:|
| Training | 2021/22–2022/23 | 1266 | 633 |
| Validation / selection | 2023/24–2024/25 | 1460 | 730 |
| Retrospective exposed diagnostic | 2025/26 | 740 | 370 |
| Previously observed partial monitor | 2026/27 | 130 | 65 |

Le stagioni 2025/26 e 2026/27 sono **storicamente contaminate dai precedenti riferimenti GTS/PitchAPI**: non possiamo dichiararle test ciechi indipendenti. La cronologia di fitting nel *nuovo* codice resta separata (2025/26 fit su 2021/22–2024/25; 2026/27 fit su 2021/22–2025/26). Gli xG storici scaricati il 31/10/2026 non sono snapshot prospettici.

## 4. Selezione limitata — Metriche appropriate

**Metrica primaria:** NLL congiunta dei gol home+away per partita, Poisson indipendenti. Più basso è meglio. Tre Brier secondari sullo stesso insieme di incontri. Candidati scelti senza usare 2025/26. A parità sostanziale (entro 0.005 NLL di validazione), si preferisce il modello più semplice.

| Variante | NLL validazione | NLL 2025/26 (esposta) | NLL 2026/27 (esposta) | Brier BTTS validazione | Brier O2.5 validazione | Brier 1X2 validazione |
|---|---:|---:|---:|---:|---:|---:|
| simple_xg | 3.07024 | 2.93919 | 3.05602 | 0.23844 | 0.23526 | 0.20220 |
| gts2_ecdf | 3.04601 | 2.94334 | 3.03597 | 0.24061 | 0.23534 | 0.19636 |
| od | 3.05024 | 2.93560 | 3.04192 | 0.23918 | 0.23651 | 0.19633 |
| odh | 3.02868 | 2.91557 | 3.00376 | 0.24050 | 0.23596 | 0.18993 |
| odhqf | 3.03015 | 2.91586 | 3.00461 | 0.24018 | 0.23659 | 0.18972 |
| odh_bigchance | 3.02948 | 2.91561 | 3.00624 | 0.24052 | 0.23616 | 0.18993 |

`odh` vince la selezione. Non è il più affidabile in ogni mercato: il Brier BTTS è migliore per la baseline xG semplice, e le altre linee differiscono. Esempi e percentuali di esiti indovinati non sono usati come criterio primario.

## 5. Component ablation e ridondanze

NLL validazione modello ODH completo **3.02868**. Eliminando O: **3.03012**; eliminando D: **3.03247**; eliminando H: **3.05024**. Il campo H contribuisce sensibilmente nel confronto univariato di rimozione, pur essendo derivato da O/D.

Nel training corr(O,H)=0.677, corr(D,H)=0.515, corr(O,Q)=0.741. Le componenti non sono indipendenti; maggiore complessità non implica più informazione.

## 6. GA2 architettura: confronto non nativo

Il riferimento `ga2_replay.py` replica la configurazione matematica GA2 documentata (Poisson, half-life 365, ridge 10, campo attivo, refit mensile) usando risultati PitchAPI. Non è il motore operativo congelato GA2. Il confronto è perciò metodologicamente utile, **non** una prova di produzione.

| Periodo | ODH NLL | GA2-replay NLL | GA2+ODH offset NLL | Differenza ODH – GA2 con CI95 a blocchi |
|---|---:|---:|---:|---|
| 2023/24–2024/25 | 3.02868 | 3.03604 | 3.01291 | -0.00737 [-0.03474, +0.02146] |
| 2025/26 already exposed | 2.91557 | 2.89883 | 2.89365 | +0.01674 [-0.01194, +0.05215] |
| 2026/27 partially exposed | 3.00376 | 2.97574 | 2.97744 | +0.02802 [+0.00062, +0.14845] |

Il modello autonomo non supera in maniera affidabile GA2: perde in 2025/26 e nel 2026/27 parziale.

Una prova di valore *incrementale*, non operativa, usa la forma:

\[\lambda_{comb}=\lambda_{GA2}\exp(a+b\log(\lambda_{GTS3}/\lambda_{GA2}))\]

L'offset-Poisson è calibrato **solo su precedenti predizioni GTS3 out-of-sample**, con penalizzazione ridge sul coefficiente b. NLL combinata: validazione **3.01291**, periodo 2025/26 **2.89365**, monitor parziale 2026/27 **2.97744**. Il miglioramento rispetto a GA2 non si mantiene stabilmente nei periodi esposti.

Gli intervalli bootstrap usano 1.000 repliche su blocchi calendariali di 30 giorni accoppiati; non compensano automaticamente la selezione di più modelli, la contaminazione storica, il piccolo campione 2026/27 o la dipendenza complessa fra stagioni e squadre.

## 7. Calibrazione e stabilità

Validazione 2023/24: NLL **3.08571** (360 partite). 2024/25: **2.97319** (370 partite). Il modello non è completamente stabile per stagione.

Per la frequenza P(gol squadra >=1), Brier descrittivo **0.16313** e errore di calibrazione medio ponderato su 5 gruppi retrospettivi **0.01861**. Le fasce sono diagnostiche, non sono validazioni operative.

## 8. Stato e decisione

`GTS 3.0 / ODH / Research Candidate RC1` è un motore in Python implementato e testato con 16 test offline. È giustificato come *candidato di ricerca* e indicatore relativo, ma non ancora come sostituto di GA2 né come correttivo numerico operativo. Gli altri quattro campionati vanno completati e valutati **dopo** il congelamento definitivo. Servono snapshot prematch autentici e confronto GA2 nativo sullo stesso sottoinsieme.

**Nessun ROI, EV o risultato economico certificato. Nessun bookmaker o stake usato nel fitting.**
