# BETPILOT — Confronto GTS 2.0 vs GTS 3.0

| Dimensione | GTS-AVAILABLE-ECDF-v1 (adattamento PitchAPI) | GTS3 ODH RC1 |
|---|---|---|
| Fenomeno misurato | Profilo composito relativo di minaccia | Intensità dei gol segnati dalla squadra contro l'avversario, più rango descrittivo 0–100 |
| Componenti | O, D, H, Q, F | O, D, H |
| Pesi | 25:25:15:10:10 / 85, esterni congelati | Coefficienti ridge-Poisson stimati su gol del training |
| Input xG | `/stats` PitchAPI aggregati nel confronto, non somme per-shot | `/stats` PitchAPI aggregati |
| Normalizzazione | ECDF midrank di ciascuna variabile | StandardScaler storico sulle 3 feature per λ; ECDF train su λ per score |
| Output 0–100 | Somma ponderata di ECDF | Rango relativo della λ stimata rispetto al training |
| Output predittivo | Poisson link sperimentale stimato sul score, non operativo | Poisson expected goals λ sperimentale, non operativo |
| Casa/trasferta | Componente H condivisa | Componente H condivisa |
| Piccoli campioni | 5 pseudo-gare per O/D/H; min 10 partite e 4 in venue | Stessa regolarizzazione, stessi minimi |
| Robustezza | Scala a intervalli artificiali, possibile saturazione | Regressione log-lineare semplice, collinearità O/D/H residua |
| Valore aggiunto GA2 | Non dimostrato su nuovo source | Non confermato fuori campione come motore autonomo |
| Stato | Baseline legacy di ricerca | Nuovo candidato di ricerca, mai sostituto GA2 per produzione |

## Confronto quantitativo

Premier League, validazione temporale 2023/24–2024/25, 730 partite:

- GTS2 ECDF adattato agli aggregati + Poisson link: NLL partita **3.04601**.
- GTS3 ODH Poisson: NLL partita **3.02868**.
- Miglioramento assoluto ODH-GTS2: **−0.01734**. CI95 bootstrap temporale **[−0.03403, −0.00131]** (nominale, esplorativo; selezione multipla non corretta).

Nella diagnostica già esposta 2025/26, 370 partite:

- GTS2 ECDF: **2.94334**.
- GTS3 ODH: **2.91557**.

Questa differenza descrive soltanto i dati retrospettivi; 2025/26 era già entrato nel lavoro precedente e non è un test completamente cieco. L'effetto non dimostra un guadagno contro GA2 o sul valore delle quote.

## Risposta alla missione

GTS3 ha ridotto la complessità in modo interpretabile e migliorato alcuni riferimenti statistici, ma **non è stato dimostrato capace di migliorare stabilmente GA2**. Pertanto non è legittimo promuoverlo automaticamente a componente operativa di BetAnalyzer. L'esperimento di correzione GA2+GTS3 resta isolato e disattivato.
