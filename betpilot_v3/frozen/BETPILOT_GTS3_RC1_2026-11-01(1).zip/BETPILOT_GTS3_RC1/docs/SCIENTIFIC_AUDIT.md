# BETPILOT | GTS 3.0 — Revisione scientifica indipendente

## Definizione e misura

Il prodotto ricerca produce una stima della **intensità condizionata di gol segnati da una singola squadra nella partita target**. `λ` ha unità gol/squadra/partita; lo score 0–100 deriva dalla ECDF midrank delle predizioni su un training storico fisso e rappresenta soltanto un *rango relativo*. Non è una probabilità.

## Architettura selezionata (provisional)

- O: medie xG squadra ultime 10 partite, regolarizzate con 5 pseudo-partite al prior di lega disponibile prima del match.
- D: media xGA dell'avversaria ultime 10 gare, stessa regolarizzazione.
- H: media dei profili per sede delle due squadre, ciascuno regolarizzato con 5 pseudo-partite e prior O/D.
- O,D,H sono standardizzati sui soli dati di training.
- `lambda = exp(beta_0 + beta_O*z(O) + beta_D*z(D) + beta_H*z(H))`; PoissonRegressor L2 `alpha=0.20`.
- `GTS3 = 100 * midrank_ECDF_train(lambda)`.

La ECDF modifica l'interpretazione dello **score**, non le feature regredite. Il modello proposto mantiene un alto grado di collinearità: H include O/D nei prior. I coefficienti standardizzati non devono essere interpretati causalmente o come importanze indipendenti.

## Limiti metodologici attuali

**Bloccanti per produzione:** non esistono snapshot prematch autentici per le stagioni storiche; dataset esterni incompleti; impossibile affermare superiorità sul GA2 nativo; 2025/26 già esposto a esperimenti; nessuna validazione prospettica indipendente.

**Importanti:** QA xG solo interna, non terza parte ufficiale; le regressioni e le selezioni sono stati eseguiti principalmente su Premier; window xG recenti influenzati da opponent strength; periodi poco coperti penalizzano neopromosse; condizioni espulsioni non corrette senza dati temporali; Brier mercati non sempre migliorano.

**Minori:** saturazione ECDF, approssimazione Poisson indipendente per calcolare BTTS e 1X2; confronto bootstrap a blocchi limitato per i 65 incontri 2026/27.

**Opzionali:** opponent-adjustment, npxG, big-chance, open play e xGOT soltanto dopo prove di miglioramento incrementale; evita espansione indiscriminata delle feature.

## Decisione scientifica

Il modello **non è predittivamente validato per impieghi operativi**. La struttura a tre componenti è un candidato robusto relativamente semplice e testato offline, ma il fatto che la combinazione GA2+GTS3 abbia piccole differenze favorevoli in alcuni periodi non è una dimostrazione di generalizzabilità. Goal Analyzer, Bookmaker Analyzer, Market Analyzer e BetAnalyzer rimangono invariati.

## Studi ulteriori realmente necessari

1. Acquisire ogni match mancante di Serie A, La Liga, Bundesliga e Ligue1, riconciliando fixture ID/dati e distribuzione per stagione.
2. Archiviare snapshot pre-kickoff reali con hash, timestamp e provider schema version per un campione prospettico indipendente.
3. Congelare ipotesi e soglie statistiche di promozione prima delle nuove osservazioni.
4. Confrontare nativamente con GA2 sulle stesse partite e data cut, includendo l'eventuale offset Poisson.
5. Confermare per campionato, stagione e popolazione, con variazioni degli xG stabili nel tempo.
