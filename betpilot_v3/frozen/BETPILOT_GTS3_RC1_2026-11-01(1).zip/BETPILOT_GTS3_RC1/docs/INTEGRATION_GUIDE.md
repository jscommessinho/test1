# GTS 3.0 — Contratto di integrazione (NON ATTIVO)

## Schema input

```json
{
  "fixture_id": "m_XXXXXX",
  "date": "YYYY-MM-DD",
  "league_id": "l_XXXXXX",
  "season": "2026/2027",
  "home_team_id": "t_XXXXXX",
  "away_team_id": "t_YYYYYY",
  "history_provider": "PitchAPI",
  "history_source": "match-team aggregated /stats All",
  "model_version": "gts3-odh-research",
  "history_asof_timestamp": "[verifiable capture time required for live use]"
}
```

## Schema output

```json
{
  "status": "RESEARCH_ONLY_NO_BETTING",
  "gts3_score_home_0_100": null,
  "gts3_score_away_0_100": null,
  "research_lambda_home": null,
  "research_lambda_away": null,
  "data_coverage": {},
  "latest_history_date": null,
  "prematch_source_snapshot_verified": false,
  "lambda_adjustment_allowed": false,
  "upstream_GA2_modified": false
}
```

*Le chiavi `null` nello schema sono segnaposto del contratto, non output di una partita reale.* Il CLI `gts3.score` restituisce il proprio schema operativo in `predictions[]`, descritto dal codice Python.

## Regole fail closed

- Se `stats.expected_goals` o `stats.total_shots` non esistono, rinunciare; non usare somma xG dai tiri e non convertire missing in zero.
- Verificare identità incontro, home/away, stagione, campionato, period `All`, duplicati e integrità dei valori.
- Storico prima di kickoff con lag prudenziale, e almeno 10 match complessivi e 4 nella sede per **entrambe** le squadre.
- `GTS NOT AVAILABLE` per dati insufficienti o output non finiti.
- Non considerare lo score 0–100 una probabilità; non usarlo per selezione quote, stake, bankroll o λ GA2.
- Per consentire una futura interfaccia GA2, richiedere un'autorizzazione scientifica distinta con confronto su snapshot genuinamente prematch.

## Versioning

Salvare versioni di parser, fonte, stagione, ID provider, pesi, scaler, GLM e `score_reference`. Distinguere baseline GTS2 ECDF da candidato GTS3 ODH. Qualsiasi modifica del parser o degli xG deve avviare una nuova variante, non sovrascrivere parametri congelati.
