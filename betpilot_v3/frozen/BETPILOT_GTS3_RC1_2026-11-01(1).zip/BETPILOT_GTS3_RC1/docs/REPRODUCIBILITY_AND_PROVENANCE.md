# Dati, provenienza e riproducibilità

## Repository originale verificato in sola lettura

`jscommessinho/betpilot-prematch-analyzer`, branch `main`, commit di riferimento `512f0ccc49fbc5c9a3ab65573107c19d8d7a6209` del 31/10/2026.

File letti: `betpilot/pitchapi_gts_reference.py`, `betpilot/pitchapi_history_archive.py`, `betpilot/pitchapi_gts_probe.py`, `betpilot/gts_pitchapi_quality.py`, `vendor/BETPILOT_STEP5/original_sources/ga2/research.py`, `.../locked_model.json`, documenti GTS PitchAPI, workflow di acquisizione delle statistiche.

## Artifact originali analizzati

- Premier League completo, run GitHub Actions [41215948782](https://github.com/jscommessinho/betpilot-prematch-analyzer/actions/runs/41215948782), artifact ID `13048330723`.
- Quattro altre leghe, run GitHub Actions [41216521575](https://github.com/jscommessinho/betpilot-prematch-analyzer/actions/runs/41216521575), artifact IDs: Serie A `13048766644`, La Liga `13047973462`, Bundesliga `13048172277`, Ligue 1 `13048367156`.

Conservare copie personali legittime: gli artifact GitHub Actions possono scadere e non costituiscono storage permanente. I file ZIP originali **non** sono inclusi nel presente rilascio. `reports/INPUT_ARTIFACT_SHA256.json` contiene digest SHA-256 per verifica integrità quando gli archivi sono ancora disponibili.

## Differenza essenziale con la pipeline legacy

Le vecchie registrazioni `eng-premier_archive.json` contengono xG derivati dai tiri; sono state utilizzate SOLO per ID partite, data, stagione, squadre e risultati. Tutti i valori xG del nuovo esperimento Premier vengono da `raw/m_..._stats.json`, chiave `expected_goals` del blocco `All`. Nessun xG delle singole conclusioni o coordinate entra nelle feature GTS3. Per le leghe aggiuntive vengono letti i `statistics` originali degli archivi team-stats.

## Limite point in time

La ricostruzione storica applica un lag di due giorni al *dato della partita*, ma non possiede timestamp originali di pubblicazione o immutabilità storica del provider. Le date di acquisizione moderne non dimostrano quale fosse il valore disponibile prima di un calcio d'inizio passato. Registrare in futuro snapshot pre-match autentici con timestamp e digest.

## Replay matematico GA2

`src/gts3/ga2_replay.py` ricostruisce la struttura del Poisson ridge temporale da `research.py` e la usa su partite PitchAPI. Non usa lo stesso pacchetto di origine per produrre l'output e **non certifica** parità byte-for-byte o equivalenza delle previsioni prodotte dal motore frozen in un ambiente produttivo. La variazione di provider/dataset comporta anche differenze di dominio e riproducibilità.
