# BETPILOT | GTS 3.0 — Research Candidate RC1

**Stato:** `IMPLEMENTATION_COMPLETE / RESEARCH_ONLY` (prototype offline, non produzione).

Questo pacchetto realizza il Goal Threat Score come **intensità offensiva condizionata dall'avversario** e relativo score 0–100. Non modifica GA2, RC15, MA2 o BetAnalyzer. Non invia richieste ad API, non contiene credenziali o dati storici riservati; legge gli artifact ZIP originali, se forniti localmente.

## Verdetto

Il candidato principale è `odh`: tre componenti Offensive xG (O), Defensive xGA avversaria (D), Home/Away (H), con un Poisson GLM regolarizzato. Ha superato varianti più complesse nella validazione retrospettiva 2023/24–2024/25 (NLL partita 3.02868 contro 3.04601 del vecchio GTS ECDF adattato). **Non è dimostrata superiorità rispetto a GA2**: nel test retrospettivo 2025/26 il GA2-architecture replay ha NLL inferiore (2.89883 vs 2.91557). Pertanto GTS3 è un modulo **sperimentale**, non un correttivo autorizzato di λ.

## Input dati ammessi

SOLO statistiche di squadra, dalle risposte PitchAPI `/v1/matches/{id}/stats`, sezione `All`:
- `expected_goals`, `total_shots` obbligatori per la feature baseline.
- `expected_goals_non_penalty`, `big_chance`, `touches_opp_box`, etc. raccolti con `None` per le assenze.
- **Mai** gli xG dei singoli tiri, coordinate o attributi evento-per-evento.

File ZIP privati disponibili come input esterni, **NON inclusi** nel rilascio:
- `audit_premier.zip` (originale Premier, usiamo SOLO `raw/*_stats.json`; non gli xG legacy nell'archive).
- `audit_seriea.zip`, `audit_laliga.zip`, `audit_bundes.zip`, `audit_ligue1.zip` (team stats originali).

Gli snapshot di questi ZIP sono stati scaricati **dopo** le partite: non sono prove della reale disponibilità point-in-time dei dati.

## Installazione

```bash
python -m pip install -e .
# In an offline environment that already has the dependencies and setuptools installed:
# python -m pip install --no-deps --no-build-isolation -e .
python -m unittest discover -s tests -v
```

## Eseguire la ricerca (senza chiamate API)

```bash
OPENBLAS_NUM_THREADS=1 python -m gts3.evaluate \
  --premier /PERCORSO/audit_premier.zip \
  --seriea /PERCORSO/audit_seriea.zip \
  --laliga /PERCORSO/audit_laliga.zip \
  --bundes /PERCORSO/audit_bundes.zip \
  --ligue1 /PERCORSO/audit_ligue1.zip \
  --output reports/
```

Output: `reports/validation_report.json` (copertura, metriche, confronto, ablation, CI), `reports/selected_model_parameters.json` (frozen candidates e scale di riferimento). L'opzione `--no-ga2-replay` salta la riproduzione dell'architettura GA2.

## Calcolare un esempio prematch isolato

**Solo dimostrazione di funzionamento, non pronostico o scommessa:**

```bash
python -m gts3.score \
  --archive /PERCORSO/audit_premier.zip \
  --model reports/selected_model_parameters.json \
  --period 2026_27_HISTORICALLY_OBSERVED \
  --date 2026-11-15 --season 2026/2027 \
  --home-id t_0BrMnM --away-id t_3eV7Ev
```

Questi ID sono utilizzati a fini di esempio; la gara del 15/11/2026 è **ipotetica, non verificata in calendario**. Il codice usa solo partite precedenti e prova a soddisfare i requisiti di storico, senza leggere il risultato di una gara target futura. Restituisce O/D/H/Q/F, score, intensità research e copertura. Non modifica λ di Goal Analyzer.

## Architettura

- `gts3.source`: import ZIP e QA con controllo di identità, deduplica campi, confronto aritmetico; il valore mancante rimane `None`.
- `gts3.features`: finestre ultime 5/10 gare, prior e H campo con cutoff storico +2 giorni.
- `gts3.models`: sei architetture predefinite, fitting ridge-Poisson, ECDF vecchia e scale GTS3.
- `gts3.metrics` / `calibration`: NLL, Brier, bootstrap a blocchi, affidabilità descrittiva.
- `gts3.ga2_replay`: riproduzione MATEMATICA separata del modello GA2, non motore produttivo.
- `gts3.incremental`: prova opzionale non operativa GA2+GTS3 con Poisson offset.
- `gts3.evaluate`: validazione temporale e report.
- `gts3.score`: singola partita isolata.

## Vincoli scientifici non risolti

1. Le stagioni 2025/26 e parte del 2026/27 erano già state osservate nella ricerca precedente; **non sono test ciechi indipendenti**.
2. La data di acquisizione 2026 non certifica il valore prepartita storico.
3. Copertura per le quattro leghe esterne ancora largamente parziale: **nessun test di trasferibilità**.
4. Nessun confronto xG indipendente con un provider esterno comparabile.
5. L'architettura GA2 riprodotta non costituisce un replay certificato del codice nativo congelato su una medesima pipeline dati.
6. Non esiste certificazione di ritorni economici, EV positivo o affidabilità operativa quote.

**NON** attivare il GTS nell'orchestratore prematch fino al superamento di un test futuro realmente pre-registrato su snapshot pre-kickoff e all'audit di compatibilità GA2.

Leggi i rapporti in `docs/` e i valori numerici in `reports/`.
