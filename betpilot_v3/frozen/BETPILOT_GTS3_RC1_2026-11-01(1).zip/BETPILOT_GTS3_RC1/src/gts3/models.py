"""Predeclared limited candidate set; independent from frozen BETPILOT engines."""
from __future__ import annotations
from dataclasses import dataclass
from math import exp
import numpy as np
from sklearn.linear_model import PoissonRegressor
from sklearn.preprocessing import StandardScaler
from .features import RAW_COMPONENTS,ecdf_reference,gts2_score,midrank

# The candidate catalogue is set BEFORE validation or holdout evaluation.
ALPHA=0.20
CANDIDATES={
    'simple_xg':('proxy',()),
    'gts2_ecdf':('gts2',()),
    'od':('glm',('O','D')),
    'odh':('glm',('O','D','H')),
    'odhqf':('glm',('O','D','H','Q','F')),
    'odh_bigchance':('glm',('O','D','H','BC')),
}

@dataclass
class Fitted:
    name:str
    kind:str
    fields:tuple
    scaler:object
    estimator:object
    ref:object
    scale:float
    score_reference:object

    def matrix(self, observations):
        if self.kind=='gts2':
            return np.array([[gts2_score(r,self.ref)/100-.5] for r in observations])
        if self.kind=='glm':
            return np.array([[r.features[f] for f in self.fields] for r in observations],dtype=float)
        raise ValueError('Proxy has no coefficient features')

    def predict(self, observations):
        if self.kind=='proxy':
            return np.array([(r.features['O']+r.features['D'])/2*self.scale for r in observations])
        raw=self.matrix(observations)
        if not np.isfinite(raw).all():raise ValueError('Missing candidate feature: abstain, never zero-impute')
        return np.clip(self.estimator.predict(self.scaler.transform(raw)),.02,8.)

    def score(self, observations):
        y=self.predict(observations)
        return np.array([100*midrank(x,self.score_reference) for x in y])


def fit(name, train):
    if not train:raise ValueError('Training set empty')
    kind,fields=CANDIDATES[name]
    y=np.array([r.goals for r in train],float)
    if kind=='proxy':
        x=np.array([(r.features['O']+r.features['D'])/2 for r in train])
        sc=(y.sum()+0.5)/(x.sum()+0.5)
        obj=Fitted(name,kind,fields,None,None,None,sc,None)
    else:
        ref=ecdf_reference(train) if kind=='gts2' else None
        if kind=='gts2':X=np.array([[gts2_score(r,ref)/100-.5] for r in train])
        else:X=np.array([[r.features[f] for f in fields] for r in train],float)
        if not np.isfinite(X).all():raise ValueError(name+': missing values in training')
        scaler=StandardScaler()
        Z=scaler.fit_transform(X)
        mod=PoissonRegressor(alpha=ALPHA,max_iter=250,tol=1e-8)
        mod.fit(Z,y)
        obj=Fitted(name,kind,fields,scaler,mod,ref,1.,None)
    obj.score_reference=np.sort(obj.predict(train))
    return obj


def export(f):
    return {'name':f.name,'kind':f.kind,'features':list(f.fields),
            'alpha':ALPHA if f.kind!='proxy' else None,
            'scale':f.scale,
            'glm_intercept':float(f.estimator.intercept_) if f.estimator is not None else None,
            'glm_coefs':list(map(float,f.estimator.coef_)) if f.estimator is not None else None,
            'scaler_mean':list(map(float,f.scaler.mean_)) if f.scaler is not None else None,
            'scaler_std':list(map(float,f.scaler.scale_)) if f.scaler is not None else None,
            'gts2_reference':{k:list(map(float,v)) for k,v in f.ref.items()} if f.ref is not None else None,
            'score_reference':list(map(float,f.score_reference)),
            'training_rows':len(f.score_reference),
            'semantic_note':'GTS3 score is train-referenced rank of conditional team goals intensity; NOT a probability',
            'not_operational':'Research only; no GA2 injection or betting use permitted'}
