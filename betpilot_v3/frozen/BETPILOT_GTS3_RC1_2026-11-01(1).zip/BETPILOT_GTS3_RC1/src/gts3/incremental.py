"""One predeclared offset-Poisson GA2+GTS3 residual correction, fit on earlier OOF seasons ONLY.
No changes to GA2 model or its native code. Research experiment, NOT production integration.
"""
import math
import numpy as np
from scipy.optimize import minimize

class OffsetCorrection:
    def __init__(self,ridge=20.):self.ridge=ridge
    def fit(self,goals,ga2,gts):
        y=np.asarray(goals,float);a=np.asarray(ga2,float);g=np.asarray(gts,float)
        if min(a)<=0 or min(g)<=0:raise ValueError('Positive intensities required')
        x=np.log(g/a)
        def objective(b):
            z=np.clip(np.log(a)+b[0]+b[1]*x,-12,10);mu=np.exp(z)
            loss=float(np.sum(mu-y*z)+.5*self.ridge*b[1]**2)
            grad=np.array([np.sum(mu-y),np.sum((mu-y)*x)+self.ridge*b[1]])
            return loss,grad
        sol=minimize(objective,[0.,0.],jac=True,method='L-BFGS-B',options={'maxiter':500,'ftol':1e-12})
        if not sol.success and np.linalg.norm(sol.jac)>1e-3:raise RuntimeError(str(sol.message))
        self.intercept,self.beta=map(float,sol.x)
        self.fit_sample=len(y)
        return self
    def predict(self,ga2,gts):
        a=np.asarray(ga2,float);g=np.asarray(gts,float)
        return np.clip(a*np.exp(self.intercept+self.beta*np.log(g/a)),.02,8.)
    def as_dict(self):return {'intercept':self.intercept,'beta':self.beta,'ridge_beta':self.ridge,'n_team_matches':self.fit_sample,
                                'formula':'lambda_combined=GA2_lambda * exp(intercept + beta*log(GTS3_lambda/GA2_lambda))'}
