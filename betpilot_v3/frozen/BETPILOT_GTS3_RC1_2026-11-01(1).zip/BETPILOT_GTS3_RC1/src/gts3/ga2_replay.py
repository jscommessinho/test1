"""Research REPLAY of the documented frozen GA2 mathematical CONFIGURATION, not a call to the locked live GA2 engine.
Uses the original Poisson time-decay/ridge/venue design as documented in vendor/.../original_sources/ga2/research.py.
It is an architecture-control baseline on PitchAPI fixtures, not a verified identical GA2 production output.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date,timedelta
import math
import numpy as np
from scipy.optimize import minimize

@dataclass(frozen=True)
class Params:
    half_life:int=365
    ridge:float=10.
    venue:bool=True

class GA2Replay:
    def __init__(self,config=Params()):self.cfg=config
    def _design(self,h,a):
        n=len(self.teams);X=np.zeros((2,2+n*(4 if self.cfg.venue else 2)))
        X[:,0]=1;X[0,1]=1
        for side,(team,opp) in enumerate(((h,a),(a,h))):
            if team in self.idx:
                i=self.idx[team];X[side,2+i]=1
                if self.cfg.venue:X[side,2+2*n+i]=1 if side==0 else -1
            if opp in self.idx:
                i=self.idx[opp];X[side,2+n+i]=1
                if self.cfg.venue:X[side,2+3*n+i]=1 if side==1 else -1
        return X
    def fit(self,rows,cut):
        train=[m for m in rows if m.date+timedelta(days=2)<cut]
        if len(train)<500:raise ValueError('GA2 replay requires >=500 dated matches')
        self.teams=sorted({team for m in train for team in (m.home,m.away)})
        self.idx={t:i for i,t in enumerate(self.teams)}
        X=np.vstack([self._design(m.home,m.away) for m in train]);y=np.array([g for m in train for g in (m.hg,m.ag)],float)
        w=np.repeat([2**(-(cut-m.date).days/self.cfg.half_life) for m in train],2)
        pen=np.full(X.shape[1],self.cfg.ridge);pen[:2]=0
        if self.cfg.venue:pen[2+2*len(self.teams):]*=4
        def obj(beta):
            z=np.clip(X@beta,-12,10);mu=np.exp(z)
            loss=float(np.dot(w,mu-y*z)+.5*np.dot(pen,beta*beta))
            grad=X.T@(w*(mu-y))+pen*beta
            return loss,grad
        beta=np.zeros(X.shape[1]);beta[0]=math.log(max(np.average(y,weights=w),.01))
        sol=minimize(obj,beta,jac=True,method='L-BFGS-B',options={'maxiter':1500,'ftol':1e-10,'gtol':1e-6})
        if not sol.success and not np.linalg.norm(sol.jac)<1e-3:raise RuntimeError('GA2 replay optimizer: '+str(sol.message))
        self.beta=sol.x
        return self
    def predict(self,h,a):return np.exp(np.clip(self._design(h,a)@self.beta,-12,10))

def predict_monthly(all_matches,team_observations):
    bymatch={}
    for obs in team_observations:
        bymatch.setdefault(obs.match_id,[]).append(obs)
    eligible={k:r for k,r in bymatch.items() if len(r)==2}
    months=sorted({r[0].date[:7] for r in eligible.values()})
    predictions={};train_counts={};cache={}
    for month in months:
        y,m=map(int,month.split('-'));cut=date(y,m,1)
        try:
            model=GA2Replay().fit(all_matches,cut)
        except ValueError:continue
        count=sum(x.date+timedelta(days=2)<cut for x in all_matches)
        train_counts[month]=count
        for mid,rows in eligible.items():
            if rows[0].date[:7]!=month:continue
            home=next(r for r in rows if r.venue=='home')
            away=next(r for r in rows if r.venue=='away')
            pred=model.predict(home.team_id,away.team_id)
            predictions[(mid,home.team_id)]=float(pred[0]);predictions[(mid,away.team_id)]=float(pred[1])
    return predictions,train_counts
