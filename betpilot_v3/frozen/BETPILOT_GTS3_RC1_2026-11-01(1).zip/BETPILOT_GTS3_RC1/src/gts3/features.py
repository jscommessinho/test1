"""Leakage-controlled, league-local team-match features from PitchAPI team aggregate xG."""
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from datetime import timedelta
import math
import numpy as np

WEIGHTS=np.array([25.,25.,15.,10.,10.])/85.
RAW_COMPONENTS=('O','D','H','Q','F')

@dataclass(frozen=True)
class Observation:
    match_id: str
    date: str
    season: str
    league: str
    team_id: str
    opponent_id: str
    venue: str
    goals: int
    observed_xg: float
    features: dict
    latest_history_date: str


def shrink(values,prior,pseudo=5):
    return (sum(values)+pseudo*prior)/(len(values)+pseudo)


def prepare(matches,min_games=10,min_venue=4,lag_days=2):
    """Both sides admitted or neither. History includes every eligible fixture, regardless of whether a feature was scored for it.

    Each feature only uses matches with finished_date + lag_days < target date.
    No target match result/target xG enters its own features.
    """
    matches=sorted(matches,key=lambda m:(m.date,m.id))
    byteam=defaultdict(list);leaguehist=[]
    out=[];cur=0;skipped=defaultdict(int);latest_league_date=None
    for m in matches:
        # add older source observations only. Missing source data were removed upstream, not converted to zero.
        while cur<len(matches) and matches[cur].date+timedelta(days=lag_days)<m.date:
            prev=matches[cur]
            latest_league_date=prev.date
            for team,opp,venue,xg,xga,shots,stats in [
                (prev.home,prev.away,'home',prev.h['expected_goals'],prev.a['expected_goals'],prev.h['total_shots'],prev.h),
                (prev.away,prev.home,'away',prev.a['expected_goals'],prev.h['expected_goals'],prev.a['total_shots'],prev.a)]:
                byteam[team].append({'date':prev.date,'match_id':prev.id,'opp':opp,'venue':venue,
                    'xg':xg,'xga':xga,'shots':shots,'npxg':stats['expected_goals_non_penalty'],
                    'big_chance':stats['big_chance'],'touches':stats['touches_opp_box'],
                    'red':stats['red_cards'],'goals':prev.hg if venue=='home' else prev.ag})
                leaguehist.append((xg,shots))
            cur+=1
        if not leaguehist:
            skipped['no_league_history']+=1;continue
        mu=sum(x for x,s in leaguehist)/len(leaguehist)
        totalshots=sum(s for x,s in leaguehist)
        if totalshots<=0:
            skipped['no_league_shots']+=1;continue
        q0=sum(x for x,s in leaguehist)/totalshots
        both=[]
        for side,team,opponent,venue,target_xg,goals in [
            ('home',m.home,m.away,'home',m.h['expected_goals'],m.hg),
            ('away',m.away,m.home,'away',m.a['expected_goals'],m.ag)]:
            own=byteam[team];opp=byteam[opponent]
            ownv=[x for x in own if x['venue']==venue]
            oppv=[x for x in opp if x['venue']!=venue]
            if min(len(own),len(opp))<min_games or min(len(ownv),len(oppv))<min_venue:
                skipped['team_or_venue_warmup']+=1
                both=[];break
            ow=own[-10:];op=opp[-10:]
            O=shrink([v['xg'] for v in ow],mu)
            D=shrink([v['xga'] for v in op],mu)
            H=(shrink([v['xg'] for v in ownv[-10:]],O)+shrink([v['xga'] for v in oppv[-10:]],D))/2
            Q=(sum(v['xg'] for v in ow)+20*q0)/(sum(v['shots'] for v in ow)+20)
            F=shrink([v['xg'] for v in own[-5:]],mu)-O
            npo=[v['npxg'] for v in ow]
            BC=shrink([v['big_chance'] for v in ow],1.0) if all(v['big_chance'] is not None for v in ow) else None
            T=shrink([v['touches'] for v in ow],15.0) if all(v['touches'] is not None for v in ow) else None
            NPO=shrink(npo,mu) if all(v is not None for v in npo) else None
            features={'O':O,'D':D,'H':H,'Q':Q,'F':F,'mu':mu,'q0':q0,
                'BC':BC,'T':T,'NPO':NPO,'n_team':len(own),
                'n_opp':len(opp),'n_team_venue':len(ownv),'n_opp_venue':len(oppv),
                'red_own_l10':sum(v['red'] or 0 for v in ow) if all(v['red'] is not None for v in ow) else None}
            if any(not math.isfinite(features[k]) for k in RAW_COMPONENTS):
                raise ValueError('Nonfinite GTS component '+m.id)
            both.append(Observation(m.id,m.date.isoformat(),m.season,m.league,team,opponent,venue,
                goals,target_xg,features,latest_league_date.isoformat()))
        if len(both)==2:out+=both
    return out,dict(skipped)


def ecdf_reference(observations,fields=RAW_COMPONENTS):
    if not observations:raise ValueError('Empty reference')
    return {key:np.sort([r.features[key] for r in observations]) for key in fields}


def midrank(x,ref):
    ref=np.asarray(ref)
    return float((np.searchsorted(ref,x,side='left')+np.searchsorted(ref,x,side='right'))/(2*len(ref)))


def gts2_score(obs,ref):
    return 100.*float(np.dot(WEIGHTS,[midrank(obs.features[k],ref[k]) for k in RAW_COMPONENTS]))
