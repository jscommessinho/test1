"""BETPILOT GTS3 isolated research implementation; never auto-adjusts GA2."""
__version__ = '3.0.0-research'
