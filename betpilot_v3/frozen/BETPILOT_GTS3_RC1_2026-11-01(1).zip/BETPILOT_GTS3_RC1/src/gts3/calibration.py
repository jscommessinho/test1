"""Descriptive reliability tables for P(team scores >=1), not automatic betting calibration."""
import math
import numpy as np

def team_reliability(obs,lam,n_bins=5):
    if len(obs)!=len(lam):raise ValueError('Length mismatch')
    p=np.array([1-math.exp(-max(float(x),.0001)) for x in lam])
    y=np.array([int(r.goals>=1) for r in obs])
    edges=np.quantile(p,np.linspace(0,1,n_bins+1))
    bins=[];weighted=0
    for i in range(n_bins):
        select=(p>=edges[i]) & (p<=edges[i+1] if i==n_bins-1 else p<edges[i+1])
        n=int(select.sum());gap=abs(float(p[select].mean()-y[select].mean())) if n else None
        if n:weighted+=n/len(p)*gap
        bins.append({'bin':i+1,'n':n,'mean_pred_score1plus':float(p[select].mean()) if n else None,
                     'observed_frequency_score1plus':float(y[select].mean()) if n else None,
                     'abs_gap':gap})
    return {'n_team_rows':len(obs),'brier_score1plus':float(np.mean((p-y)**2)),
            'ece_equal_frequency_descriptive':float(weighted),'bins':bins,
            'note':'Bins are descriptive eval-score quantiles, not evidence of calibrated operational probabilities'}
