"""Temporal frozen-design experiments; never tune using 2025/26 or 2026/27 outcomes."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import numpy as np
from .source import load_many
from .features import prepare,ecdf_reference,gts2_score
from .models import CANDIDATES,fit,export
from .metrics import outcomes,summarize,paired_bootstrap
from .ga2_replay import predict_monthly
from .calibration import team_reliability

TRAIN={'2021/2022','2022/2023'}
VALID={'2023/2024','2024/2025'}
EXPOSED={'2025/2026'}
MONITOR={'2026/2027'}

def bucket(obs,seasonset):return [r for r in obs if r.season in seasonset]

def comparable_split(candidates,reference,seasons):
    chosen={s:bucket(reference,s) for s in seasons}
    return chosen

def evaluate(premier,others,output,run_ga2=True):
    root=Path(output);root.mkdir(parents=True,exist_ok=True)
    all_data,coverage=load_many({'Premier League':premier,**others})
    obs,skipped=prepare(all_data['Premier League'])
    tr=bucket(obs,TRAIN);va=bucket(obs,VALID);te=bucket(obs,EXPOSED);mo=bucket(obs,MONITOR)
    # Fixed candidate definitions and alpha are imported, not chosen by the test period.
    val_result={};full_validation={}
    for name in CANDIDATES:
        mod=fit(name,tr);p=mod.predict(va)
        matches=outcomes(va,p);val_result[name]=summarize(matches)
        full_validation[name]=matches
    # Prespecified complexity-penalized selection using validation NLL only.
    # Simpler candidate preferred if within 0.005 NLL of validation minimum.
    candidate_rank={'simple_xg':0,'od':1,'gts2_ecdf':2,'odh':3,'odhqf':4,'odh_bigchance':5}
    best=min(val_result,key=lambda k:val_result[k]['nll'])
    eligible=[k for k in val_result if val_result[k]['nll']<=val_result[best]['nll']+0.005]
    selected=min(eligible,key=lambda k:(candidate_rank[k],val_result[k]['nll']))
    result={'status':'RESEARCH_ONLY','data_cutoff':'2026-10-31','source':'Archived PitchAPI team-stats only',
        'source_coverage':coverage,'feature_skips':skipped,
        'samples':{'train_rows':len(tr),'validation_rows':len(va),'exposed_rows':len(te),'monitor_rows':len(mo),
                   'train_games':len(tr)//2,'validation_games':len(va)//2,'exposed_games':len(te)//2,'monitor_games':len(mo)//2},
        'protocol':{'candidate_ids':list(CANDIDATES),'training_seasons':sorted(TRAIN),
                    'validation_seasons':sorted(VALID),'exposed_diagnostic_seasons':sorted(EXPOSED),
                    'historically_observed_monitor_seasons':sorted(MONITOR),
                    'selection':'Lowest validation NLL, simpler within 0.005',
                    'model_weights_fit':'Train 2021/22-22/23 for validation; expand with 2023/24-24/25 for exposed diagnostic',
                    'prematch_available_proxy':'match finished date + 2 days strictly earlier than evaluated match date',
                    'point_in_time_publication_guaranteed':False,
                    '2025_independent_test':False,
                    '2026_prospective_test':False},
        'validation':val_result,'selection':{'minimum_nll_candidate':best,'selected':selected,
                                            'eligible_within_0_005':eligible}}
    fits={}
    for period,train_rows,eval_rows in [
        ('2025_26_EXPOSED_DIAGNOSTIC',tr+va,te),
        ('2026_27_HISTORICALLY_OBSERVED',tr+va+te,mo)]:
        scores={};preds={}
        for name in CANDIDATES:
            mod=fit(name,train_rows)
            preds[name]=mod.predict(eval_rows)
            scores[name]=summarize(outcomes(eval_rows,preds[name]))
            if name==selected:
                fits[period]=export(mod)
                fits[period]['training_max_date']=max(r.date for r in train_rows)
                fits[period]['training_seasons']=sorted({r.season for r in train_rows})
        result[period]=scores
        result[period+'_selected_calibration']=team_reliability(eval_rows,preds[selected])
        result[period+'_selected_by_season']={season:summarize(outcomes([r for r in eval_rows if r.season==season],np.array([v for r,v in zip(eval_rows,preds[selected]) if r.season==season]))) for season in sorted({r.season for r in eval_rows})}
        result[period+'_paired_vs_simple']={name:paired_bootstrap(outcomes(eval_rows,preds[name]),outcomes(eval_rows,preds['simple_xg'])) for name in CANDIDATES if name!='simple_xg'}
        result[period+'_paired_selected_vs_gts2']=paired_bootstrap(outcomes(eval_rows,preds[selected]),outcomes(eval_rows,preds['gts2_ecdf']))
        # frozen coefficients/rules for a period; do not refit inside this evaluation split
    selected_valid=fit(selected,tr)
    result['selected_validation_scoring_reliability']=team_reliability(va,selected_valid.predict(va))
    result['selected_validation_by_season']={season:summarize(outcomes([r for r in va if r.season==season],selected_valid.predict([r for r in va if r.season==season]))) for season in sorted(VALID)}
    result['validation_paired_selected_vs_simple']=paired_bootstrap(full_validation[selected],full_validation['simple_xg'])
    result['validation_paired_selected_vs_gts2']=paired_bootstrap(full_validation[selected],full_validation['gts2_ecdf'])
    # Component drop tests (for full 5-comp model) as predeclared limited ablation
    ablation={}
    from .models import Fitted
    from sklearn.linear_model import PoissonRegressor
    from sklearn.preprocessing import StandardScaler
    for removed in ('O','D','H','Q','F'):
        fields=tuple(x for x in ('O','D','H','Q','F') if x!=removed)
        def prediction(train,eval):
            X=np.array([[r.features[k] for k in fields] for r in train]);Y=np.array([r.goals for r in train]);sc=StandardScaler().fit(X)
            mdl=PoissonRegressor(alpha=.20,max_iter=250,tol=1e-8).fit(sc.transform(X),Y)
            return mdl.predict(sc.transform(np.array([[r.features[k] for k in fields] for r in eval])))
        ablation['minus_'+removed]=summarize(outcomes(va,prediction(tr,va)))
    result['validation_ablation_full_five']=ablation
    # Removal tests from the SELECTED O/D/H architecture, separately from five-factor GTS2.
    selected_ablation={}
    for removed in ('O','D','H'):
        fields=tuple(f for f in ('O','D','H') if f!=removed)
        X=np.array([[r.features[k] for k in fields] for r in tr]);Y=np.array([r.goals for r in tr])
        sc=StandardScaler().fit(X)
        model=PoissonRegressor(alpha=.20,max_iter=250,tol=1e-8).fit(sc.transform(X),Y)
        XE=np.array([[r.features[k] for k in fields] for r in va])
        selected_ablation['minus_'+removed]=summarize(outcomes(va,model.predict(sc.transform(XE))))
    result['validation_ablation_selected_od_h']=selected_ablation
    comp=['O','D','H','Q','F']
    correlation=np.corrcoef(np.array([[r.features[k] for k in comp] for r in tr],float),rowvar=False)
    result['training_component_correlations']={'fields':comp,'matrix':correlation.tolist()}
    if run_ga2:
        pred,refits=predict_monthly(all_data['Premier League'],obs)
        result['ga2_architecture_replay']={'method':'Fitted separately with published GA2 Poisson config; NOT the frozen deployed GA2 binary','monthly_refits':len(refits),
                                              'first_last_month':[min(refits),max(refits)] if refits else []}
        # Additional incremental value test: an offset-Poisson residual correction
        # is trained on chronologically EARLIER OOF predictions, never on the evaluated season.
        from .incremental import OffsetCorrection
        def ga2_common(rows):return [r for r in rows if (r.match_id,r.team_id) in pred]
        train_early=bucket(obs,{'2021/2022'})
        train_late=ga2_common(bucket(obs,{'2022/2023'}))
        model_early=fit(selected,train_early)
        model_valid=fit(selected,tr)
        model_exposed=fit(selected,tr+va)
        y0=[r.goals for r in train_late]
        a0=[pred[(r.match_id,r.team_id)] for r in train_late]
        g0=model_early.predict(train_late)
        calib_valid=OffsetCorrection().fit(y0,a0,g0)
        valid_rows=ga2_common(va)
        calib_2025=OffsetCorrection().fit(
            y0+[r.goals for r in valid_rows],
            a0+[pred[(r.match_id,r.team_id)] for r in valid_rows],
            list(g0)+list(model_valid.predict(valid_rows)))
        exposed_rows=ga2_common(te)
        calib_2026=OffsetCorrection().fit(
            y0+[r.goals for r in valid_rows]+[r.goals for r in exposed_rows],
            a0+[pred[(r.match_id,r.team_id)] for r in valid_rows]+[pred[(r.match_id,r.team_id)] for r in exposed_rows],
            list(g0)+list(model_valid.predict(valid_rows))+list(model_exposed.predict(exposed_rows)))
        result['incremental_GA2_plus_GTS3']={'description':'Fixed-form offset Poisson corrected GA2 replay; calibrator fitted only on earlier out-of-sample GTS predictions',
                'calibration_params':{'validation':calib_valid.as_dict(),
                    '2025_26_EXPOSED_DIAGNOSTIC':calib_2025.as_dict(),
                    '2026_27_HISTORICALLY_OBSERVED':calib_2026.as_dict()},'status':'RESEARCH_ONLY'}
        for tag,rows,mod,cal in [('validation',va,model_valid,calib_valid),
                ('2025_26_EXPOSED_DIAGNOSTIC',te,model_exposed,calib_2025),
                ('2026_27_HISTORICALLY_OBSERVED',mo,fit(selected,tr+va+te),calib_2026)]:
            r=ga2_common(rows);a=np.array([pred[(q.match_id,q.team_id)] for q in r]);g=mod.predict(r)
            augmented=outcomes(r,cal.predict(a,g));ga2base=outcomes(r,a)
            result['incremental_GA2_plus_GTS3'][tag]={'metrics':summarize(augmented),
                'paired_against_GA2':paired_bootstrap(augmented,ga2base)}
        for tag,rows in [('validation',va),('2025_26_EXPOSED_DIAGNOSTIC',te),('2026_27_HISTORICALLY_OBSERVED',mo)]:
            common=[r for r in rows if (r.match_id,r.team_id) in pred]
            ga2m=outcomes(common,[pred[(r.match_id,r.team_id)] for r in common])
            result['ga2_architecture_replay'][tag]=summarize(ga2m)
            mod=fit(selected,tr if tag=='validation' else tr+va if tag.startswith('2025') else tr+va+te)
            selected_matches=outcomes(common,mod.predict(common))
            result['ga2_architecture_replay'][tag+'_selected_vs_ga2']=paired_bootstrap(selected_matches,ga2m)
    (root/'validation_report.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False))
    (root/'selected_model_parameters.json').write_text(json.dumps(fits,indent=2,ensure_ascii=False,allow_nan=False))
    return result

def main(argv=None):
    p=argparse.ArgumentParser(description='GTS3 offline research. No live API calls, credentials or GA2 modifications')
    p.add_argument('--premier',required=True)
    for league in ('seriea','laliga','bundes','ligue1'):p.add_argument('--'+league)
    p.add_argument('--output',required=True)
    p.add_argument('--no-ga2-replay',action='store_true')
    a=p.parse_args(argv)
    others={name:vars(a)[name] for name in ('seriea','laliga','bundes','ligue1') if vars(a).get(name)}
    result=evaluate(a.premier,others,a.output,run_ga2=not a.no_ga2_replay)
    print(json.dumps({'status':result['status'],'selected':result['selection'],'samples':result['samples'],
                      'validation_nll':{k:round(v['nll'],5) for k,v in result['validation'].items()},
                      'exposed_nll':{k:round(v['nll'],5) for k,v in result['2025_26_EXPOSED_DIAGNOSTIC'].items()}},ensure_ascii=False))
if __name__=='__main__':main()
