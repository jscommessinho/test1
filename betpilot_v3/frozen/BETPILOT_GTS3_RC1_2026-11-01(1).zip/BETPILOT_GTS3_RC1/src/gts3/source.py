"""Strict, non-shot PitchAPI team-aggregate ETL, directly from original GitHub artifact zips.
Private underlying ZIPs and provider responses are never redistributed by this module.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
import json
import math
from pathlib import Path
import re
import zipfile

class SourceError(ValueError): pass
NUMERIC = re.compile(r'^\s*([0-9]+(?:\.[0-9]+)?)\s*(?:\(\s*([0-9]+(?:\.[0-9]+)?)%\))?\s*$')
FIELDS = ('expected_goals','expected_goals_non_penalty','expected_goals_on_target',
          'expected_goals_open_play','expected_goals_set_play','total_shots',
          'ShotsOnTarget','ShotsOffTarget','blocked_shots','shots_inside_box',
          'shots_outside_box','big_chance','big_chance_missed_title','touches_opp_box',
          'corners','BallPossesion','red_cards','yellow_cards','accurate_passes')
INT_FIELDS = {'total_shots','ShotsOnTarget','ShotsOffTarget','blocked_shots',
              'shots_inside_box','shots_outside_box','big_chance','big_chance_missed_title',
              'touches_opp_box','corners','red_cards','yellow_cards'}

@dataclass(frozen=True)
class Match:
    id: str
    date: date
    season: str
    league: str
    home: str
    away: str
    hg: int
    ag: int
    h: dict
    a: dict


def number(value, key):
    if value is None or value == '': return None
    if isinstance(value, bool):raise SourceError('Boolean metric '+key)
    if isinstance(value,(int,float,Decimal)):
        x=float(value)
    elif isinstance(value,str):
        m=NUMERIC.fullmatch(value)
        if not m:return None   # Semantic value not numeric: missing rather than 0
        x=float(m.group(1))
    else:return None
    if not math.isfinite(x) or x<0: raise SourceError('Invalid '+key)
    if key in INT_FIELDS and not x.is_integer():raise SourceError('Noninteger '+key)
    return x


def extract_stats(payload, match_id, home, away):
    if payload.get('match_id')!=match_id: raise SourceError('Stats/match identity conflict '+match_id)
    if payload.get('home_team',{}).get('id') != home or payload.get('away_team',{}).get('id') != away:
        raise SourceError('Stats/team identity conflict '+match_id)
    full=[p for p in payload.get('periods',[]) if p.get('period')=='All']
    if len(full)!=1:raise SourceError('Missing or duplicate full-time period '+match_id)
    items=[i for grp in full[0].get('groups',[]) for i in grp.get('items',[])]
    ret={'home':{},'away':{}};duplicate=0; conflicts=[]
    for key in FIELDS:
        for side in ('home','away'):
            found=[number(i.get(side),key) for i in items if i.get('key')==key]
            valid=[v for v in found if v is not None]
            if len(found)>1:duplicate+=len(found)-1
            if valid:
                if max(valid)-min(valid)>0.011:conflicts.append((key,side,valid))
                ret[side][key]=valid[0]
            else:ret[side][key]=None
    if conflicts: raise SourceError('Conflicting duplicated fields '+match_id+': '+repr(conflicts)[:100])
    for side in ('home','away'):
        r=ret[side]
        if r['expected_goals'] is None or r['total_shots'] is None:raise SourceError('Missing required team xG or shots '+match_id)
        if r['total_shots']==0 and r['expected_goals']>0.02:raise SourceError('Positive xG, no shots '+match_id)
        if r['expected_goals']>r['total_shots']+0.02:raise SourceError('xG > shots '+match_id)
        for a,b in [('expected_goals_non_penalty','expected_goals'),('big_chance_missed_title','big_chance')]:
            if r[a] is not None and r[b] is not None and r[a]>r[b]+0.02:raise SourceError('Implausible '+a+' '+match_id)
        for trio in [('ShotsOnTarget','ShotsOffTarget','blocked_shots'),('shots_inside_box','shots_outside_box')]:
            if all(r[k] is not None for k in trio):
                if abs(sum(r[k] for k in trio)-r['total_shots'])>0.1: raise SourceError('Inconsistent shot totals '+match_id)
    if all(ret[side]['BallPossesion'] is not None for side in ('home','away')):
        if abs(ret['home']['BallPossesion']+ret['away']['BallPossesion']-100)>1:raise SourceError('Possession mismatch '+match_id)
    return ret['home'],ret['away'],duplicate


def _fixture(rec):
    if 'fixture' in rec:
        f=rec['fixture'];return (f['match_id'],f['date'],f['season'],f['home']['id'],f['away']['id'],f['home_goals'],f['away_goals'])
    return (rec['match_id'],rec['date'],rec['season'],rec['home']['id'],rec['away']['id'],rec['home']['goals'],rec['away']['goals'])


def load_zip(path, league_label=None):
    """Supports Premier old artifact but NEVER USES its shot-derived xG; opens raw /stats only.
    Also supports the new four-league full team-stat archives.
    """
    path=Path(path); rows=[]; invalid=[]; counts=Counter(); by_season=defaultdict(Counter)
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist())
        premier='eng-premier_archive.json' in names
        archive=json.loads(z.read('eng-premier_archive.json' if premier else 'archive.json'))
        league_label=league_label or ('Premier League' if premier else archive['league']['name'])
        if premier:
            recs={**archive.get('records',{}),**archive.get('warnings',{})}
        else:recs=archive.get('records',{})
        seen=set()
        for rec in recs.values():
            mid,dt,season,home,away,hg,ag=_fixture(rec)
            if mid in seen:raise SourceError('Duplicate match id '+mid)
            seen.add(mid); by_season[season]['indexed']+=1
            try:
                if not all(isinstance(v,int) and not isinstance(v,bool) and 0<=v<=30 for v in (hg,ag)):raise SourceError('Bad match result '+mid)
                if home==away:raise SourceError('Same team '+mid)
                if premier:
                    file='raw/'+mid+'_stats.json'
                    if file not in names:raise SourceError('Missing raw team stats '+mid)
                    raw=json.loads(z.read(file))
                else:
                    raw=rec['statistics']
                h,a,duplicates=extract_stats(raw,mid,home,away)
                rows.append(Match(mid,date.fromisoformat(dt),season,league_label,home,away,hg,ag,h,a))
                counts['duplicate_field_occurrences']+=duplicates
                by_season[season]['accepted']+=1
            except (KeyError,TypeError,ValueError,InvalidOperation,SourceError) as exc:
                invalid.append({'match_id':mid,'season':season,'reason':str(exc)[:170]})
                by_season[season]['invalid']+=1
        fixtures={}
        for filename in names:
            if filename.startswith('raw/fixtures_') and filename.endswith('.json') or (filename.startswith('fixtures_') and filename.endswith('.json')):
                try:
                    fixture_data=json.loads(z.read(filename))
                    for ft in fixture_data.get('matches',[]):
                        if ft.get('status')!='finished' or not ft.get('date') or not ft.get('id'):continue
                        if date.fromisoformat(ft['date'])+timedelta(days=2)>=date(2026,10,31):continue
                        fixtures[ft['id']]=ft
                except (ValueError,KeyError,TypeError):continue
    rows.sort(key=lambda r:(r.date,r.id))
    coverage={}
    for key in FIELDS:
        for side in ('home','away'):
            coverage[side+'_'+key]=sum(getattr(m,'h' if side=='home' else 'a')[key] is not None for m in rows)
    report={'source':str(path.name),'league':league_label,'indexed':len(recs),'eligible_fixture_listed':len(fixtures),
            'accepted_pct_of_eligible_listed':round(100*len(rows)/len(fixtures),2) if fixtures else None,
            'accepted':len(rows),'invalid':len(invalid),'invalid_examples':invalid[:12],
            'per_season':{s:dict(v) for s,v in sorted(by_season.items())},
            'per_season_field_coverage':{s:{k:sum((m.h[k] is not None)+(m.a[k] is not None) for m in rows if m.season==s) for k in FIELDS} for s in sorted(by_season)},
            'coverage_nonmissing_side_counts':coverage,
            'duplicate_field_occurrences':counts['duplicate_field_occurrences'],
            'xg_source':'PitchAPI /v1/matches/{id}/stats All expected_goals ONLY',
            'individual_shots_used':False,
            'scope_note':'Archived historical responses retrieved in 2026; not authenticated prematch snapshots'}
    return rows,report


def load_many(mapping):
    results={};reports={}
    for label, filename in mapping.items():
        data, report=load_zip(filename,label);results[label]=data;reports[label]=report
    return results,reports
