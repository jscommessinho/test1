"""Proper scoring rules computed on complete MATCHES, never treating the two sides as independent bootstrap units."""
import math
import numpy as np
from scipy.special import gammaln
from scipy.stats import poisson,skellam


def outcomes(obs, pred):
    by={}
    for r,v in zip(obs,pred):
        by.setdefault(r.match_id,[]).append((r,float(v)))
    matches=[]
    for k,rows in by.items():
        if len(rows)!=2 or set(r.venue for r,_ in rows)!={'home','away'}:continue
        (h,lh),(a,la)=sorted(rows,key=lambda pair:pair[0].venue!='home')
        if h.date!=a.date or h.league!=a.league or h.season!=a.season:raise ValueError('Mismatched same match')
        if not np.isfinite([lh,la]).all() or min(lh,la)<=0:raise ValueError('Invalid Poisson lambda')
        y1=(h.goals>a.goals);yx=(h.goals==a.goals);y2=(h.goals<a.goals)
        p1=float(skellam.sf(0,lh,la));p2=float(skellam.cdf(-1,lh,la));px=1-p1-p2
        pgg=(1-math.exp(-lh))*(1-math.exp(-la))
        po=float(poisson.sf(2,lh+la))
        nll=float(lh-h.goals*math.log(lh)+gammaln(h.goals+1)+la-a.goals*math.log(la)+gammaln(a.goals+1))
        per={'nll':nll,'brier_gg':(pgg-(h.goals>0 and a.goals>0))**2,
             'brier_o25':(po-(h.goals+a.goals>=3))**2,
             'brier_1x2':((p1-y1)**2+(px-yx)**2+(p2-y2)**2)/3,
             'mae_xg':(abs(h.observed_xg-lh)+abs(a.observed_xg-la))/2,
             'rmse_xg':((h.observed_xg-lh)**2+(a.observed_xg-la)**2)/2,
             'mean_pred_goals':(lh+la)/2,'mean_obs_goals':(h.goals+a.goals)/2,
             'mean_pred_gg':pgg,'observed_gg':int(h.goals>0 and a.goals>0),
             'mean_pred_o25':po,'observed_o25':int(h.goals+a.goals>=3)}
        matches.append({'match_id':k,'date':h.date,'season':h.season,'metrics':per})
    return matches


def summarize(matches):
    if not matches:return {'matches':0}
    keys=matches[0]['metrics']
    means={k:float(np.mean([m['metrics'][k] for m in matches])) for k in keys}
    means['rmse_xg']=math.sqrt(means['rmse_xg'])
    means['matches']=len(matches)
    return means


def paired_bootstrap(a,b,key='nll',repetitions=1000,seed=42,block_days=30):
    """Calendar-block paired bootstrap. Samples same temporal blocks across both models.
    Negative difference a-b means improvement for a.
    """
    from datetime import date
    am={r['match_id']:r for r in a}; bm={r['match_id']:r for r in b}
    common=[(v,bm[k]) for k,v in am.items() if k in bm]
    if not common:return None
    years=[date.fromisoformat(x[0]['date']).toordinal() for x in common]
    start=min(years)
    blockids=np.array([(n-start)//block_days for n in years])
    uniq=np.unique(blockids)
    perblock=[np.array([i for i,bi in enumerate(blockids) if bi==u],dtype=int) for u in uniq]
    delta=np.array([x['metrics'][key]-y['metrics'][key] for x,y in common])
    rng=np.random.default_rng(seed);bs=[]
    for _ in range(repetitions):
        ix=np.concatenate([perblock[j] for j in rng.integers(0,len(perblock),size=len(perblock))]);bs.append(float(delta[ix].mean()))
    lo,hi=np.percentile(bs,[2.5,97.5]);return {'n_matched':len(common),'delta_mean':float(delta.mean()),'ci95':[float(lo),float(hi)],'resampling':'paired 30-day calendar blocks','replications':repetitions}
