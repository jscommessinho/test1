"""Reconstruct pregame features and score a single fixture using PRE-FROZEN, RESEARCH-ONLY parameters.
No observed match stats or results of the target game enter model inputs.
"""
from __future__ import annotations
import argparse
from datetime import date
import json
import math
import numpy as np
from .source import load_zip,Match
from .features import prepare,midrank

def predict_fixture(source_archive,model_path,period,fixture_date,home_id,away_id,season):
    z=json.load(open(model_path,encoding='utf-8'))
    params=z[period]
    if fixture_date<=params['training_max_date']:
        raise ValueError('Target is before or on model training endpoint: wrong model-period selection')
    history,report=load_zip(source_archive)
    if not history:raise ValueError('Empty archive')
    if home_id==away_id:raise ValueError('Invalid same-team fixture')
    # None here are the UNKNOWN outcome/xG of a FUTURE target, not zeros or input features.
    dummy={k:None for k in ('expected_goals','total_shots')}
    target=Match('PREMATCH_RESEARCH_TARGET',date.fromisoformat(fixture_date),season,
                 history[0].league,home_id,away_id,None,None,dummy,dummy)
    rows,skipped=prepare(history+[target])
    target_rows=[r for r in rows if r.match_id==target.id]
    if len(target_rows)!=2:raise ValueError('GTS NOT AVAILABLE: insufficient data or venue history')
    result=[]
    for r in target_rows:
        x=np.array([r.features[f] for f in params['features']],float)
        mean=np.array(params['scaler_mean'],float);std=np.array(params['scaler_std'],float)
        coef=np.array(params['glm_coefs'],float)
        lam=float(np.clip(math.exp(float(params['glm_intercept']+np.dot(coef,(x-mean)/std))),.02,8.))
        score=100*midrank(lam,params['score_reference'])
        result.append({'team_id':r.team_id,'opponent_id':r.opponent_id,'venue':r.venue,
                       'gts3_0_100_relative':round(score,3),'goals_intensity_research':round(lam,4),
                       'features':{k:round(r.features[k],6) for k in ('O','D','H','Q','F')},
                       'latest_input_match_date':r.latest_history_date,
                       'history_matches_team':r.features['n_team'],
                       'history_matches_opponent':r.features['n_opp'],
                       'history_matches_team_at_venue':r.features['n_team_venue']})
    return {'status':'RESEARCH_ONLY_NO_BETTING','fixture_date':fixture_date,'season':season,
            'model_version':params['name'],'period_calibration':period,'snapshot_is_true_prematch':False,
            'source':'PitchAPI match-team aggregate stats.expected_goals, no per-shot data',
            'interpretation':'0-100 is a historical relative score, NOT a scoring probability',
            'lambda_adjustment_allowed':False,'predictions':result}

def main():
    p=argparse.ArgumentParser()
    for k in ('archive','model','period','date','season','home-id','away-id'):p.add_argument('--'+k,required=True)
    a=p.parse_args()
    o=predict_fixture(a.archive,a.model,a.period,a.date,a.home_id,a.away_id,a.season)
    print(json.dumps(o,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
